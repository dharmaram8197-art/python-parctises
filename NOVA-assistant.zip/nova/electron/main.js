'use strict';
const {
  app, BrowserWindow, Tray, Menu, ipcMain, globalShortcut, nativeImage, Notification, shell, session, dialog,
} = require('electron');
const fs = require('fs');
const path = require('path');
const { BackendManager } = require('./backend-manager');

app.setAppUserModelId('com.nova.assistant');
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

if (!app.requestSingleInstanceLock()) {
  app.quit();
  process.exit(0);
}

const START_HIDDEN = process.argv.includes('--hidden');
const ICON = path.join(__dirname, '..', 'assets', 'icon.png');
let win = null;
let tray = null;
let backend = null;
let quitting = false;
let micEnabled = true;

// ---------------------------------------------------------------- UI prefs
const prefsPath = () => path.join(app.getPath('userData'), 'ui-prefs.json');
const DEFAULT_PREFS = { minimizeToTray: true, hotkey: 'CommandOrControl+Alt+N', trayHintShown: false };
function loadPrefs() {
  try { return { ...DEFAULT_PREFS, ...JSON.parse(fs.readFileSync(prefsPath(), 'utf8')) }; } catch (_) { return { ...DEFAULT_PREFS }; }
}
function savePrefs(p) {
  try { fs.writeFileSync(prefsPath(), JSON.stringify(p, null, 2)); } catch (err) { console.error(err); }
}
let prefs = DEFAULT_PREFS;

const dataDir = () => {
  const d = path.join(app.getPath('userData'), 'data');
  fs.mkdirSync(d, { recursive: true });
  return d;
};
const avatarPath = () => path.join(dataDir(), 'avatar.glb');

function send(channel, payload) {
  if (win && !win.isDestroyed()) win.webContents.send(channel, payload);
}

function showWindow() {
  if (!win) createWindow();
  if (win.isMinimized()) win.restore();
  win.show();
  win.focus();
}

// ---------------------------------------------------------------- window
function createWindow() {
  win = new BrowserWindow({
    width: 1180,
    height: 760,
    minWidth: 420,
    minHeight: 600,
    frame: false,
    show: false,
    backgroundColor: '#05060f',
    title: 'NOVA',
    icon: ICON,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      spellcheck: false,
      backgroundThrottling: false, // keep speaking/reminders working while hidden in the tray
    },
  });

  win.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
  win.once('ready-to-show', () => { if (!START_HIDDEN) win.show(); });

  win.on('close', (e) => {
    if (!quitting && prefs.minimizeToTray) {
      e.preventDefault();
      win.hide();
      if (!prefs.trayHintShown && Notification.isSupported()) {
        new Notification({ title: 'NOVA is still running', body: 'Say "Hey Nova" any time. Right-click the tray icon to quit.', icon: ICON }).show();
        prefs.trayHintShown = true;
        savePrefs(prefs);
      }
    }
  });
  win.on('maximize', () => send('window:maximized', true));
  win.on('unmaximize', () => send('window:maximized', false));

  // Never navigate away or open new Electron windows; send links to the real browser.
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e, url) => {
    if (!url.startsWith('file://')) e.preventDefault();
  });
}

// ---------------------------------------------------------------- tray
function buildTrayMenu() {
  return Menu.buildFromTemplate([
    { label: 'Show NOVA', click: showWindow },
    { label: 'Talk to NOVA', accelerator: prefs.hotkey, click: () => send('tray:action', 'listen') },
    { type: 'separator' },
    { label: 'Microphone on', type: 'checkbox', checked: micEnabled, click: (item) => send('tray:action', item.checked ? 'mic-on' : 'mic-off') },
    { label: 'Launch at startup', type: 'checkbox', checked: getStartup(), click: (item) => setStartup(item.checked) },
    { type: 'separator' },
    { label: 'Quit NOVA', click: () => { quitting = true; app.quit(); } },
  ]);
}
function createTray() {
  let img = nativeImage.createFromPath(ICON);
  if (!img.isEmpty()) img = img.resize({ width: 16, height: 16 });
  tray = new Tray(img);
  tray.setToolTip('NOVA - AI assistant');
  tray.setContextMenu(buildTrayMenu());
  tray.on('click', showWindow);
}
const refreshTray = () => tray && tray.setContextMenu(buildTrayMenu());

// ---------------------------------------------------------------- startup
function getStartup() {
  try { return app.getLoginItemSettings().openAtLogin; } catch (_) { return false; }
}
function setStartup(enabled) {
  const args = app.isPackaged ? ['--hidden'] : [path.resolve(process.argv[1] || '.'), '--hidden'];
  app.setLoginItemSettings({ openAtLogin: !!enabled, path: process.execPath, args });
  refreshTray();
  return getStartup();
}

// ---------------------------------------------------------------- hotkey
function registerHotkey(accel) {
  globalShortcut.unregisterAll();
  try {
    const ok = globalShortcut.register(accel, () => send('hotkey:talk'));
    if (!ok) return false;
    prefs.hotkey = accel;
    return true;
  } catch (_) {
    return false;
  }
}

// ---------------------------------------------------------------- IPC
function setupIpc() {
  ipcMain.handle('backend:get', () => backend.info());
  ipcMain.on('backend:restart', () => backend.restart());

  ipcMain.on('window:minimize', () => win && win.minimize());
  ipcMain.on('window:toggleMaximize', () => { if (win) win.isMaximized() ? win.unmaximize() : win.maximize(); });
  ipcMain.on('window:close', () => win && win.close());

  ipcMain.handle('startup:get', () => getStartup());
  ipcMain.handle('startup:set', (_e, enabled) => setStartup(enabled));

  ipcMain.handle('prefs:get', () => ({ ...prefs }));
  ipcMain.handle('prefs:set', (_e, patch) => {
    if (patch && typeof patch.minimizeToTray === 'boolean') prefs.minimizeToTray = patch.minimizeToTray;
    let hotkeyOk = true;
    if (patch && typeof patch.hotkey === 'string' && patch.hotkey !== prefs.hotkey) {
      const old = prefs.hotkey;
      hotkeyOk = registerHotkey(patch.hotkey);
      if (!hotkeyOk) registerHotkey(old);
    }
    savePrefs(prefs);
    refreshTray();
    return { prefs: { ...prefs }, hotkeyOk };
  });

  ipcMain.on('app:notify', (_e, { title, body }) => {
    if (!Notification.isSupported()) return;
    const n = new Notification({ title: String(title || 'NOVA').slice(0, 80), body: String(body || '').slice(0, 300), icon: ICON });
    n.on('click', showWindow);
    n.show();
  });
  ipcMain.on('app:openExternal', (_e, url) => {
    if (typeof url === 'string' && /^https:\/\//i.test(url)) shell.openExternal(url);
  });
  ipcMain.on('app:openDataFolder', () => shell.openPath(dataDir()));
  ipcMain.on('app:micState', (_e, enabled) => { micEnabled = !!enabled; refreshTray(); });
  ipcMain.on('app:quit', () => { quitting = true; app.quit(); });

  // Optional custom 3D character (.glb). Read here so the renderer never needs file:// fetch.
  ipcMain.handle('avatar:load', () => {
    try { return fs.existsSync(avatarPath()) ? fs.readFileSync(avatarPath()) : null; } catch (_) { return null; }
  });
  ipcMain.handle('avatar:choose', async () => {
    const res = await dialog.showOpenDialog(win, {
      title: 'Choose a 3D character (.glb)', properties: ['openFile'], filters: [{ name: 'glTF binary', extensions: ['glb'] }],
    });
    if (res.canceled || !res.filePaths[0]) return null;
    const src = res.filePaths[0];
    if (fs.statSync(src).size > 80 * 1024 * 1024) throw new Error('That file is larger than 80 MB.');
    fs.copyFileSync(src, avatarPath());
    return fs.readFileSync(avatarPath());
  });
  ipcMain.handle('avatar:reset', () => { try { fs.unlinkSync(avatarPath()); } catch (_) { /* none */ } return true; });
}

// ---------------------------------------------------------------- lifecycle
app.on('second-instance', showWindow);

app.whenReady().then(() => {
  prefs = loadPrefs();

  // The renderer needs no device permissions (the backend owns the microphone).
  const ALLOWED_PERMISSIONS = new Set(['notifications', 'clipboard-sanitized-write']);
  session.defaultSession.setPermissionRequestHandler((_wc, permission, cb) => cb(ALLOWED_PERMISSIONS.has(permission)));

  backend = new BackendManager(app, dataDir());
  backend.on('status', (s) => send('backend:status', s));
  setupIpc();
  createWindow();
  createTray();
  if (!registerHotkey(prefs.hotkey)) registerHotkey(DEFAULT_PREFS.hotkey);
  backend.start();
});

app.on('before-quit', () => {
  quitting = true;
  globalShortcut.unregisterAll();
  if (backend) backend.stop();
});

app.on('window-all-closed', () => {
  // Stay alive in the tray; quitting happens from the tray menu.
  if (process.platform !== 'darwin' && quitting) app.quit();
});

app.on('activate', showWindow);
