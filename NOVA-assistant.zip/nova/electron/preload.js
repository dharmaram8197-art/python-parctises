'use strict';
// Exposes a small, explicit API to the UI. The UI gets no Node.js access.
const { contextBridge, ipcRenderer } = require('electron');

const on = (channel) => (cb) => {
  const handler = (_e, payload) => cb(payload);
  ipcRenderer.on(channel, handler);
  return () => ipcRenderer.removeListener(channel, handler);
};

contextBridge.exposeInMainWorld('nova', {
  platform: process.platform,
  backend: {
    get: () => ipcRenderer.invoke('backend:get'),
    restart: () => ipcRenderer.send('backend:restart'),
    onStatus: on('backend:status'),
  },
  window: {
    minimize: () => ipcRenderer.send('window:minimize'),
    toggleMaximize: () => ipcRenderer.send('window:toggleMaximize'),
    close: () => ipcRenderer.send('window:close'),
    onMaximized: on('window:maximized'),
  },
  startup: {
    get: () => ipcRenderer.invoke('startup:get'),
    set: (enabled) => ipcRenderer.invoke('startup:set', !!enabled),
  },
  prefs: {
    get: () => ipcRenderer.invoke('prefs:get'),
    set: (patch) => ipcRenderer.invoke('prefs:set', patch),
  },
  avatar: {
    load: () => ipcRenderer.invoke('avatar:load'),
    choose: () => ipcRenderer.invoke('avatar:choose'),
    reset: () => ipcRenderer.invoke('avatar:reset'),
  },
  onHotkey: on('hotkey:talk'),
  onTray: on('tray:action'),
  notify: (title, body) => ipcRenderer.send('app:notify', { title, body }),
  openExternal: (url) => ipcRenderer.send('app:openExternal', url),
  openDataFolder: () => ipcRenderer.send('app:openDataFolder'),
  setMicState: (enabled) => ipcRenderer.send('app:micState', !!enabled),
  quit: () => ipcRenderer.send('app:quit'),
});
