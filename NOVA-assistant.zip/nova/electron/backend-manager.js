'use strict';
/**
 * Starts, watches and restarts the Python backend.
 * - Development: runs `python -m nova` from backend/.venv (or NOVA_PYTHON).
 * - Installed app: runs the bundled resources/backend/nova-backend.exe.
 * A random per-launch token is handed over in an environment variable so
 * only this app can talk to the backend's localhost WebSocket.
 */
const { spawn } = require('child_process');
const crypto = require('crypto');
const EventEmitter = require('events');
const fs = require('fs');
const path = require('path');
const readline = require('readline');

const IS_WIN = process.platform === 'win32';

class BackendManager extends EventEmitter {
  constructor(app, dataDir) {
    super();
    this.app = app;
    this.dataDir = dataDir;
    this.proc = null;
    this.port = null;
    this.token = crypto.randomBytes(24).toString('base64url');
    this.restarts = 0;
    this.stopping = false;
    this.lastErrors = [];
    this.status = 'starting';
  }

  resolveCommand() {
    if (this.app.isPackaged) {
      const exe = path.join(process.resourcesPath, 'backend', IS_WIN ? 'nova-backend.exe' : 'nova-backend');
      if (fs.existsSync(exe)) return { cmd: exe, args: [], cwd: path.dirname(exe) };
    }
    const backendDir = path.join(__dirname, '..', 'backend');
    const venvPython = IS_WIN
      ? path.join(backendDir, '.venv', 'Scripts', 'python.exe')
      : path.join(backendDir, '.venv', 'bin', 'python');
    let cmd = IS_WIN ? 'python' : 'python3';
    if (process.env.NOVA_PYTHON) cmd = process.env.NOVA_PYTHON;
    else if (fs.existsSync(venvPython)) cmd = venvPython;
    return { cmd, args: ['-m', 'nova'], cwd: backendDir };
  }

  setStatus(status, detail = '') {
    this.status = status;
    this.emit('status', { status, detail, port: this.port, token: this.token });
  }

  start() {
    this.stopping = false;
    const { cmd, args, cwd } = this.resolveCommand();
    const env = {
      ...process.env,
      NOVA_TOKEN: this.token,
      NOVA_DATA_DIR: this.dataDir,
      PYTHONUNBUFFERED: '1',
      PYTHONIOENCODING: 'utf-8',
    };
    this.setStatus('starting');
    let proc;
    try {
      proc = spawn(cmd, args, { cwd, env, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
    } catch (err) {
      this.setStatus('failed', `Could not start the backend: ${err.message}`);
      return;
    }
    this.proc = proc;

    readline.createInterface({ input: proc.stdout }).on('line', (line) => {
      const m = /^NOVA_BACKEND_READY (\d+)/.exec(line.trim());
      if (m) {
        this.port = Number(m[1]);
        this.restarts = 0;
        this.setStatus('ready');
      }
    });
    readline.createInterface({ input: proc.stderr }).on('line', (line) => {
      this.lastErrors.push(line);
      if (this.lastErrors.length > 40) this.lastErrors.shift();
      if (!this.app.isPackaged) console.log('[backend]', line);
    });

    proc.on('error', (err) => {
      const hint = err.code === 'ENOENT'
        ? 'Python was not found. Run scripts/setup.ps1 (Windows) or scripts/setup.sh first, or set NOVA_PYTHON.'
        : err.message;
      this.setStatus('failed', hint);
    });

    proc.on('exit', (code) => {
      this.proc = null;
      this.port = null;
      if (this.stopping) return;
      const tail = this.lastErrors.slice(-6).join('\n');
      if (this.restarts < 3) {
        this.restarts += 1;
        this.setStatus('restarting', `Backend stopped (code ${code}). Restarting...\n${tail}`);
        setTimeout(() => this.start(), 1500 * this.restarts);
      } else {
        this.setStatus('failed', `The backend keeps stopping (code ${code}).\n${tail}`);
      }
    });
  }

  restart() {
    this.restarts = 0;
    if (this.proc) {
      this.stopping = true;
      this.proc.once('exit', () => this.start());
      this.kill();
    } else {
      this.start();
    }
  }

  kill() {
    const proc = this.proc;
    if (!proc) return;
    try { proc.stdin.end(); } catch (_) { /* ignore */ }
    setTimeout(() => { try { proc.kill(); } catch (_) { /* ignore */ } }, 1500);
  }

  stop() {
    this.stopping = true;
    this.kill();
  }

  info() {
    return { status: this.status, port: this.port, token: this.token, detail: this.lastErrors.slice(-6).join('\n') };
  }
}

module.exports = { BackendManager };
