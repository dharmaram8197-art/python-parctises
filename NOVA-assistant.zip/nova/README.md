# NOVA — AI desktop voice assistant

NOVA is a voice assistant for your Windows laptop. It has an animated 3D male character, a natural male voice, wakes up when you say **"Hey Nova"**, holds real conversations through an AI model, and can control basic things on your laptop. It asks you before doing anything sensitive.

```
 You ──"Hey Nova…"──► Python backend ───────────────────────────────► Electron UI
                       ├─ Microphone + offline wake word (Vosk)         ├─ Three.js 3D character
                       ├─ Speech-to-text (faster-whisper, offline)      │   (lip-sync, blinking, states)
                       ├─ AI brain (Gemini / Groq / OpenAI / Claude /   ├─ Glowing interface rings
                       │   OpenRouter / Ollama) with tool calling       ├─ Subtitles + chat panel
                       ├─ Skills: apps, websites, search, music,        ├─ Settings, privacy, reminders
                       │   reminders, files (sandboxed)                 └─ Tray, startup, hotkey
                       └─ Text-to-speech (neural male voice) ──audio──►
            (both sides talk over an authenticated WebSocket bound to 127.0.0.1 only)
```

## Features

| Area | What works |
|---|---|
| **Voice** | "Hey Nova" wake word detected offline · push-to-talk button / **Ctrl+Alt+N** · automatic end-of-speech detection · follow-up listening (no wake word needed for a few seconds after a reply) · interrupt by saying "Hey Nova", pressing **Esc**/Stop, or clicking the character |
| **Speech** | Natural neural male voice (Andrew, Brian, Guy, Ryan, Prabhat…) streamed sentence by sentence so NOVA starts talking quickly · offline Windows voice as automatic fallback · subtitles while speaking · code is shown on screen, not read aloud |
| **Intelligence** | Natural conversation with short-term memory, follow-up questions, explanations, coding help. The AI calls laptop tools itself ("find my resume and open it") |
| **Laptop** | Open apps (Start-menu search) and websites · time and date · web search (and answering from live results) · play music (your Music folder, then YouTube / YT Music / Spotify) · reminders with notifications · list, search, read, create, move and delete files |
| **Safety** | Creating, moving and deleting files, and opening program files, always show an **Allow / Deny** dialog. You can also answer "yes" or "no" by voice. File actions only work inside folders you allow. Deleting sends files to the Recycle Bin |
| **Desktop** | Windows installer · runs in the tray · launch at startup · global hotkey · microphone on/off switch · privacy settings |

## 1. Requirements

* Windows 10 or 11 (64-bit) and a microphone
* **Python 3.10, 3.11 or 3.12**: <https://www.python.org/downloads/> (tick *"Add python.exe to PATH"*)
* **Node.js 20 or newer**: <https://nodejs.org>
* Internet connection for the AI model and the neural voice. Wake word and speech recognition run offline.

## 2. Setup (about 5 minutes)

Open **PowerShell** in the project folder and run:

```powershell
powershell -ExecutionPolicy Bypass -File scripts\setup.ps1
```

This creates `backend\.venv`, installs the Python packages from `backend\requirements.txt`, installs Electron and Three.js with `npm install`, and runs a health check (`npm run check`).

Manual alternative:

```powershell
py -3.12 -m venv backend\.venv
backend\.venv\Scripts\python -m pip install -r backend\requirements.txt
npm install
npm run check
```

## 3. Add an AI key (stored securely)

NOVA needs a key for one AI provider. **Google Gemini** and **Groq** both have free tiers:

* Gemini: <https://aistudio.google.com/apikey>
* Groq: <https://console.groq.com/keys>
* You can also use OpenAI, Anthropic Claude or OpenRouter, or **Ollama** fully offline with no key.

Choose **one** way to provide the key. Never put a key in the source code.

1. **Recommended: in the app.** Start NOVA, open **Settings → AI brain**, pick the provider, paste the key and click **Save key**. The key goes into the **Windows Credential Manager** (encrypted with your Windows login). It is never written to a project file or a log, and it is never shown again. The UI only shows "✓ set".
2. **Environment variable.** For example, `setx GEMINI_API_KEY "your-key"` in a terminal, then restart NOVA.
3. **`.env` file** (handy during development). Copy `backend\.env.example` to `backend\.env` (or to `%APPDATA%\NOVA\data\.env`) and fill it in. `.env` is in `.gitignore`, so don't commit it.

The lookup order is environment variable / `.env`, then Credential Manager.

## 4. Run

```powershell
npm start
```

On first launch NOVA downloads the wake-word model (about 40 MB) and the speech model `base.en` (about 150 MB). After that it works offline except for the AI and voice.

Things to try:

| Say | NOVA does |
|---|---|
| "Hey Nova, what time is it?" | Answers instantly, offline |
| "Open Notepad" / "Open VS Code" / "Open YouTube" | Launches the app or site |
| "Search for the best laptops under 60,000" | Opens the search results |
| "What's the latest news about ISRO?" | Searches the web and summarises it out loud |
| "Play some lo-fi music" | Plays from your Music folder, or YouTube |
| "Remind me to drink water in 20 minutes" / "…at 6 pm" | Sets a reminder that speaks and notifies you |
| "Explain recursion with an example" | Speaks the explanation, shows the code in Chat |
| "Create a file called notes.txt in Documents with my to-do list" | **Asks for confirmation**, then does it |
| "Delete old.txt from Downloads" | **Asks for confirmation**, then moves it to the Recycle Bin |
| "Stop" / Esc / "Hey Nova" while it talks | Interrupts |

Common commands (time, open, search, play, remind) are handled by a fast offline command router. Everything else goes to the AI, which can call the same tools.

## 5. Build the Windows installer

```powershell
npm run dist
```

This bundles the Python backend with PyInstaller (`backend\dist\nova-backend\`) and builds `release\NOVA Setup 1.0.0.exe` with electron-builder. The installed app doesn't need Python or Node. Speech models are downloaded on first run into `%APPDATA%\NOVA\data\models`.

## 6. Background, startup and privacy

* **Close (✕)** hides NOVA to the system tray. It keeps listening for "Hey Nova", and reminders still fire. Use **tray icon → Quit NOVA** to exit.
* **Settings → General → Launch when Windows starts** starts NOVA hidden in the tray at login.
* **Mic button / tray → Microphone on**: when off, the microphone stream is closed and nothing is heard.
* The wake word is detected **on your laptop**. Audio is only transcribed after the wake word, the Talk button, or a follow-up window. The local Whisper model keeps audio on the laptop. Only the text of your request goes to the AI provider you chose.
* **Settings → Privacy & files**: allowed folders, transcript saving (off by default), open the data folder, forget the conversation.
* Data folder: `%APPDATA%\NOVA\data` (settings, reminders, models, `logs\backend.log`).

## 7. Customising

* **Voice**: Settings → Voice (neural voice, speed, pitch, or OpenAI "onyx" / offline system voice).
* **Your own 3D character**: Settings → General → *Choose .glb…*. Any glTF avatar with ARKit or viseme blend shapes (`jawOpen`, `mouthSmile`, `eyeBlinkLeft/Right`, `viseme_aa`…) gets automatic lip-sync, blinking and head motion.
* **Slow laptop?** Use the speech model `tiny.en`, or Settings → Hearing → *Online Whisper API* with a free Groq key.
* **Other languages**: Settings → General → Language changes the speech recognition and reply language. Pick a matching voice (for example `hi-IN-MadhurNeural` for Hindi) and use the multilingual model `small` instead of `base.en`. Wake-word phrases are editable.
* **New skills**: add a function that returns `ToolResult` in `backend/nova/skills/`, then register it with a JSON schema (and `sensitive=True` if it changes anything). The AI can use it immediately.

## 8. Project layout

```
electron/          main.js (window, tray, startup, hotkey, IPC) · preload.js (safe API) · backend-manager.js
renderer/          index.html · styles.css · js/app.js (controller) · avatar.js (Three.js character)
                   audio-player.js (speech playback + lip-sync analysis) · settings.js · ws-client.js
backend/nova/      __main__.py · server.py (localhost WebSocket + token auth) · assistant.py (state machine)
                   audio/ (capture, VAD, wake word, STT, pipeline) · tts.py · speaker.py · llm/client.py
                   router.py (offline commands) · skills/ (system, files, music, reminders) · config.py · secrets.py
backend/tests/     31 automated tests (router, reminders, file sandbox, confirmations, streaming, interrupts…)
scripts/           setup.ps1 · setup.sh · check.js · build-backend.js · csp-hash.js
```

Run the backend tests: `backend\.venv\Scripts\python -m pip install pytest` and then `backend\.venv\Scripts\python -m pytest backend\tests`.

## 9. Troubleshooting

| Problem | Fix |
|---|---|
| "Backend could not start / Python was not found" | Run `scripts\setup.ps1`, or set `NOVA_PYTHON` to your python.exe path. Check `npm run check` |
| "Hey Nova" doesn't trigger | Check Settings → Hearing → Microphone, and that Windows *Privacy → Microphone → Let desktop apps access your microphone* is **on**. Speak normally from about 1 m away. Use Talk / Ctrl+Alt+N meanwhile |
| NOVA says it needs an API key | Settings → AI brain → paste the key for the selected provider |
| Recognition is slow | Use the speech model `tiny.en` or the online Groq Whisper |
| No voice, only subtitles | The neural voice needs internet. NOVA falls back to the Windows voice, and if that fails it shows subtitles |
| 3D view blank | Run `npm install` (Three.js must be in `node_modules`) and update your graphics driver |
| Anything else | See `%APPDATA%\NOVA\data\logs\backend.log`, or start with `npm run dev` |

Default model names (for example `gemini-2.5-flash` and `gpt-4o-mini`) change over time. If a provider reports an unknown model, enter the current one in Settings → AI brain → Model.
