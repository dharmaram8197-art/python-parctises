#!/usr/bin/env bash
# NOVA setup for macOS / Linux development:  bash scripts/setup.sh
set -euo pipefail
cd "$(dirname "$0")/.."
PY=${PYTHON:-python3}
"$PY" -m venv backend/.venv
backend/.venv/bin/python -m pip install --upgrade pip
backend/.venv/bin/python -m pip install -r backend/requirements.txt
backend/.venv/bin/python -m pip install -r backend/requirements-optional.txt || echo "Optional VAD package skipped"
npm install
node scripts/check.js || true
echo "Done. Start NOVA with: npm start"
