// Quick health check of a development setup:  npm run check
'use strict';
const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const win = process.platform === 'win32';
const venvPy = path.join(root, 'backend', '.venv', win ? 'Scripts/python.exe' : 'bin/python');
let ok = true;
const report = (good, msg, fix) => { console.log(`${good ? '✔' : '✘'} ${msg}${good || !fix ? '' : `\n    → ${fix}`}`); ok = ok && good; };

report(fs.existsSync(path.join(root, 'node_modules', 'three', 'build', 'three.module.js')), 'Three.js installed', 'npm install');
report(fs.existsSync(path.join(root, 'node_modules', 'electron')), 'Electron installed', 'npm install');
const hasVenv = fs.existsSync(venvPy);
report(hasVenv, 'Python virtual environment (backend/.venv)', 'run scripts\\setup.ps1');
if (hasVenv) {
  const code = [
    'import importlib, sys',
    "mods = {'websockets':1,'httpx':1,'numpy':1,'sounddevice':1,'keyring':1,'vosk':0,'faster_whisper':0,'edge_tts':0,'pyttsx3':0,'send2trash':0,'ddgs':0}",
    'bad = []',
    'for m, req in mods.items():',
    '    try: importlib.import_module(m); print("  ok  ", m)',
    '    except Exception as e: print("  MISSING" if req else "  optional missing", m, "-", e); bad += [m] if req else []',
    'sys.exit(1 if bad else 0)',
  ].join('\n');
  const r = spawnSync(venvPy, ['-c', code], { encoding: 'utf8' });
  process.stdout.write(r.stdout || '');
  report(r.status === 0, 'Required Python packages', 'backend\\.venv\\Scripts\\pip install -r backend\\requirements.txt');
}
console.log(ok ? '\nAll good - start NOVA with: npm start' : '\nFix the items above, then run: npm start');
process.exit(ok ? 0 : 1);
