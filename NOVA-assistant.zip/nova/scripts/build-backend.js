// Bundles the Python backend into backend/dist/nova-backend/ with PyInstaller (used by `npm run dist`).
'use strict';
const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const backend = path.join(__dirname, '..', 'backend');
const win = process.platform === 'win32';
const venvPy = path.join(backend, '.venv', win ? 'Scripts/python.exe' : 'bin/python');
const py = process.env.NOVA_PYTHON || (fs.existsSync(venvPy) ? venvPy : (win ? 'python' : 'python3'));

const run = (args) => {
  const r = spawnSync(py, args, { cwd: backend, stdio: 'inherit' });
  if (r.status !== 0) { console.error(`Failed: ${py} ${args.join(' ')}`); process.exit(r.status || 1); }
};
run(['-m', 'pip', 'install', '--quiet', 'pyinstaller>=6.5']);
run(['-m', 'PyInstaller', 'nova-backend.spec', '--noconfirm', '--clean', '--distpath', 'dist', '--workpath', 'build']);
console.log('Backend bundled to backend/dist/nova-backend');
