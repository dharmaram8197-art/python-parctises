# NOVA one-time setup for Windows.  Run from the project folder:
#   powershell -ExecutionPolicy Bypass -File scripts\setup.ps1
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

function Need($cmd, $hint) {
  if (-not (Get-Command $cmd -ErrorAction SilentlyContinue)) { Write-Host "Missing $cmd. $hint" -ForegroundColor Red; exit 1 }
}
Need "node" "Install Node.js 20+ from https://nodejs.org"
$py = $null
$candidates = @("py -3.12", "py -3.11", "py -3.10", "python")
foreach ($cand in $candidates) {
  try {
    $c = @($cand -split ' ')
    $exe = $c[0]; $rest = @($c | Select-Object -Skip 1)
    & $exe @rest --version *> $null
    if ($LASTEXITCODE -eq 0) { $py = $c; break }
  } catch {}
}
if (-not $py) { Write-Host "Python 3.10-3.12 not found. Install it from https://www.python.org (tick 'Add to PATH')." -ForegroundColor Red; exit 1 }
Write-Host "Using Python: $($py -join ' ')" -ForegroundColor Cyan

Write-Host "`n[1/3] Creating Python environment..." -ForegroundColor Cyan
$pyExe = $py[0]; $pyArgs = @($py | Select-Object -Skip 1)
& $pyExe @pyArgs -m venv backend\.venv
& backend\.venv\Scripts\python.exe -m pip install --upgrade pip
& backend\.venv\Scripts\python.exe -m pip install -r backend\requirements.txt
& backend\.venv\Scripts\python.exe -m pip install -r backend\requirements-optional.txt
if ($LASTEXITCODE -ne 0) { Write-Host "Optional VAD package skipped (that's fine)." -ForegroundColor Yellow }

Write-Host "`n[2/3] Installing Electron and Three.js..." -ForegroundColor Cyan
npm install

Write-Host "`n[3/3] Checking setup..." -ForegroundColor Cyan
node scripts\check.js
Write-Host "`nDone! Start NOVA with:  npm start" -ForegroundColor Green
Write-Host "First launch downloads the wake-word (~40 MB) and speech (~150 MB) models." -ForegroundColor Green
