// Keeps the Content-Security-Policy hash in renderer/index.html in sync with the inline import map.
// Run after editing the import map:  npm run csp
'use strict';
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const file = path.join(__dirname, '..', 'renderer', 'index.html');
const html = fs.readFileSync(file, 'utf8');
const m = /<script type="importmap">([\s\S]*?)<\/script>/.exec(html);
if (!m) { console.error('No import map found'); process.exit(1); }
const hash = crypto.createHash('sha256').update(m[1], 'utf8').digest('base64');
const out = html.replace(/script-src 'self' 'sha256-[^']*'/, `script-src 'self' 'sha256-${hash}'`);
if (out !== html) { fs.writeFileSync(file, out); console.log('CSP hash updated:', hash); }
else console.log('CSP hash already up to date:', hash);
