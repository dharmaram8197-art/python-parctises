// NOVA's animated 3D character (Three.js).
// - Built-in: a procedurally modelled male head & shoulders with a deformable jaw,
//   blinking eyelids, moving eyes/brows, holographic rim light and interface rings.
// - Optional: load your own .glb character; ARKit / Oculus-viseme blend shapes
//   (jawOpen, mouthSmile, eyeBlinkLeft, viseme_aa, ...) are driven automatically.
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

const clamp01 = (x) => Math.min(1, Math.max(0, x));
const smooth = (e0, e1, x) => { const t = clamp01((x - e0) / (e1 - e0)); return t * t * (3 - 2 * t); };
const gauss = (v, c, s) => Math.exp(-(((v - c) / s) ** 2));
const lerp = (a, b, t) => a + (b - a) * t;
const damp = (cur, target, lambda, dt) => lerp(cur, target, 1 - Math.exp(-lambda * dt));

export const STATE_COLORS = { idle: 0x3d8bff, listening: 0x22d3ee, thinking: 0xa855f7, speaking: 0x7c83ff };

// ------------------------------------------------------------------ head shape
// Maps a point on the unit sphere to a male head shape (units: head ≈ 2 tall).
function shapeHead(x, y, z, out = new THREE.Vector3()) {
  let X = x * 0.74;
  let Y = y;
  let Z = z * 0.86;
  if (z < 0) Z *= 1.07; // fuller back of the skull
  const ax = Math.abs(x);
  const sx = Math.sign(x);
  const lower = smooth(0.0, -0.95, y);
  X *= 1 - 0.3 * lower; // face narrows toward the chin
  if (z < 0) Z *= 1 - 0.16 * lower; // underside tucks into the neck
  X += sx * 0.07 * gauss(y, -0.55, 0.2) * smooth(0.25, 0.85, ax) * (z > -0.3 ? 1 : 0.4); // square jaw
  const chin = gauss(y, -0.86, 0.14) * smooth(0.2, 0.9, z);
  Z += 0.12 * chin;
  Y -= 0.04 * chin;
  const front = smooth(0.55, 0.95, z);
  Z += 0.055 * gauss(y, 0.24, 0.08) * front * gauss(x, 0, 0.45); // brow ridge
  for (const s of [-1, 1]) Z -= 0.07 * gauss(x - s * 0.31, 0, 0.13) * gauss(y, 0.1, 0.1) * front; // eye sockets
  X += sx * 0.035 * gauss(y, -0.08, 0.13) * smooth(0.35, 0.75, ax) * smooth(-0.1, 0.5, z); // cheekbones
  Z += 0.035 * gauss(y, -0.48, 0.08) * gauss(x, 0, 0.22) * front; // mouth area
  Z -= 0.03 * gauss(x, 0, 0.12) * gauss(y, -0.64, 0.05) * front; // groove under the lip
  X *= 1 - 0.06 * smooth(0.55, 1.0, y); // narrower crown
  return out.set(X, Y, Z);
}
const shapedAt = (x, y, z) => { const v = new THREE.Vector3(x, y, z).normalize(); return shapeHead(v.x, v.y, v.z); };

const JAW_PIVOT = new THREE.Vector3(0, -0.08, -0.18);
function rotateAboutPivot(p, angle, out) {
  const ry = p.y - JAW_PIVOT.y;
  const rz = p.z - JAW_PIVOT.z;
  const c = Math.cos(angle);
  const s = Math.sin(angle);
  return out.set(p.x, JAW_PIVOT.y + ry * c - rz * s, JAW_PIVOT.z + ry * s + rz * c);
}

// ------------------------------------------------------------------ materials
function auraMaterial() {
  return new THREE.ShaderMaterial({
    uniforms: { uColor: { value: new THREE.Color(STATE_COLORS.idle) }, uIntensity: { value: 1 }, uTime: { value: 0 } },
    vertexShader: `
      varying vec3 vN; varying vec3 vV; varying float vY;
      void main() {
        vec4 wp = modelMatrix * vec4(position, 1.0);
        vN = normalize(mat3(modelMatrix) * normal);
        vV = normalize(cameraPosition - wp.xyz);
        vY = wp.y;
        gl_Position = projectionMatrix * viewMatrix * wp;
      }`,
    fragmentShader: `
      uniform vec3 uColor; uniform float uIntensity; uniform float uTime;
      varying vec3 vN; varying vec3 vV; varying float vY;
      void main() {
        float f = pow(1.0 - max(dot(normalize(vN), normalize(vV)), 0.0), 2.6);
        float scan = 0.85 + 0.15 * step(0.5, fract(vY * 38.0 - uTime * 1.5));
        gl_FragColor = vec4(uColor * f * uIntensity * scan, f * uIntensity);
      }`,
    transparent: true,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
  });
}

function ringMaterial({ dashes = 0, duty = 0.5, speed = 0.02, opacity = 0.8 }) {
  return new THREE.ShaderMaterial({
    uniforms: {
      uColor: { value: new THREE.Color(STATE_COLORS.idle) }, uTime: { value: 0 }, uLevel: { value: 0 },
      uDashes: { value: dashes }, uDuty: { value: duty }, uSpeed: { value: speed }, uOpacity: { value: opacity },
    },
    vertexShader: 'varying vec2 vP; void main(){ vP = position.xy; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
    fragmentShader: `
      uniform vec3 uColor; uniform float uTime, uLevel, uDashes, uDuty, uSpeed, uOpacity;
      varying vec2 vP;
      void main() {
        float a = atan(vP.y, vP.x) / 6.28318 + 0.5;
        float on = uDashes > 0.0 ? step(fract((a + uTime * uSpeed) * uDashes), uDuty) : 1.0;
        float sweep = 0.55 + 0.45 * pow(fract(a - uTime * 0.12), 3.0);
        float alpha = on * uOpacity * sweep * (0.55 + 0.6 * uLevel);
        gl_FragColor = vec4(uColor * (1.0 + uLevel), alpha);
      }`,
    transparent: true,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    side: THREE.DoubleSide,
  });
}

// ------------------------------------------------------------------ procedural character
class ProceduralMale {
  constructor() {
    this.group = new THREE.Group();
    this.head = new THREE.Group();
    this.group.add(this.head);
    this.lastOpen = -1;

    const skin = new THREE.MeshPhysicalMaterial({
      color: 0xc6927a, roughness: 0.58, metalness: 0, sheen: 0.35, sheenColor: new THREE.Color(0xff9a80),
      clearcoat: 0.06, emissive: 0x160604,
    });
    this.skin = skin;
    const dark = new THREE.MeshStandardMaterial({ color: 0x17110e, roughness: 0.85 });
    const lip = new THREE.MeshPhysicalMaterial({ color: 0xa8665a, roughness: 0.45, sheen: 0.4 });

    // Head: deformed sphere with per-vertex jaw weights for lip-sync
    const geo = new THREE.SphereGeometry(1, 112, 84);
    const pos = geo.attributes.position;
    this.base = new Float32Array(pos.count * 3);
    this.jawW = new Float32Array(pos.count);
    const v = new THREE.Vector3();
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i); const y = pos.getY(i); const z = pos.getZ(i);
      shapeHead(x, y, z, v);
      pos.setXYZ(i, v.x, v.y, v.z);
      this.base.set([v.x, v.y, v.z], i * 3);
      this.jawW[i] = smooth(-0.42, -0.62, y) * smooth(-0.45, 0.2, z);
    }
    geo.computeVertexNormals();
    this.headGeo = geo;
    this.headMesh = new THREE.Mesh(geo, skin);
    this.head.add(this.headMesh);

    this.aura = new THREE.Mesh(geo, auraMaterial());
    this.aura.scale.setScalar(1.025);
    this.head.add(this.aura);

    // Ears
    for (const s of [-1, 1]) {
      const ear = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 18), skin);
      ear.scale.set(0.055, 0.17, 0.11);
      ear.position.set(s * 0.755, 0.0, -0.06);
      ear.rotation.y = s * -0.35;
      this.head.add(ear);
    }

    // Nose
    const bridgeTop = shapedAt(0, 0.08, 1);
    const tipPos = shapedAt(0, -0.2, 1).add(new THREE.Vector3(0, 0, 0.12));
    const bridge = new THREE.Mesh(new THREE.CapsuleGeometry(0.048, 0.2, 8, 16), skin);
    bridge.position.copy(bridgeTop.clone().lerp(tipPos, 0.5)).add(new THREE.Vector3(0, 0, -0.02));
    bridge.rotation.x = -Math.atan2(tipPos.z - bridgeTop.z, bridgeTop.y - tipPos.y);
    this.head.add(bridge);
    const tip = new THREE.Mesh(new THREE.SphereGeometry(0.065, 24, 18), skin);
    tip.position.copy(tipPos);
    this.head.add(tip);
    for (const s of [-1, 1]) {
      const wing = new THREE.Mesh(new THREE.SphereGeometry(0.045, 18, 14), skin);
      wing.position.copy(tipPos).add(new THREE.Vector3(s * 0.065, -0.02, -0.05));
      this.head.add(wing);
      const nostril = new THREE.Mesh(new THREE.SphereGeometry(0.018, 10, 8), dark);
      nostril.position.copy(tipPos).add(new THREE.Vector3(s * 0.03, -0.05, -0.01));
      this.head.add(nostril);
    }

    // Eyes (glowing irises), eyelids and brows
    this.eyes = [];
    this.lids = [];
    this.brows = [];
    const white = new THREE.MeshPhysicalMaterial({ color: 0xf1f3f8, roughness: 0.15, clearcoat: 0.8 });
    this.irisMat = new THREE.MeshStandardMaterial({ color: 0x1c4fd8, emissive: 0x2a8cff, emissiveIntensity: 0.9, roughness: 0.2 });
    const pupilMat = new THREE.MeshStandardMaterial({ color: 0x020206, roughness: 0.1 });
    for (const s of [-1, 1]) {
      const center = shapedAt(s * 0.3, 0.1, 0.95).add(new THREE.Vector3(0, 0, -0.045));
      const eye = new THREE.Group();
      eye.position.copy(center);
      const ball = new THREE.Mesh(new THREE.SphereGeometry(0.085, 32, 24), white);
      eye.add(ball);
      const iris = new THREE.Mesh(new THREE.SphereGeometry(0.042, 24, 16), this.irisMat);
      iris.scale.z = 0.35;
      iris.position.z = 0.074;
      eye.add(iris);
      const pupil = new THREE.Mesh(new THREE.SphereGeometry(0.019, 16, 12), pupilMat);
      pupil.scale.z = 0.3;
      pupil.position.z = 0.087;
      eye.add(pupil);
      this.head.add(eye);
      this.eyes.push(eye);

      const lid = new THREE.Mesh(new THREE.SphereGeometry(0.092, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2), skin);
      lid.position.copy(center);
      this.head.add(lid);
      this.lids.push(lid);
      const lower = new THREE.Mesh(new THREE.SphereGeometry(0.09, 32, 12, 0, Math.PI * 2, Math.PI * 0.62, Math.PI * 0.38), skin);
      lower.position.copy(center);
      lower.rotation.x = -0.5;
      this.head.add(lower);

      const brow = new THREE.Mesh(new THREE.CapsuleGeometry(0.024, 0.17, 6, 12), dark);
      brow.rotation.z = Math.PI / 2 + s * 0.08;
      brow.scale.z = 0.7;
      const bp = shapedAt(s * 0.3, 0.29, 0.92).add(new THREE.Vector3(0, 0, 0.02));
      brow.position.copy(bp);
      brow.userData.base = bp.clone();
      brow.userData.side = s;
      this.head.add(brow);
      this.brows.push(brow);
    }

    // Mouth: interior, teeth and lips; the lower lip follows the jaw
    this.mouthCenter = shapedAt(0, -0.5, 0.87).add(new THREE.Vector3(0, 0, 0.012));
    const mouth = new THREE.Mesh(new THREE.CircleGeometry(1, 40), new THREE.MeshBasicMaterial({ color: 0x1a0507 }));
    mouth.position.copy(this.mouthCenter).add(new THREE.Vector3(0, 0, -0.004));
    this.mouth = mouth;
    this.head.add(mouth);
    const teeth = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.03, 0.02),
      new THREE.MeshStandardMaterial({ color: 0xeeeae2, roughness: 0.3 }));
    teeth.position.copy(this.mouthCenter).add(new THREE.Vector3(0, 0.012, -0.002));
    this.teeth = teeth;
    this.head.add(teeth);
    this.upperLip = new THREE.Mesh(new THREE.CapsuleGeometry(0.024, 0.2, 6, 16), lip);
    this.upperLip.rotation.z = Math.PI / 2;
    this.upperLip.scale.set(1, 1, 0.55);
    this.upperLip.position.copy(this.mouthCenter).add(new THREE.Vector3(0, 0.026, 0.004));
    this.head.add(this.upperLip);
    this.lowerLip = new THREE.Mesh(new THREE.CapsuleGeometry(0.028, 0.18, 6, 16), lip);
    this.lowerLip.rotation.z = Math.PI / 2;
    this.lowerLip.scale.set(1, 1, 0.6);
    this.lowerLipRest = this.mouthCenter.clone().add(new THREE.Vector3(0, -0.028, 0.004));
    this.lowerLip.position.copy(this.lowerLipRest);
    this.head.add(this.lowerLip);

    // Short hair cap following the skull
    const hairGeo = new THREE.SphereGeometry(1, 96, 48, 0, Math.PI * 2, 0, 1.28);
    const hp = hairGeo.attributes.position;
    const rot = new THREE.Matrix4().makeRotationX(-0.42);
    for (let i = 0; i < hp.count; i++) {
      v.set(hp.getX(i), hp.getY(i), hp.getZ(i)).applyMatrix4(rot);
      const n = 1 + 0.006 * Math.sin(v.x * 60) * Math.sin(v.y * 47 + v.z * 31);
      shapeHead(v.x, v.y, v.z, v).multiplyScalar(1.045 * n);
      hp.setXYZ(i, v.x, v.y, v.z);
    }
    hairGeo.computeVertexNormals();
    this.head.add(new THREE.Mesh(hairGeo, new THREE.MeshStandardMaterial({ color: 0x1a130f, roughness: 0.75, side: THREE.DoubleSide })));

    // Neck, shoulders, futuristic suit
    const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.37, 0.95, 32), skin);
    neck.position.set(0, -1.08, -0.12);
    this.group.add(neck);
    this.torso = new THREE.Group();
    const suit = new THREE.MeshStandardMaterial({ color: 0x121a35, roughness: 0.38, metalness: 0.65 });
    const chest = new THREE.Mesh(new THREE.SphereGeometry(1, 64, 32), suit);
    chest.scale.set(1.6, 0.64, 0.8);
    chest.position.set(0, -1.98, -0.15);
    this.torso.add(chest);
    this.glowMat = new THREE.MeshBasicMaterial({ color: STATE_COLORS.idle });
    const collar = new THREE.Mesh(new THREE.TorusGeometry(0.42, 0.022, 12, 80), this.glowMat);
    collar.rotation.x = Math.PI / 2 - 0.18;
    collar.position.set(0, -1.38, -0.1);
    this.torso.add(collar);
    for (const s of [-1, 1]) {
      const curve = new THREE.CatmullRomCurve3([
        new THREE.Vector3(s * 0.38, -1.42, 0.12), new THREE.Vector3(s * 0.6, -1.52, 0.36),
        new THREE.Vector3(s * 0.95, -1.62, 0.36), new THREE.Vector3(s * 1.35, -1.72, 0.1),
      ]);
      this.torso.add(new THREE.Mesh(new THREE.TubeGeometry(curve, 40, 0.012, 8), this.glowMat));
    }
    this.group.add(this.torso);
  }

  setJaw(open, wide) {
    if (Math.abs(open - this.lastOpen) < 0.002) return;
    this.lastOpen = open;
    const pos = this.headGeo.attributes.position;
    const angle = open * 0.2;
    const p = new THREE.Vector3();
    const o = new THREE.Vector3();
    for (let i = 0; i < pos.count; i++) {
      const w = this.jawW[i];
      if (w <= 0.0005) continue;
      p.fromArray(this.base, i * 3);
      rotateAboutPivot(p, angle * w, o);
      pos.setXYZ(i, o.x, o.y, o.z);
    }
    pos.needsUpdate = true;
    this.headGeo.computeVertexNormals();
    rotateAboutPivot(this.lowerLipRest, angle * 0.85, this.lowerLip.position);
    const gap = this.upperLip.position.y - this.lowerLip.position.y;
    this.mouth.scale.set(0.1 * (1 + wide * 0.2 - open * 0.1), Math.max(0.004, gap * 0.55), 1);
    this.mouth.position.y = (this.upperLip.position.y + this.lowerLip.position.y) / 2;
    const widthScale = 1 + wide * 0.16 - open * 0.08;
    this.upperLip.scale.x = widthScale;
    this.lowerLip.scale.x = widthScale;
    this.teeth.visible = open > 0.08;
  }

  update(p) {
    this.setJaw(p.open, p.wide);
    const lidAngle = lerp(-0.45, 1.3, p.blink); // open (upper lid just over the iris) -> closed
    for (const lid of this.lids) lid.rotation.x = lidAngle;
    for (const eye of this.eyes) { eye.rotation.y = p.gaze.x; eye.rotation.x = -p.gaze.y; }
    for (const b of this.brows) {
      b.position.y = b.userData.base.y + p.brow;
      b.rotation.z = Math.PI / 2 + b.userData.side * (0.08 + p.furrow * 0.18);
    }
    this.head.rotation.set(p.head.x, p.head.y, p.head.z);
    this.head.position.y = p.breath * 0.012;
    this.torso.scale.y = 1 + p.breath * 0.01;
    this.aura.material.uniforms.uColor.value.copy(p.color);
    this.aura.material.uniforms.uIntensity.value = p.glow;
    this.aura.material.uniforms.uTime.value = p.t;
    this.glowMat.color.copy(p.color).multiplyScalar(0.8 + p.glow * 0.6);
    this.irisMat.emissive.copy(p.color);
    this.irisMat.emissiveIntensity = 0.7 + p.glow * 0.6;
  }
}

// ------------------------------------------------------------------ custom GLB character
const MORPHS = {
  open: ['jawopen', 'mouthopen', 'viseme_aa', 'mouth_open', 'aa', 'a'],
  wide: ['mouthsmile', 'viseme_e', 'viseme_i', 'mouthstretchleft', 'mouthstretchright', 'mouthsmileleft', 'mouthsmileright'],
  blink: ['eyeblinkleft', 'eyeblinkright', 'eyesclosed', 'blink', 'eyes_closed'],
  brow: ['browinnerup', 'browouterupleft', 'browouterupright'],
  oh: ['viseme_o', 'mouthfunnel', 'viseme_u'],
};

class GlbCharacter {
  constructor(gltf) {
    this.group = new THREE.Group();
    const model = gltf.scene;
    this.targets = [];
    model.traverse((obj) => {
      if (obj.isMesh && obj.morphTargetDictionary) {
        const dict = {};
        for (const [name, idx] of Object.entries(obj.morphTargetDictionary)) dict[name.toLowerCase()] = idx;
        const pick = (keys) => keys.map((k) => dict[k]).filter((i) => i !== undefined);
        this.targets.push({ mesh: obj, open: pick(MORPHS.open), wide: pick(MORPHS.wide), blink: pick(MORPHS.blink), brow: pick(MORPHS.brow), oh: pick(MORPHS.oh) });
      }
      if (obj.isMesh) obj.frustumCulled = false;
      if (!this.headBone && obj.isBone && /head/i.test(obj.name) && !/top|end/i.test(obj.name)) this.headBone = obj;
    });
    this.headBase = this.headBone ? this.headBone.quaternion.clone() : null;
    model.updateMatrixWorld(true);
    const box = new THREE.Box3().setFromObject(model);
    const size = box.getSize(new THREE.Vector3());
    let scale; let center;
    if (this.headBone) {
      center = this.headBone.getWorldPosition(new THREE.Vector3()).add(new THREE.Vector3(0, size.y * 0.04, 0));
      scale = 2.0 / Math.max(0.15, size.y * 0.14);
    } else {
      center = box.getCenter(new THREE.Vector3());
      center.y = box.max.y - size.y * 0.2;
      scale = 3.0 / Math.max(size.y, 0.001);
    }
    model.position.sub(center);
    this.group.add(model);
    this.group.scale.setScalar(scale);
    this.model = model;
    this.hasMouth = this.targets.some((t) => t.open.length);
    this.q = new THREE.Quaternion();
    this.e = new THREE.Euler();
  }

  update(p) {
    for (const t of this.targets) {
      const inf = t.mesh.morphTargetInfluences;
      for (const i of t.open) inf[i] = p.open * 0.85;
      for (const i of t.wide) inf[i] = p.wide * 0.45 * p.open;
      for (const i of t.oh) inf[i] = Math.max(0, (1 - p.wide) * p.open - 0.4) * 0.6;
      for (const i of t.blink) inf[i] = p.blink;
      for (const i of t.brow) inf[i] = clamp01(p.brow * 25);
    }
    if (this.headBone) {
      this.e.set(p.head.x, p.head.y, p.head.z);
      this.q.setFromEuler(this.e);
      this.headBone.quaternion.copy(this.headBase).multiply(this.q);
    } else {
      this.model.rotation.set(p.head.x * 0.5, p.head.y * 0.5, p.head.z * 0.5);
    }
  }
}

// ------------------------------------------------------------------ scene
export class Avatar {
  constructor(canvas) {
    this.canvas = canvas;
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'low-power' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;

    this.scene = new THREE.Scene();
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    this.scene.environmentIntensity = 0.35;

    this.camera = new THREE.PerspectiveCamera(30, 1, 0.1, 100);
    this.camera.position.set(0, 0.05, 5.4);
    this.lookTarget = new THREE.Vector3(0, -0.28, 0);

    this.scene.add(new THREE.HemisphereLight(0x9cc0ff, 0x1a0b2e, 0.55));
    const key = new THREE.DirectionalLight(0xfff1e6, 2.1);
    key.position.set(1.6, 2.2, 3.2);
    this.scene.add(key);
    this.rimBlue = new THREE.PointLight(0x3a8cff, 22, 12);
    this.rimBlue.position.set(-2.4, 0.9, -1.4);
    this.scene.add(this.rimBlue);
    this.rimPurple = new THREE.PointLight(0xa64dff, 22, 12);
    this.rimPurple.position.set(2.4, 0.5, -1.4);
    this.scene.add(this.rimPurple);
    const fill = new THREE.PointLight(0x7f8cff, 3, 8);
    fill.position.set(0, -0.6, 2.6);
    this.scene.add(fill);

    this.buildInterface();
    this.setCharacter(new ProceduralMale());

    this.state = 'idle';
    this.mouthProvider = () => ({ open: 0, wide: 0 });
    this.micLevel = 0;
    this.color = new THREE.Color(STATE_COLORS.idle);
    this.targetColor = new THREE.Color(STATE_COLORS.idle);
    this.anim = { headX: 0, headY: 0, headZ: 0, brow: 0, furrow: 0, glow: 1, gx: 0, gy: 0, ringSpeed: 1, level: 0 };
    this.gazeTarget = { x: 0, y: 0 };
    this.nextSaccade = 0;
    this.nextBlink = 2;
    this.blinkStart = -1;
    this.clock = new THREE.Clock();

    new ResizeObserver(() => this.resize()).observe(canvas.parentElement);
    this.resize();
    this.renderer.setAnimationLoop(() => this.tick());
  }

  buildInterface() {
    this.ui = new THREE.Group();
    this.ui.position.set(0, 0, -0.9);
    this.scene.add(this.ui);
    this.rings = [
      new THREE.Mesh(new THREE.RingGeometry(1.72, 1.76, 160), ringMaterial({ opacity: 0.75 })),
      new THREE.Mesh(new THREE.RingGeometry(1.86, 1.92, 160), ringMaterial({ dashes: 72, duty: 0.35, speed: 0.01, opacity: 0.55 })),
      new THREE.Mesh(new THREE.RingGeometry(2.05, 2.08, 160), ringMaterial({ dashes: 6, duty: 0.7, speed: -0.03, opacity: 0.6 })),
      new THREE.Mesh(new THREE.RingGeometry(1.55, 1.6, 160), ringMaterial({ dashes: 24, duty: 0.15, speed: 0.05, opacity: 0.5 })),
    ];
    for (const r of this.rings) this.ui.add(r);

    // Orbit rings around the head
    this.orbits = [];
    for (let i = 0; i < 2; i++) {
      const m = new THREE.Mesh(new THREE.TorusGeometry(1.32 + i * 0.12, 0.004, 6, 220),
        new THREE.MeshBasicMaterial({ color: STATE_COLORS.idle, transparent: true, opacity: 0.45, blending: THREE.AdditiveBlending, depthWrite: false }));
      m.rotation.x = Math.PI / 2 + (i ? 0.35 : -0.25);
      m.rotation.y = i ? 0.3 : -0.2;
      this.orbits.push(m);
      this.scene.add(m);
    }

    // Particle field
    const n = 520;
    const pts = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      const r = 1.7 + Math.random() * 1.4;
      const th = Math.random() * Math.PI * 2;
      const ph = Math.acos(2 * Math.random() - 1);
      pts.set([r * Math.sin(ph) * Math.cos(th), r * Math.cos(ph) * 0.8, r * Math.sin(ph) * Math.sin(th) - 0.4], i * 3);
    }
    const pg = new THREE.BufferGeometry();
    pg.setAttribute('position', new THREE.BufferAttribute(pts, 3));
    this.particles = new THREE.Points(pg, new THREE.PointsMaterial({
      color: STATE_COLORS.idle, size: 0.022, transparent: true, opacity: 0.7, blending: THREE.AdditiveBlending, depthWrite: false,
    }));
    this.scene.add(this.particles);
  }

  setCharacter(ch) {
    if (this.character) this.scene.remove(this.character.group);
    this.character = ch;
    this.scene.add(ch.group);
  }

  async loadGlb(buffer) {
    const loader = new GLTFLoader();
    const ab = buffer.buffer ? buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength) : buffer;
    const gltf = await loader.parseAsync(ab, '');
    const ch = new GlbCharacter(gltf);
    this.setCharacter(ch);
    return { hasMouth: ch.hasMouth };
  }

  useDefaultCharacter() { this.setCharacter(new ProceduralMale()); }

  setState(state) {
    this.state = state;
    this.targetColor.set(STATE_COLORS[state] || STATE_COLORS.idle);
  }

  setMicLevel(v) { this.micLevel = v; }

  resize() {
    const el = this.canvas.parentElement;
    const w = el.clientWidth; const h = el.clientHeight;
    if (!w || !h) return;
    this.renderer.setSize(w, h, false);
    const aspect = w / h;
    this.camera.aspect = aspect;
    this.camera.position.z = 5.4 * Math.max(1, 0.95 / aspect);
    this.camera.updateProjectionMatrix();
  }

  tick() {
    const dt = Math.min(0.05, this.clock.getDelta());
    const t = this.clock.elapsedTime;
    const a = this.anim;
    const s = this.state;
    const m = this.mouthProvider();
    const speaking = s === 'speaking';
    const open = speaking || m.open > 0.02 ? m.open : 0;

    // --- head pose per state
    let hx = 0.03 * Math.sin(t * 0.53) - 0.02;
    let hy = 0.07 * Math.sin(t * 0.37);
    let hz = 0.02 * Math.sin(t * 0.29);
    let brow = 0; let furrow = 0; let glow = 0.9 + 0.1 * Math.sin(t * 1.3);
    let ringSpeed = 0.6; let level = 0;
    if (s === 'listening') { hx -= 0.05; hz += 0.07; brow = 0.018; glow = 1.25; ringSpeed = 1.2; level = this.micLevel * 3; }
    if (s === 'thinking') { hx -= 0.08; hy += 0.12; brow = 0.006; furrow = 0.9; glow = 1.1 + 0.25 * Math.sin(t * 6); ringSpeed = 4; level = 0.4 + 0.3 * Math.sin(t * 4); }
    if (speaking) { hx += open * 0.05; hy += 0.03 * Math.sin(t * 1.9); brow = open * 0.012; glow = 1.0 + open * 0.8; ringSpeed = 1.6; level = open; }
    a.headX = damp(a.headX, hx, 5, dt);
    a.headY = damp(a.headY, hy, 4, dt);
    a.headZ = damp(a.headZ, hz, 4, dt);
    a.brow = damp(a.brow, brow, 10, dt);
    a.furrow = damp(a.furrow, furrow, 4, dt);
    a.glow = damp(a.glow, glow, 6, dt);
    a.ringSpeed = damp(a.ringSpeed, ringSpeed, 2, dt);
    a.level = damp(a.level, clamp01(level), 12, dt);
    this.color.lerp(this.targetColor, 1 - Math.exp(-3 * dt));

    // --- eyes: saccades, looking up while thinking
    if (t > this.nextSaccade) {
      this.nextSaccade = t + 0.8 + Math.random() * 3;
      this.gazeTarget = s === 'thinking'
        ? { x: 0.18 + Math.random() * 0.08, y: 0.16 + Math.random() * 0.05 }
        : { x: (Math.random() - 0.5) * 0.16, y: (Math.random() - 0.5) * 0.08 };
    }
    a.gx = damp(a.gx, this.gazeTarget.x, 18, dt);
    a.gy = damp(a.gy, this.gazeTarget.y, 18, dt);

    // --- blinking
    if (this.blinkStart < 0 && t > this.nextBlink) { this.blinkStart = t; this.nextBlink = t + 2 + Math.random() * 4.5; }
    let blink = 0;
    if (this.blinkStart >= 0) {
      const ph = (t - this.blinkStart) / 0.17;
      blink = ph < 0.5 ? ph * 2 : Math.max(0, 2 - ph * 2);
      if (ph >= 1) { this.blinkStart = -1; if (Math.random() < 0.15) this.nextBlink = t + 0.25; }
    }

    this.character.update({
      t, dt, open, wide: m.wide, blink, gaze: { x: a.gx, y: a.gy }, brow: a.brow, furrow: a.furrow,
      head: { x: a.headX, y: a.headY, z: a.headZ }, breath: Math.sin(t * 1.6), color: this.color, glow: a.glow,
    });

    // --- interface rings & particles
    this.rings.forEach((r, i) => {
      const u = r.material.uniforms;
      u.uTime.value = t * a.ringSpeed;
      u.uLevel.value = a.level;
      u.uColor.value.copy(this.color);
      r.rotation.z += dt * a.ringSpeed * (i % 2 ? -0.05 : 0.08);
    });
    const pulse = 1 + a.level * 0.06;
    this.rings[0].scale.setScalar(pulse);
    this.rings[3].scale.setScalar(1 + a.level * 0.12);
    this.orbits.forEach((o, i) => {
      o.rotation.z += dt * a.ringSpeed * (i ? -0.25 : 0.35);
      o.material.color.copy(this.color);
      o.material.opacity = 0.3 + a.level * 0.4;
    });
    this.particles.rotation.y += dt * 0.05 * a.ringSpeed;
    this.particles.material.color.copy(this.color);
    this.rimBlue.intensity = 18 + a.glow * 8;
    this.rimPurple.intensity = 18 + a.glow * 8 + (s === 'thinking' ? 10 : 0);

    this.camera.lookAt(this.lookTarget);
    this.renderer.render(this.scene, this.camera);
  }
}
