// NOVA UI controller: wires the backend connection, voice playback, 3D character and controls.
import { NovaSocket } from './ws-client.js';
import { AudioPlayer } from './audio-player.js';
import { SettingsDialog } from './settings.js';

const $ = (id) => document.getElementById(id);
const appEl = $('app');
const socket = new NovaSocket();
const player = new AudioPlayer();
let avatar = null;

const ui = {
  state: 'idle',
  micEnabled: true,
  micActive: false,
  wakeEnabled: true,
  connected: false,
  pendingConfirm: null,
  streaming: null, // { turn, el, text }
};

// ------------------------------------------------------------------ helpers
function toast(message, level = 'info', ms = 4500) {
  const el = document.createElement('div');
  el.className = `toast ${level}`;
  el.textContent = message;
  $('toasts').appendChild(el);
  while ($('toasts').children.length > 4) $('toasts').firstChild.remove();
  setTimeout(() => { el.style.opacity = '0'; setTimeout(() => el.remove(), 400); }, ms);
}

const STATE_TEXT = { listening: 'Listening…', thinking: 'Thinking…', speaking: 'Speaking…  (Esc to stop)' };
function stateLabel() {
  if (ui.state !== 'idle') return STATE_TEXT[ui.state] || ui.state;
  if (!ui.connected) return 'Connecting…';
  if (!ui.micEnabled) return 'Mic off — type in Chat';
  return ui.wakeEnabled ? 'Say “Hey Nova”' : 'Press Talk or Ctrl+Alt+N';
}
function setState(s) {
  ui.state = s;
  appEl.dataset.state = s;
  appEl.dataset.listening = s === 'listening' ? '1' : '0';
  $('state-text').textContent = stateLabel();
  if (avatar) avatar.setState(s);
  $('mic-label').textContent = !ui.micEnabled ? 'Mic off' : (s === 'listening' ? 'Listening' : (ui.micActive ? 'Mic ready' : 'Mic unavailable'));
}

function setMic(enabled, active) {
  ui.micEnabled = !!enabled;
  ui.micActive = !!active;
  appEl.dataset.mic = ui.micEnabled ? 'on' : 'off';
  $('btn-mic-label').textContent = ui.micEnabled ? 'Mic on' : 'Mic off';
  window.nova.setMicState(ui.micEnabled);
  setState(ui.state);
}

let subtitleTimer = null;
function showSubtitle(text, who = 'assistant') {
  const el = $('subtitles');
  clearTimeout(subtitleTimer);
  el.textContent = text;
  el.classList.toggle('user', who === 'user');
  el.classList.add('show');
  if (who === 'user') subtitleTimer = setTimeout(() => el.classList.remove('show'), 2600);
}
function hideSubtitle(delay = 1400) {
  clearTimeout(subtitleTimer);
  subtitleTimer = setTimeout(() => $('subtitles').classList.remove('show'), delay);
}

// ------------------------------------------------------------------ chat log
function renderRich(el, text) {
  el.textContent = '';
  text.split('```').forEach((part, i) => {
    if (i % 2 === 1) {
      const nl = part.indexOf('\n');
      const code = nl >= 0 ? part.slice(nl + 1) : part;
      const pre = document.createElement('pre');
      const c = document.createElement('code');
      c.textContent = code.replace(/\n$/, '');
      const copy = document.createElement('button');
      copy.className = 'copy-btn';
      copy.textContent = 'Copy';
      copy.addEventListener('click', () => navigator.clipboard.writeText(c.textContent).then(() => { copy.textContent = 'Copied'; }));
      pre.append(c, copy);
      el.appendChild(pre);
    } else {
      part.split(/(`[^`\n]+`)/).forEach((seg) => {
        if (seg.startsWith('`') && seg.endsWith('`') && seg.length > 2) {
          const c = document.createElement('code');
          c.textContent = seg.slice(1, -1);
          el.appendChild(c);
        } else if (seg) {
          el.appendChild(document.createTextNode(seg.replace(/\*\*(.+?)\*\*/g, '$1')));
        }
      });
    }
  });
}

function addMessage(role, text, cls = '') {
  const log = $('chat-log');
  log.querySelector('.chat-empty')?.remove();
  const el = document.createElement('div');
  el.className = `msg ${role} ${cls}`.trim();
  renderRich(el, text);
  log.appendChild(el);
  log.scrollTop = log.scrollHeight;
  return el;
}

const TOOL_LABELS = {
  open_application: (a) => `Opening app · ${a.name}`, open_website: (a) => `Opening website · ${a.url}`,
  web_search: (a) => `Searching · ${a.query}`, play_music: (a) => `Music · ${a.query || 'anything'}`,
  create_reminder: (a) => `Reminder · ${a.message} (${a.when})`, list_reminders: () => 'Checking reminders',
  cancel_reminder: () => 'Cancelling reminder', get_datetime: () => 'Checking the clock', tell_time: () => 'Checking the time',
  tell_date: () => 'Checking the date', list_files: (a) => `Listing · ${a.folder || 'documents'}`,
  search_files: (a) => `Finding files · ${a.name}`, read_text_file: (a) => `Reading · ${a.path}`,
  open_file: (a) => `Opening file · ${a.path}`, create_folder: (a) => `New folder · ${a.path}`,
  create_text_file: (a) => `Saving file · ${a.path}`, move_file: (a) => `Moving · ${a.source}`,
  delete_file: (a) => `Recycle · ${a.path}`, system_info: () => 'System info',
};

// ------------------------------------------------------------------ backend messages
socket.on('_open', () => {
  ui.connected = true;
  $('conn-status').textContent = 'Online';
  $('conn-status').dataset.level = 'ok';
  $('boot').classList.add('hide');
  setState(ui.state);
});
socket.on('_close', () => {
  ui.connected = false;
  player.stop();
  $('conn-status').textContent = 'Reconnecting…';
  $('conn-status').dataset.level = 'warn';
  setState('idle');
});

const settingsDialog = new SettingsDialog(socket, toast);

socket.on('hello', (m) => {
  settingsDialog.setData(m);
  ui.wakeEnabled = m.settings.wake_word.enabled;
  setMic(m.mic.enabled, m.mic.active);
  setState(m.state);
});
socket.on('settings', (m) => {
  settingsDialog.setData({ settings: m.settings });
  ui.wakeEnabled = m.settings.wake_word.enabled;
  setState(ui.state);
});
socket.on('secrets', (m) => settingsDialog.setSecrets(m.secrets));
socket.on('reminders', (m) => settingsDialog.setReminders(m.items));
socket.on('state', (m) => setState(m.state));
socket.on('mic', (m) => setMic(m.enabled, m.active));
socket.on('wake', () => player.chime('wake'));
socket.on('heard_nothing', () => { showSubtitle('I didn’t catch that.', 'user'); });

const bars = [...document.querySelectorAll('.mic-bars i')];
socket.on('level', (m) => {
  const v = Math.min(1, m.value * 3.2);
  bars.forEach((b, i) => { b.style.height = `${3 + Math.max(0, v * 11 - Math.abs(i - 2) * 2.2)}px`; });
  if (avatar) avatar.setMicLevel(m.listening ? v : 0);
});

socket.on('transcript', (m) => {
  if (m.role === 'user') {
    addMessage('user', m.text);
    showSubtitle(`“${m.text}”`, 'user');
    ui.streaming = null;
    return;
  }
  if (ui.streaming && ui.streaming.turn === m.turn) {
    renderRich(ui.streaming.el, m.text);
    ui.streaming.el.classList.toggle('error', !!m.error);
    ui.streaming = null;
  } else {
    addMessage('assistant', m.text, m.error ? 'error' : '');
  }
});
socket.on('assistant_delta', (m) => {
  if (!ui.streaming || ui.streaming.turn !== m.turn) ui.streaming = { turn: m.turn, el: addMessage('assistant', ''), text: '' };
  ui.streaming.text += m.text;
  renderRich(ui.streaming.el, ui.streaming.text);
  $('chat-log').scrollTop = $('chat-log').scrollHeight;
});
socket.on('tool', (m) => {
  const fn = TOOL_LABELS[m.name];
  addMessage('tool', `⚙ ${fn ? fn(m.args || {}) : m.name}`);
  ui.streaming = null;
});

socket.on('audio', (m) => player.enqueue(m));
socket.on('audio_end', (m) => player.endSegment(m.turn));
socket.on('stop_audio', () => { player.stop(); hideSubtitle(200); });

socket.on('confirm', (m) => {
  ui.pendingConfirm = m.id;
  $('confirm-title').textContent = m.title || 'Allow this action?';
  $('confirm-detail').textContent = m.detail;
  $('confirm-modal').hidden = false;
  player.chime('confirm');
  $('btn-allow').focus();
});
socket.on('confirm_resolved', (m) => {
  if (ui.pendingConfirm === m.id) { ui.pendingConfirm = null; $('confirm-modal').hidden = true; }
  addMessage('tool', m.approved ? '✓ Allowed' : '✕ Declined');
});

socket.on('notify', (m) => { window.nova.notify(m.title, m.body); toast(`⏰ ${m.body}`, 'info', 8000); });
socket.on('status', (m) => {
  if (!ui.connected) $('boot-text').textContent = m.message;
  toast(m.message, m.level || 'info', m.level === 'error' ? 8000 : 4500);
});
socket.on('conversation_cleared', () => {
  $('chat-log').innerHTML = '<div class="chat-empty">Conversation cleared. NOVA starts fresh.</div>';
  ui.streaming = null;
});

player.on('chunkStart', (m) => {
  socket.send({ type: 'playback_started', turn: m.turn });
  showSubtitle(m.text);
});
player.on('segmentEnd', (turn) => {
  socket.send({ type: 'playback_finished', turn });
  hideSubtitle(1500);
});

// ------------------------------------------------------------------ controls
function talk() {
  player.ensureCtx();
  if (ui.state === 'listening') socket.send({ type: 'stop_listening' });
  else socket.send({ type: 'start_listening' });
}
function interrupt() {
  player.stop();
  hideSubtitle(100);
  socket.send({ type: 'interrupt' });
}
function respondConfirm(approved) {
  if (!ui.pendingConfirm) return;
  socket.send({ type: 'confirm_response', id: ui.pendingConfirm, approved });
  $('confirm-modal').hidden = true;
}
function toggleChat(force) {
  const panel = $('chat-panel');
  const open = force ?? !panel.classList.contains('open');
  panel.classList.toggle('open', open);
  appEl.classList.toggle('chat-open', open);
  $('btn-chat').classList.toggle('active', open);
  if (open) setTimeout(() => $('chat-input').focus(), 250);
}

$('btn-talk').addEventListener('click', talk);
$('btn-stop').addEventListener('click', interrupt);
$('btn-mic').addEventListener('click', () => socket.send({ type: 'set_mic', enabled: !ui.micEnabled }));
$('btn-chat').addEventListener('click', () => toggleChat());
$('btn-close-chat').addEventListener('click', () => toggleChat(false));
$('btn-clear-chat').addEventListener('click', () => socket.send({ type: 'clear_conversation' }));
$('btn-settings').addEventListener('click', () => settingsDialog.open());
$('btn-allow').addEventListener('click', () => respondConfirm(true));
$('btn-deny').addEventListener('click', () => respondConfirm(false));
$('btn-min').addEventListener('click', () => window.nova.window.minimize());
$('btn-max').addEventListener('click', () => window.nova.window.toggleMaximize());
$('btn-close').addEventListener('click', () => window.nova.window.close());
$('btn-boot-retry').addEventListener('click', () => window.nova.backend.restart());
$('avatar-canvas').addEventListener('click', () => { if (ui.state === 'speaking') interrupt(); });

$('btn-avatar-choose').addEventListener('click', async () => {
  try {
    const buf = await window.nova.avatar.choose();
    if (!buf || !avatar) return;
    const info = await avatar.loadGlb(buf);
    toast(info.hasMouth ? 'Custom character loaded with lip-sync.' : 'Character loaded, but it has no mouth blend shapes (jawOpen / viseme_aa), so lips won’t move.', info.hasMouth ? 'info' : 'warning', 7000);
  } catch (err) {
    toast(`Could not load that character: ${err.message}`, 'error');
  }
});
$('btn-avatar-reset').addEventListener('click', async () => {
  await window.nova.avatar.reset();
  if (avatar) avatar.useDefaultCharacter();
});

const input = $('chat-input');
input.addEventListener('input', () => { input.style.height = 'auto'; input.style.height = `${Math.min(140, input.scrollHeight)}px`; });
input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); $('chat-form').requestSubmit(); }
});
$('chat-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const text = input.value.trim();
  if (!text) return;
  player.ensureCtx();
  if (!socket.send({ type: 'text_input', text })) toast('Not connected yet - your message will be sent when NOVA is back.', 'warning');
  input.value = '';
  input.style.height = 'auto';
});

document.addEventListener('keydown', (e) => {
  if (e.key !== 'Escape') return;
  if (!$('confirm-modal').hidden) respondConfirm(false);
  else if (!$('settings-modal').hidden) settingsDialog.close();
  else if (ui.state === 'speaking' || ui.state === 'thinking' || ui.state === 'listening') interrupt();
  else if ($('chat-panel').classList.contains('open')) toggleChat(false);
});

window.nova.onHotkey(talk);
window.nova.onTray((action) => {
  if (action === 'listen') talk();
  if (action === 'mic-on') socket.send({ type: 'set_mic', enabled: true });
  if (action === 'mic-off') socket.send({ type: 'set_mic', enabled: false });
});

// ------------------------------------------------------------------ backend process
function handleBackend(s) {
  if (s.status === 'ready' && s.port) {
    $('boot-text').textContent = 'Connecting…';
    $('btn-boot-retry').hidden = true;
    $('boot-detail').textContent = '';
    socket.connect(s.port, s.token);
    return;
  }
  if (s.status === 'failed' || s.status === 'restarting') {
    $('boot').classList.remove('hide');
    $('boot-text').textContent = s.status === 'failed' ? 'NOVA’s backend could not start.' : 'Restarting NOVA…';
    $('boot-detail').textContent = s.detail || '';
    $('btn-boot-retry').hidden = s.status !== 'failed';
    $('conn-status').textContent = 'Offline';
    $('conn-status').dataset.level = 'error';
  }
}

async function boot() {
  setState('idle');
  window.nova.backend.onStatus(handleBackend);
  handleBackend(await window.nova.backend.get());
  try {
    const { Avatar } = await import('./avatar.js');
    avatar = new Avatar($('avatar-canvas'));
    avatar.mouthProvider = () => player.mouth();
    avatar.setState(ui.state);
    const glb = await window.nova.avatar.load();
    if (glb) {
      try { await avatar.loadGlb(glb); } catch (err) { toast(`Custom character failed to load (${err.message}); using the default.`, 'warning'); }
    }
  } catch (err) {
    console.error(err);
    toast(`3D view unavailable: ${err.message}. Run "npm install" in the project folder.`, 'error', 10000);
  }
}

boot();
