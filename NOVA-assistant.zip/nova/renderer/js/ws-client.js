// Authenticated WebSocket connection to the local Python backend, with auto-reconnect.
export class NovaSocket {
  constructor() {
    this.ws = null;
    this.handlers = new Map();
    this.port = null;
    this.token = null;
    this.connected = false;
    this.retry = 0;
    this.timer = null;
    this.outbox = [];
  }

  on(type, fn) {
    if (!this.handlers.has(type)) this.handlers.set(type, []);
    this.handlers.get(type).push(fn);
    return this;
  }

  emit(type, msg) {
    for (const fn of this.handlers.get(type) || []) {
      try { fn(msg); } catch (err) { console.error(`handler for ${type} failed`, err); }
    }
  }

  connect(port, token) {
    if (port === this.port && token === this.token && this.ws && this.ws.readyState <= 1) return;
    this.port = port;
    this.token = token;
    this.open();
  }

  open() {
    clearTimeout(this.timer);
    if (this.ws) { try { this.ws.close(); } catch (_) { /* ignore */ } }
    if (!this.port) return;
    const ws = new WebSocket(`ws://127.0.0.1:${this.port}`);
    this.ws = ws;
    ws.onopen = () => {
      ws.send(JSON.stringify({ type: 'auth', token: this.token }));
      this.connected = true;
      this.retry = 0;
      this.emit('_open');
      for (const m of this.outbox.splice(0)) ws.send(JSON.stringify(m));
    };
    ws.onmessage = (ev) => {
      let msg;
      try { msg = JSON.parse(ev.data); } catch (_) { return; }
      this.emit(msg.type, msg);
      this.emit('*', msg);
    };
    ws.onclose = (ev) => {
      if (this.ws !== ws) return;
      this.connected = false;
      this.emit('_close', ev);
      if (ev.code === 4003) return; // bad token - main process will restart us with a new one
      const delay = Math.min(8000, 500 * 2 ** this.retry++);
      this.timer = setTimeout(() => this.open(), delay);
    };
    ws.onerror = () => { /* onclose handles reconnect */ };
  }

  send(msg) {
    if (this.connected && this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(msg));
      return true;
    }
    // Queue only small control messages while reconnecting
    if (['update_settings', 'set_mic', 'text_input', 'set_secret'].includes(msg.type)) this.outbox.push(msg);
    return false;
  }
}
