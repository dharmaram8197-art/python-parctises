// Settings dialog: reads backend settings, writes a patch back on Save.
const $ = (id) => document.getElementById(id);

const KEY_LABELS = {
  GEMINI_API_KEY: { label: 'Google Gemini', url: 'https://aistudio.google.com/apikey' },
  GROQ_API_KEY: { label: 'Groq', url: 'https://console.groq.com/keys' },
  OPENAI_API_KEY: { label: 'OpenAI', url: 'https://platform.openai.com/api-keys' },
  ANTHROPIC_API_KEY: { label: 'Anthropic', url: 'https://console.anthropic.com/settings/keys' },
  OPENROUTER_API_KEY: { label: 'OpenRouter', url: 'https://openrouter.ai/keys' },
};

export class SettingsDialog {
  constructor(socket, toast) {
    this.socket = socket;
    this.toast = toast;
    this.modal = $('settings-modal');
    this.data = null;
    this.wire();
  }

  wire() {
    this.modal.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', () => this.close()));
    this.modal.addEventListener('mousedown', (e) => { if (e.target === this.modal) this.close(); });
    this.modal.querySelectorAll('.tab').forEach((tab) => tab.addEventListener('click', () => this.showTab(tab.dataset.tab)));
    const bindOut = (input, out, fmt) => {
      const upd = () => { $(out).textContent = fmt($(input).value); };
      $(input).addEventListener('input', upd);
      this[`upd_${input}`] = upd;
    };
    bindOut('set-followup', 'out-followup', (v) => (Number(v) ? `${v}s` : 'off'));
    bindOut('set-llm-temp', 'out-temp', (v) => Number(v).toFixed(1));
    bindOut('set-tts-rate', 'out-rate', (v) => `${v > 0 ? '+' : ''}${v}%`);
    bindOut('set-tts-pitch', 'out-pitch', (v) => `${v > 0 ? '+' : ''}${v}Hz`);
    bindOut('set-silence', 'out-silence', (v) => `${(v / 1000).toFixed(1)}s`);

    $('btn-save-settings').addEventListener('click', () => this.save());
    $('btn-test-voice').addEventListener('click', async () => {
      await this.save(false);
      this.socket.send({ type: 'test_voice' });
    });
    $('btn-open-data').addEventListener('click', () => window.nova.openDataFolder());
    $('btn-forget').addEventListener('click', () => {
      this.socket.send({ type: 'clear_conversation' });
      this.toast('Conversation memory cleared.');
    });
    $('btn-restart-backend').addEventListener('click', () => { window.nova.backend.restart(); this.close(); });
    $('set-llm-provider').addEventListener('change', () => this.updateModelPlaceholder());
    $('set-tts-provider').addEventListener('change', () => this.updateVoiceRows());
    $('set-stt-provider').addEventListener('change', () => this.updateSttRows());
  }

  showTab(name) {
    this.modal.querySelectorAll('.tab').forEach((t) => t.classList.toggle('active', t.dataset.tab === name));
    this.modal.querySelectorAll('.tab-panel').forEach((p) => p.classList.toggle('active', p.dataset.panel === name));
  }

  setData(hello) {
    this.data = { ...this.data, ...hello };
  }

  setSecrets(secrets) {
    if (this.data) this.data.secrets = secrets;
    this.renderSecrets();
  }

  setReminders(items) {
    if (this.data) this.data.reminders = items;
    this.renderReminders();
  }

  async open(tab = 'general') {
    if (!this.data) { this.toast('Still connecting to NOVA…', 'warning'); return; }
    this.modal.hidden = false;
    this.showTab(tab);
    await this.fill();
  }

  close() { this.modal.hidden = true; }

  async fill() {
    const s = this.data.settings;
    const [startup, prefs] = await Promise.all([window.nova.startup.get(), window.nova.prefs.get()]);
    $('set-startup').checked = !!startup;
    $('set-tray').checked = !!prefs.minimizeToTray;
    $('set-hotkey').value = prefs.hotkey;
    $('set-wake').checked = s.wake_word.enabled;
    $('set-wake-phrases').value = s.wake_word.phrases.join(', ');
    $('set-followup').value = s.follow_up_seconds;
    $('set-speak-typed').checked = s.speak_typed_replies;
    $('set-language').value = s.language;

    const prov = $('set-llm-provider');
    prov.innerHTML = '';
    for (const [id, p] of Object.entries(this.data.providers)) prov.add(new Option(p.label, id));
    prov.value = s.llm.provider;
    $('set-llm-model').value = s.llm.model;
    $('set-llm-url').value = s.llm.base_url;
    $('set-llm-temp').value = s.llm.temperature;
    $('set-llm-tools').checked = s.llm.enable_tools;
    this.updateModelPlaceholder();

    $('set-tts-provider').value = s.tts.provider;
    const voice = $('set-tts-voice');
    voice.innerHTML = '';
    for (const [id, label] of Object.entries(this.data.voices)) voice.add(new Option(label, id));
    if (![...voice.options].some((o) => o.value === s.tts.voice)) voice.add(new Option(s.tts.voice, s.tts.voice));
    voice.value = s.tts.voice;
    $('set-tts-openai').value = s.tts.openai_voice;
    $('set-tts-rate').value = parseInt(s.tts.rate, 10) || 0;
    $('set-tts-pitch').value = parseInt(s.tts.pitch, 10) || 0;
    this.updateVoiceRows();

    $('set-stt-provider').value = s.stt.provider;
    $('set-stt-model').value = s.stt.model;
    $('set-stt-url').value = s.stt.base_url;
    $('set-stt-key').value = s.stt.key_name;
    const dev = $('set-mic-device');
    dev.innerHTML = '';
    dev.add(new Option('System default', ''));
    for (const d of this.data.devices || []) dev.add(new Option(d.name, String(d.index)));
    dev.value = s.mic.device === null || s.mic.device === undefined ? '' : String(s.mic.device);
    $('set-silence').value = s.mic.silence_ms;
    this.updateSttRows();

    $('set-mic').checked = s.mic.enabled;
    $('set-transcripts').checked = s.privacy.save_transcripts;
    $('set-roots').value = s.files.allowed_roots.join('\n');
    $('set-music-folder').value = s.music.folder;
    $('set-music-service').value = s.music.online_service;
    $('about-version').textContent = `v${this.data.version || ''}`;

    for (const id of ['set-followup', 'set-llm-temp', 'set-tts-rate', 'set-tts-pitch', 'set-silence']) this[`upd_${id}`]();
    this.renderSecrets();
    this.renderReminders();
  }

  updateModelPlaceholder() {
    const p = this.data.providers[$('set-llm-provider').value];
    $('set-llm-model').placeholder = p ? p.model : '';
  }

  updateVoiceRows() {
    const prov = $('set-tts-provider').value;
    $('set-tts-voice').closest('.row').style.display = prov === 'edge' ? '' : 'none';
    $('set-tts-openai').closest('.row').style.display = prov === 'openai' ? '' : 'none';
    $('set-tts-pitch').closest('.row').style.display = prov === 'edge' ? '' : 'none';
    $('set-tts-rate').closest('.row').style.display = prov === 'edge' ? '' : 'none';
  }

  updateSttRows() {
    const online = $('set-stt-provider').value === 'openai_compatible';
    $('set-stt-url').closest('.row').style.display = online ? '' : 'none';
    $('set-stt-key').closest('.row').style.display = online ? '' : 'none';
  }

  renderSecrets() {
    const wrap = $('secret-rows');
    if (!wrap || !this.data) return;
    wrap.innerHTML = '';
    const active = this.data.providers[this.data.settings.llm.provider]?.key_name;
    for (const [name, info] of Object.entries(this.data.secrets || {})) {
      const meta = KEY_LABELS[name] || { label: name };
      const row = document.createElement('div');
      row.className = 'secret-row';
      const title = document.createElement('div');
      title.className = 'name';
      title.textContent = `${meta.label}${name === active ? ' (in use)' : ''}`;
      const badge = document.createElement('span');
      badge.className = `badge${info.set ? ' set' : ''}`;
      badge.textContent = info.set ? `✓ set (${info.source})` : 'not set';
      title.appendChild(badge);
      const link = document.createElement('button');
      link.className = 'ghost';
      link.textContent = 'Get a key ↗';
      link.addEventListener('click', () => window.nova.openExternal(meta.url));
      const ctl = document.createElement('div');
      ctl.className = 'controls-inline';
      const input = document.createElement('input');
      input.type = 'password';
      input.placeholder = `Paste ${name}`;
      input.autocomplete = 'off';
      input.spellcheck = false;
      const save = document.createElement('button');
      save.className = 'ghost';
      save.textContent = 'Save key';
      save.addEventListener('click', () => {
        const value = input.value.trim();
        if (!value) return;
        this.socket.send({ type: 'set_secret', name, value });
        input.value = '';
      });
      const del = document.createElement('button');
      del.className = 'ghost danger';
      del.textContent = 'Remove';
      del.disabled = info.source !== 'credential store';
      del.addEventListener('click', () => this.socket.send({ type: 'delete_secret', name }));
      ctl.append(input, save, del);
      row.append(title, meta.url ? link : document.createElement('span'), ctl);
      wrap.appendChild(row);
    }
  }

  renderReminders() {
    const list = $('reminder-list');
    if (!list || !this.data) return;
    const items = this.data.reminders || [];
    list.innerHTML = '';
    if (!items.length) {
      list.innerHTML = '<p class="hint">No upcoming reminders.</p>';
      return;
    }
    for (const r of items) {
      const row = document.createElement('div');
      row.className = 'reminder';
      const text = document.createElement('div');
      text.textContent = r.message;
      const when = document.createElement('small');
      when.textContent = new Date(r.due).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
      text.appendChild(when);
      const del = document.createElement('button');
      del.className = 'ghost danger';
      del.textContent = 'Delete';
      del.addEventListener('click', () => this.socket.send({ type: 'delete_reminder', id: r.id }));
      row.append(text, del);
      list.appendChild(row);
    }
  }

  collect() {
    const rate = Number($('set-tts-rate').value);
    const pitch = Number($('set-tts-pitch').value);
    const device = $('set-mic-device').value;
    return {
      language: $('set-language').value,
      wake_word: {
        enabled: $('set-wake').checked,
        phrases: $('set-wake-phrases').value.split(',').map((p) => p.trim().toLowerCase()).filter(Boolean),
      },
      follow_up_seconds: Number($('set-followup').value),
      speak_typed_replies: $('set-speak-typed').checked,
      llm: {
        provider: $('set-llm-provider').value,
        model: $('set-llm-model').value.trim(),
        base_url: $('set-llm-url').value.trim(),
        temperature: Number($('set-llm-temp').value),
        enable_tools: $('set-llm-tools').checked,
      },
      tts: {
        provider: $('set-tts-provider').value,
        voice: $('set-tts-voice').value,
        openai_voice: $('set-tts-openai').value,
        rate: `${rate >= 0 ? '+' : ''}${rate}%`,
        pitch: `${pitch >= 0 ? '+' : ''}${pitch}Hz`,
      },
      stt: {
        provider: $('set-stt-provider').value,
        model: $('set-stt-model').value.trim() || 'base.en',
        base_url: $('set-stt-url').value.trim(),
        key_name: $('set-stt-key').value,
      },
      mic: {
        enabled: $('set-mic').checked,
        device: device === '' ? null : Number(device),
        silence_ms: Number($('set-silence').value),
      },
      privacy: { save_transcripts: $('set-transcripts').checked },
      files: { allowed_roots: $('set-roots').value.split('\n').map((l) => l.trim()).filter(Boolean) },
      music: { folder: $('set-music-folder').value.trim(), online_service: $('set-music-service').value },
    };
  }

  async save(closeAfter = true) {
    const patch = this.collect();
    this.socket.send({ type: 'update_settings', patch });
    await window.nova.startup.set($('set-startup').checked);
    const res = await window.nova.prefs.set({ minimizeToTray: $('set-tray').checked, hotkey: $('set-hotkey').value.trim() });
    if (!res.hotkeyOk) this.toast(`That hotkey couldn't be registered; keeping ${res.prefs.hotkey}.`, 'warning');
    if (closeAfter) this.close();
  }
}
