// Plays NOVA's speech chunk by chunk and measures it for lip-sync.
export class AudioPlayer {
  constructor() {
    this.ctx = null;
    this.analyser = null;
    this.queue = [];
    this.playing = false;
    this.turn = null;
    this.generation = 0;
    this.current = null;
    this.timer = null;
    this.fakeUntil = 0;
    this.listeners = {};
    this.td = null;
    this.fd = null;
    this.smooth = { open: 0, wide: 0 };
  }

  on(evt, fn) { (this.listeners[evt] ||= []).push(fn); }
  emit(evt, arg) { for (const fn of this.listeners[evt] || []) fn(arg); }

  ensureCtx() {
    if (!this.ctx) {
      this.ctx = new AudioContext();
      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 1024;
      this.analyser.smoothingTimeConstant = 0.45;
      this.gain = this.ctx.createGain();
      this.analyser.connect(this.gain);
      this.gain.connect(this.ctx.destination);
      this.td = new Float32Array(this.analyser.fftSize);
      this.fd = new Uint8Array(this.analyser.frequencyBinCount);
    }
    if (this.ctx.state === 'suspended') this.ctx.resume();
    return this.ctx;
  }

  decode(msg) {
    if (!msg.data) return Promise.resolve(null);
    const ctx = this.ensureCtx();
    const bin = atob(msg.data);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return ctx.decodeAudioData(bytes.buffer).catch((err) => {
      console.warn('Could not decode speech audio', err);
      return null;
    });
  }

  enqueue(msg) {
    if (this.turn !== null && msg.turn < this.turn) return; // stale
    if (msg.turn !== this.turn) { this.stop(); this.turn = msg.turn; }
    this.queue.push({ kind: 'chunk', msg, buffer: this.decode(msg) });
    this.pump();
  }

  endSegment(turn) {
    if (this.turn !== null && turn < this.turn) return;
    if (this.turn === null || turn > this.turn) this.turn = turn;
    this.queue.push({ kind: 'end', turn });
    this.pump();
  }

  async pump() {
    if (this.playing) return;
    const item = this.queue.shift();
    if (!item) return;
    this.playing = true;
    const gen = this.generation;
    if (item.kind === 'end') {
      this.playing = false;
      this.emit('segmentEnd', item.turn);
      this.pump();
      return;
    }
    const buffer = await item.buffer;
    if (gen !== this.generation) return;
    this.emit('chunkStart', item.msg);
    const done = () => {
      if (gen !== this.generation) return;
      this.current = null;
      this.playing = false;
      this.emit('chunkEnd', item.msg);
      this.pump();
    };
    if (buffer) {
      const src = this.ctx.createBufferSource();
      src.buffer = buffer;
      src.connect(this.analyser);
      src.onended = done;
      this.current = src;
      src.start();
    } else {
      // No audio (voice offline): show the subtitle for a natural reading time
      const ms = Math.max(1200, item.msg.text.length * 62);
      this.fakeUntil = performance.now() + ms;
      this.timer = setTimeout(done, ms);
    }
  }

  stop() {
    this.generation++;
    this.queue = [];
    clearTimeout(this.timer);
    this.fakeUntil = 0;
    if (this.current) { try { this.current.stop(); } catch (_) { /* already stopped */ } }
    this.current = null;
    const wasPlaying = this.playing;
    this.playing = false;
    if (wasPlaying) this.emit('stopped');
  }

  get isPlaying() { return this.playing; }

  // Mouth shape from the live audio: open = loudness, wide = share of high frequencies.
  mouth() {
    let open = 0;
    let wide = 0;
    if (this.current && this.analyser) {
      this.analyser.getFloatTimeDomainData(this.td);
      let sum = 0;
      for (let i = 0; i < this.td.length; i++) sum += this.td[i] * this.td[i];
      const rms = Math.sqrt(sum / this.td.length);
      open = Math.min(1, Math.max(0, (rms - 0.012) * 7));
      this.analyser.getByteFrequencyData(this.fd);
      const hz = this.ctx.sampleRate / this.analyser.fftSize;
      const band = (a, b) => {
        let s = 0; let n = 0;
        for (let i = Math.floor(a / hz); i < Math.min(this.fd.length, Math.floor(b / hz)); i++) { s += this.fd[i]; n++; }
        return n ? s / n : 0;
      };
      const low = band(250, 1200);
      const high = band(2500, 7000);
      wide = low + high > 1 ? high / (low + high) : 0;
    } else if (performance.now() < this.fakeUntil) {
      const t = performance.now() / 1000;
      open = Math.max(0, Math.sin(t * 11) * 0.5 + Math.sin(t * 17.3) * 0.3 + 0.15);
      wide = 0.3 + 0.2 * Math.sin(t * 5);
    }
    const k = open > this.smooth.open ? 0.55 : 0.25; // fast open, softer close
    this.smooth.open += (open - this.smooth.open) * k;
    this.smooth.wide += (wide - this.smooth.wide) * 0.2;
    return { ...this.smooth };
  }

  chime(kind = 'wake') {
    const ctx = this.ensureCtx();
    const now = ctx.currentTime;
    const notes = kind === 'wake' ? [660, 990] : kind === 'end' ? [880, 587] : [520];
    notes.forEach((f, i) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = 'sine';
      o.frequency.value = f;
      g.gain.setValueAtTime(0.0001, now + i * 0.09);
      g.gain.exponentialRampToValueAtTime(0.12, now + i * 0.09 + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.09 + 0.22);
      o.connect(g); g.connect(ctx.destination);
      o.start(now + i * 0.09);
      o.stop(now + i * 0.09 + 0.25);
    });
  }
}
