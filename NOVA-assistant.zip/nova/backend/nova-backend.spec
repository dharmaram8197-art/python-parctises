# PyInstaller spec for the NOVA backend.  Build with:  npm run build:backend
# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_all, collect_dynamic_libs

datas, binaries, hiddenimports = [], [], []
for pkg in ("vosk", "faster_whisper", "ctranslate2", "edge_tts", "sounddevice", "_sounddevice_data",
            "keyring", "tokenizers", "onnxruntime", "av"):
    try:
        d, b, h = collect_all(pkg)
        datas += d; binaries += b; hiddenimports += h
    except Exception:
        pass
binaries += collect_dynamic_libs("vosk")
hiddenimports += [
    "pyttsx3.drivers", "pyttsx3.drivers.sapi5", "comtypes", "comtypes.client",
    "keyring.backends.Windows", "win32timezone", "send2trash", "ddgs", "webrtcvad",
    "websockets.asyncio.server", "dotenv",
]

a = Analysis(["run_backend.py"], pathex=["."], binaries=binaries, datas=datas,
             hiddenimports=hiddenimports, excludes=["tkinter", "matplotlib", "PyQt5", "PySide6", "pytest"])
pyz = PYZ(a.pure)
# console=True keeps stdin/stdout pipes working; Electron starts it with windowsHide so no window appears.
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name="nova-backend", console=True,
          icon="../assets/icon.ico" if __import__("os").path.exists("../assets/icon.ico") else None)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name="nova-backend")
