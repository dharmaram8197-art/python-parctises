"""End-to-end turn logic with a fake AI model and fake voice."""
import threading
import time

import pytest

from nova.assistant import Assistant
from nova.config import Settings


class FakeTTS:
    def synthesize(self, text):
        return b"ID3fake", "audio/mpeg"


class FakeClient:
    def __init__(self, script):
        self.script = script  # list of event lists, one per model call
        self.calls = []

    def stream(self, messages, tools, cancel=None):
        self.calls.append(messages)
        yield from self.script.pop(0)


@pytest.fixture
def nova(tmp_path):
    msgs = []
    s = Settings(tmp_path / "settings.json")
    s.update({"files": {"allowed_roots": [str(tmp_path)]}, "mic": {"enabled": False}})
    a = Assistant(s, msgs.append)
    a.speaker.tts = FakeTTS()
    return a, msgs, tmp_path


def wait_for(cond, timeout=3.0):
    end = time.time() + timeout
    while time.time() < end:
        if cond():
            return True
        time.sleep(0.02)
    return False


def types(msgs):
    return [m["type"] for m in msgs]


def test_router_command_speaks_and_finishes(nova):
    a, msgs, _ = nova
    a.handle_text("what time is it", "voice")
    assert wait_for(lambda: "audio_end" in types(msgs))
    audio = [m for m in msgs if m["type"] == "audio"]
    assert audio and audio[0]["text"].startswith("It's") and audio[0]["data"]
    a.on_playback_finished(a.turn)
    assert a.state == "idle"  # mic disabled -> no follow-up listening


def test_llm_answer_streams_sentences_and_remembers(nova):
    a, msgs, _ = nova
    client = FakeClient([[("text", "Black holes are regions of space. "), ("text", "Nothing escapes them.")],
                         [("text", "Yes, light too.")]])
    a._client = lambda: client
    a.handle_text("explain black holes", "text")
    assert wait_for(lambda: "audio_end" in types(msgs))
    spoken = [m["text"] for m in msgs if m["type"] == "audio"]
    assert spoken == ["Black holes are regions of space.", "Nothing escapes them."]
    a.handle_text("even light?", "text")
    assert wait_for(lambda: len(client.calls) == 2 and types(msgs).count("audio_end") >= 2)
    second = client.calls[1]
    assert any(m["role"] == "assistant" and "Nothing escapes" in m["content"] for m in second)


def test_sensitive_tool_requires_confirmation(nova):
    a, msgs, root = nova
    client = FakeClient([
        [("tool_calls", [{"id": "c1", "name": "create_text_file",
                          "arguments": {"path": "plan.txt", "content": "hi"}}])],
        [("text", "Done, I saved plan.txt.")],
    ])
    a._client = lambda: client
    a.handle_text("save a file called plan.txt saying hi", "text")
    assert wait_for(lambda: "confirm" in types(msgs))
    assert not (root / "plan.txt").exists()
    confirm = next(m for m in msgs if m["type"] == "confirm")
    a.handle_ui({"type": "confirm_response", "id": confirm["id"], "approved": True})
    assert wait_for(lambda: (root / "plan.txt").exists())
    assert wait_for(lambda: any(m["type"] == "transcript" and m["role"] == "assistant" for m in msgs))


def test_denied_by_voice(nova):
    a, msgs, root = nova
    client = FakeClient([
        [("tool_calls", [{"id": "c1", "name": "delete_file", "arguments": {"path": "x.txt"}}])],
        [("text", "Okay, I left it alone.")],
    ])
    (root / "x.txt").write_text("keep me")
    a._client = lambda: client
    a.handle_text("delete x.txt", "voice")
    assert wait_for(lambda: "confirm" in types(msgs))
    a.handle_text("no", "voice")
    assert wait_for(lambda: "confirm_resolved" in types(msgs))
    assert (root / "x.txt").exists()
    resolved = next(m for m in msgs if m["type"] == "confirm_resolved")
    assert resolved["approved"] is False


def test_interrupt_cancels_turn(nova):
    a, msgs, _ = nova
    gate = threading.Event()

    class Slow:
        def stream(self, messages, tools, cancel=None):
            yield ("text", "This is a long answer that keeps going. ")
            gate.wait(2)
            yield ("text", "This part should never be spoken. ")

    a._client = lambda: Slow()
    a.handle_text("tell me a story", "voice")
    assert wait_for(lambda: "audio" in types(msgs))
    a.interrupt()
    gate.set()
    time.sleep(0.3)
    assert not any("never be spoken" in m.get("text", "") for m in msgs if m["type"] == "audio")
    assert a.state == "idle"


def test_missing_key_gives_helpful_answer(nova, monkeypatch):
    a, msgs, _ = nova
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    import nova.secrets as sec
    monkeypatch.setattr(sec, "get_secret", lambda name: None)
    a.handle_text("what is the meaning of life", "text")
    assert wait_for(lambda: any(m["type"] == "transcript" and m.get("error") for m in msgs))
    err = next(m for m in msgs if m["type"] == "transcript" and m.get("error"))
    assert "API key" in err["text"]
