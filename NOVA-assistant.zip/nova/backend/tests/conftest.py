import os
import sys
import tempfile
from pathlib import Path

os.environ.setdefault("NOVA_DATA_DIR", tempfile.mkdtemp(prefix="nova-test-"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
