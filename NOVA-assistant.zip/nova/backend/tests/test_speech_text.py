from nova.speech_text import SentenceSplitter, to_speech


def test_strip_markdown():
    assert to_speech("**Bold** and `code` see [docs](http://x.y)") == "Bold and code see docs"


def test_streaming_sentences():
    s = SentenceSplitter()
    out = []
    for ch in ["Hello there, I am NOVA. ", "How can I ", "help you today? I can", " do a lot."]:
        out += s.feed(ch)
    out += s.flush()
    assert out == ["Hello there, I am NOVA.", "How can I help you today?", "I can do a lot."]


def test_code_not_spoken():
    s = SentenceSplitter()
    text = "Here is a function that adds numbers:\n```python\ndef add(a, b):\n    return a + b\n```\nCall it with two values."
    out = []
    for i in range(0, len(text), 7):
        out += s.feed(text[i:i + 7])
    out += s.flush()
    joined = " ".join(out)
    assert "return" not in joined and "def add" not in joined
    assert "I've put the code on your screen." in out
    assert out[-1] == "Call it with two values."
