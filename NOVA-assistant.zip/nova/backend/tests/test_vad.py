import numpy as np

from nova.audio.vad import FRAME_SAMPLES, Recorder


def frame(amplitude):
    t = np.arange(FRAME_SAMPLES)
    return (np.sin(t / 5.0) * amplitude).astype(np.int16).tobytes()


def test_detects_utterance_end():
    r = Recorder(threshold=500, start_timeout_s=3, silence_ms=300)
    r.vad = None
    statuses = [r.feed(frame(20)) for _ in range(5)]
    statuses += [r.feed(frame(5000)) for _ in range(20)]
    out = None
    for _ in range(30):
        out = r.feed(frame(20))
        if out:
            break
    assert out == "done" and r.started and len(r.audio()) > 0
    assert all(s is None for s in statuses)


def test_timeout_without_speech():
    r = Recorder(threshold=500, start_timeout_s=0.3)
    r.vad = None
    results = [r.feed(frame(10)) for _ in range(12)]
    assert "timeout" in results


def test_wake_phrase_matching():
    from nova.audio.wakeword import WakeWordDetector
    d = WakeWordDetector(["hey nova"])
    assert d.matches("hey nova") and d.matches("um hey nova what time")
    assert not d.matches("hey there")
    d.free_form = True
    assert d.matches("hey no va")
    assert d.matches("hey nover")
    assert not d.matches("open the browser")
