from datetime import datetime

from nova.skills.reminders import ReminderService, describe_time, parse_when

NOW = datetime(2026, 11, 25, 18, 41, 0)


def test_relative():
    assert parse_when("in 10 minutes", NOW) == datetime(2026, 11, 25, 18, 51)
    assert parse_when("in an hour and 30 minutes", NOW) == datetime(2026, 11, 25, 20, 11)
    assert parse_when("after 45 seconds", NOW) == datetime(2026, 11, 25, 18, 41, 45)
    assert parse_when("in half an hour", NOW) == datetime(2026, 11, 25, 19, 11)


def test_clock_times():
    assert parse_when("at 7 pm", NOW) == datetime(2026, 11, 25, 19, 0)
    assert parse_when("at 5:30pm", NOW) == datetime(2026, 11, 26, 17, 30)  # passed today -> tomorrow
    assert parse_when("tomorrow at 9 am", NOW) == datetime(2026, 11, 26, 9, 0)
    assert parse_when("at 21:15", NOW) == datetime(2026, 11, 25, 21, 15)
    assert parse_when("at noon", NOW) == datetime(2026, 11, 26, 12, 0)
    assert parse_when("at 8", NOW) == datetime(2026, 11, 25, 20, 0)  # next 8 o'clock
    assert parse_when("tomorrow", NOW) == datetime(2026, 11, 26, 9, 0)
    assert parse_when("2026-12-01T10:00", NOW) == datetime(2026, 12, 1, 10, 0)


def test_invalid():
    assert parse_when("whenever you like", NOW) is None
    assert parse_when("at 99", NOW) is None


def test_service_fires(tmp_path):
    fired = []
    svc = ReminderService(tmp_path / "r.json", fired.append)
    r = svc.create_reminder("stretch", "in 1 second")
    assert r.ok and "stretch" in r.message
    assert len(svc.list()) == 1
    import time
    svc.start()
    time.sleep(2.6)
    svc.stop()
    assert fired and fired[0]["message"] == "stretch"
    assert svc.list() == []
    # persisted
    assert ReminderService(tmp_path / "r.json", fired.append).list() == []


def test_describe():
    assert describe_time(datetime(2026, 11, 26, 9, 0), NOW) == "tomorrow at 9:00 AM"
