import pytest

from nova.skills.base import Registry
from nova.skills.files import FileManager, register


@pytest.fixture
def setup(tmp_path):
    root = tmp_path / "allowed"
    root.mkdir()
    (root / "notes.txt").write_text("hello")
    fm = FileManager(lambda: [str(root)])
    reg = Registry()
    register(reg, fm)
    return root, fm, reg


def test_sandbox_blocks_outside(setup, tmp_path):
    root, fm, _ = setup
    with pytest.raises(PermissionError):
        fm.resolve(str(tmp_path / "secret.txt"))
    with pytest.raises(PermissionError):
        fm.resolve("../outside.txt")
    assert fm.resolve("notes.txt") == (root / "notes.txt").resolve()


def test_read_and_list_need_no_confirmation(setup):
    root, _, reg = setup
    asked = []
    res = reg.execute("read_text_file", {"path": "notes.txt"}, lambda t, d: asked.append(d) or False)
    assert res.ok and res.data["content"] == "hello" and not asked
    res = reg.execute("list_files", {"folder": str(root)}, lambda t, d: False)
    assert res.ok and res.data["items"][0]["name"] == "notes.txt"


def test_changes_require_confirmation(setup):
    root, _, reg = setup
    asked = []
    res = reg.execute("create_text_file", {"path": "todo.txt", "content": "x"},
                      lambda t, d: asked.append(d) or False)
    assert not res.ok and asked and not (root / "todo.txt").exists()
    res = reg.execute("create_text_file", {"path": "todo.txt", "content": "x"}, lambda t, d: True)
    assert res.ok and (root / "todo.txt").read_text() == "x"
    res = reg.execute("move_file", {"source": "todo.txt", "destination": "sub/todo2.txt"}, lambda t, d: True)
    assert res.ok and (root / "sub" / "todo2.txt").exists()


def test_refuses_to_delete_root(setup):
    root, fm, _ = setup
    assert not fm.delete_file(str(root)).ok


def test_outside_path_reports_error(setup, tmp_path):
    _, _, reg = setup
    res = reg.execute("read_text_file", {"path": str(tmp_path / "x.txt")}, lambda t, d: True)
    assert not res.ok and "only work inside" in res.message
