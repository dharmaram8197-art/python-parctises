import json

from nova.llm.client import (parse_anthropic_stream, parse_openai_stream, sse_data, to_anthropic,
                             to_openai_messages)


def test_openai_stream_text_and_tools():
    lines = [
        'data: ' + json.dumps({"choices": [{"delta": {"content": "Opening "}}]}),
        'data: ' + json.dumps({"choices": [{"delta": {"content": "it."}}]}),
        'data: ' + json.dumps({"choices": [{"delta": {"tool_calls": [{"index": 0, "id": "c1", "function": {"name": "open_application", "arguments": "{\"na"}}]}}]}),
        'data: ' + json.dumps({"choices": [{"delta": {"tool_calls": [{"index": 0, "function": {"arguments": "me\": \"notepad\"}"}}]}}]}),
        "data: [DONE]",
    ]
    ev = list(parse_openai_stream(sse_data(lines)))
    assert ev[0] == ("text", "Opening ") and ev[1] == ("text", "it.")
    assert ev[2] == ("tool_calls", [{"id": "c1", "name": "open_application", "arguments": {"name": "notepad"}}])


def test_anthropic_stream():
    payloads = [
        {"type": "content_block_start", "index": 0, "content_block": {"type": "text", "text": ""}},
        {"type": "content_block_delta", "index": 0, "delta": {"type": "text_delta", "text": "Sure."}},
        {"type": "content_block_start", "index": 1, "content_block": {"type": "tool_use", "id": "t1", "name": "play_music"}},
        {"type": "content_block_delta", "index": 1, "delta": {"type": "input_json_delta", "partial_json": "{\"query\":"}},
        {"type": "content_block_delta", "index": 1, "delta": {"type": "input_json_delta", "partial_json": "\"jazz\"}"}},
        {"type": "message_stop"},
    ]
    ev = list(parse_anthropic_stream(payloads))
    assert ev == [("text", "Sure."), ("tool_calls", [{"id": "t1", "name": "play_music", "arguments": {"query": "jazz"}}])]


HIST = [
    {"role": "system", "content": "sys"},
    {"role": "user", "content": "play jazz"},
    {"role": "assistant", "content": "", "tool_calls": [{"id": "t1", "name": "play_music", "arguments": {"query": "jazz"}}]},
    {"role": "tool", "tool_call_id": "t1", "name": "play_music", "content": "{\"ok\": true}"},
    {"role": "assistant", "content": "Playing jazz."},
]


def test_conversions():
    o = to_openai_messages(HIST)
    assert o[2]["tool_calls"][0]["function"]["arguments"] == '{"query": "jazz"}'
    assert o[3] == {"role": "tool", "tool_call_id": "t1", "content": '{"ok": true}'}
    system, a = to_anthropic(HIST)
    assert system == "sys"
    assert [m["role"] for m in a] == ["user", "assistant", "user", "assistant"]
    assert a[1]["content"][0]["type"] == "tool_use"
    assert a[2]["content"][0]["type"] == "tool_result"
