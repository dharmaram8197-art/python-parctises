from nova import router


def m(t):
    i = router.match(t)
    return (i.tool, i.args) if i else None


def test_time_and_date():
    assert m("Hey Nova, what time is it?")[0] == "tell_time"
    assert m("what's the date today")[0] == "tell_date"
    assert m("what is the date and time")[0] == "get_datetime"


def test_open_app_vs_site():
    assert m("open notepad") == ("open_application", {"name": "notepad"})
    assert m("can you open youtube please") == ("open_website", {"url": "youtube"})
    assert m("go to github.com") == ("open_website", {"url": "github.com"})
    assert m("launch vs code") == ("open_application", {"name": "vs code"})
    assert m("open the report file in documents") is None  # goes to the AI


def test_search_and_play():
    assert m("search for black holes") == ("web_search", {"query": "black holes", "engine": "google"})
    assert m("search lofi beats on youtube") == ("web_search", {"query": "lofi beats", "engine": "youtube"})
    assert m("play some music") == ("play_music", {"query": "some music"})
    assert m("play believer by imagine dragons")[1]["query"] == "believer by imagine dragons"


def test_reminders():
    assert m("remind me to drink water in 10 minutes") == (
        "create_reminder", {"message": "drink water", "when": "in 10 minutes"})
    assert m("remind me at 6 pm to call mom") == (
        "create_reminder", {"message": "call mom", "when": "at 6 pm"})
    assert m("what are my reminders")[0] == "list_reminders"


def test_general_questions_go_to_ai():
    assert m("explain quantum entanglement") is None
    assert m("how do I reverse a list in python") is None


def test_yes_no_and_stop():
    assert router.parse_yes_no("Yes please") is True
    assert router.parse_yes_no("yeah go ahead") is True
    assert router.parse_yes_no("no, don't") is False
    assert router.parse_yes_no("what is the weather") is None
    assert router.is_stop("Nova, stop")
    assert not router.is_stop("stop the music video and open chrome")
