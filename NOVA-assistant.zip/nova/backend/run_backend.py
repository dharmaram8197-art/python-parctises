"""PyInstaller entry point (equivalent to `python -m nova`)."""
from nova.__main__ import main

if __name__ == "__main__":
    main()
