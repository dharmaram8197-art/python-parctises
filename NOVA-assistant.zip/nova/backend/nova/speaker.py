"""Background speech synthesis.

Sentences are queued as the AI streams its reply; a worker thread turns each
into audio and ships it to the UI immediately, so NOVA starts talking after
the first sentence instead of waiting for the whole answer.
"""
from __future__ import annotations

import base64
import logging
import queue
import threading

log = logging.getLogger("nova.speaker")


class Speaker:
    def __init__(self, tts, send):
        self.tts = tts
        self.send = send
        self.q: "queue.Queue[tuple]" = queue.Queue()
        self.current_turn = 0
        self.seq = 0
        self._warned = False
        self.enabled = True
        threading.Thread(target=self._loop, daemon=True, name="speaker").start()

    def begin(self, turn: int) -> None:
        self.current_turn = turn

    def cancel(self) -> None:
        """Drop everything still queued (the UI is told to stop playback separately)."""
        try:
            while True:
                self.q.get_nowait()
        except queue.Empty:
            pass

    def say(self, turn: int, text: str) -> None:
        if text.strip():
            self.q.put(("say", turn, text.strip()))

    def end_segment(self, turn: int) -> None:
        self.q.put(("end", turn, ""))

    def _loop(self) -> None:
        while True:
            kind, turn, text = self.q.get()
            if turn != self.current_turn:
                continue
            if kind == "end":
                self.send({"type": "audio_end", "turn": turn})
                continue
            self.seq += 1
            data, mime = None, None
            if self.enabled:
                try:
                    audio, mime = self.tts.synthesize(text)
                    data = base64.b64encode(audio).decode("ascii")
                except Exception as exc:
                    log.warning("Speech synthesis failed: %s", exc)
                    if not self._warned:
                        self._warned = True
                        self.send({"type": "status", "level": "warning",
                                   "message": "Voice output is unavailable right now - showing subtitles only."})
            if turn != self.current_turn:
                continue  # interrupted while synthesizing
            self.send({"type": "audio", "turn": turn, "seq": self.seq, "text": text, "mime": mime, "data": data})
