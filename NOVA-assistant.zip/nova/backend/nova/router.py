"""Fast, offline intent matching for common commands.

Clear commands ("open notepad", "what time is it", "remind me in 5 minutes to
stretch") are handled instantly without calling the AI model, so they work
even without internet or an API key. Everything else goes to the AI model,
which can call the same tools itself.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from .skills.system import KNOWN_SITES


@dataclass
class Intent:
    tool: str
    args: dict = field(default_factory=dict)


_WAKE_PREFIX = re.compile(r"^\s*(?:hey|hi|okay|ok)?\s*nova[\s,.!:]*", re.I)
_POLITE = re.compile(r"^(?:(?:can|could|would|will) you|please|kindly)\s+", re.I)
_TRAIL = re.compile(r"\s*(?:please|for me|now|thanks|thank you)[\s.!?]*$", re.I)

STOP_WORDS = {"stop", "stop talking", "be quiet", "quiet", "shut up", "cancel", "never mind",
              "nevermind", "that's enough", "thats enough", "enough", "silence"}

YES = {"yes", "yeah", "yep", "yup", "sure", "ok", "okay", "go ahead", "do it", "confirm", "confirmed",
       "allow", "please do", "yes please", "of course", "affirmative", "proceed", "sounds good", "absolutely"}
NO = {"no", "nope", "nah", "don't", "do not", "cancel", "stop", "deny", "never mind", "nevermind",
      "no thanks", "negative", "don't do it", "abort"}


def clean(text: str) -> str:
    t = _WAKE_PREFIX.sub("", text.strip())
    for _ in range(2):
        t = _POLITE.sub("", t)
    t = _TRAIL.sub("", t)
    return t.strip().rstrip(".!?").strip()


def parse_yes_no(text: str) -> bool | None:
    t = clean(text).lower().strip(" .!?,")
    if t in YES or re.match(r"^(yes|yeah|yep|sure|ok(ay)?|go ahead|do it)\b", t):
        return True
    if t in NO or re.match(r"^(no|nope|nah|don'?t|cancel|stop)\b", t):
        return False
    return None


def is_stop(text: str) -> bool:
    return clean(text).lower().strip(" .!?,") in STOP_WORDS


_TIME = re.compile(r"^(?:what(?:'s| is) the (?:current )?time(?: now)?|what time is it(?: now)?|"
                   r"tell me the time|current time|time)$", re.I)
_DATE = re.compile(r"^(?:what(?:'s| is) (?:the |today'?s )?date(?: today)?|what day is (?:it|today)|"
                   r"today'?s date|tell me the date|what(?:'s| is) today)$", re.I)
_DATETIME = re.compile(r"^what(?:'s| is) the (?:date and time|time and date)$", re.I)
_OPEN = re.compile(r"^(?:open|launch|start|run|go to|visit)\s+(?:up\s+)?(.+)$", re.I)
_SEARCH = re.compile(r"^(?:search|google|look up|search the web)\s+(?:for\s+|about\s+)?(.+?)"
                     r"(?:\s+on\s+(google|youtube|bing|the web|the internet))?$", re.I)
_SEARCH_YT = re.compile(r"^(?:search|find)\s+(?:on\s+)?youtube\s+(?:for\s+)?(.+)$", re.I)
_PLAY = re.compile(r"^play\s+(.+?)(?:\s+on\s+(youtube|spotify|youtube music))?$", re.I)
_REMIND_A = re.compile(r"^(?:remind me|set a reminder|create a reminder)\s+(?:to\s+|about\s+)?(.+?)\s+"
                       r"((?:in|after|at|on|tomorrow|tonight|today|by)\b.+)$", re.I)
_REMIND_B = re.compile(r"^(?:remind me|set a reminder)\s+((?:in|after|at|tomorrow|tonight|today)\b.+?)\s+"
                       r"(?:to|about|that)\s+(.+)$", re.I)
_LIST_REM = re.compile(r"^(?:what are|list|show)(?: me)? my reminders$|^(?:do i have any )?reminders\??$", re.I)
_DOMAIN = re.compile(r"^[\w-]+(\.[\w-]+)+(/\S*)?$")


def match(text: str) -> Intent | None:
    t = clean(text)
    if not t:
        return None
    low = t.lower()

    if _DATETIME.match(low):
        return Intent("get_datetime")
    if _TIME.match(low):
        return Intent("tell_time")
    if _DATE.match(low):
        return Intent("tell_date")
    if _LIST_REM.match(low):
        return Intent("list_reminders")

    m = _REMIND_B.match(t)
    if m:
        return Intent("create_reminder", {"message": m.group(2), "when": m.group(1)})
    m = _REMIND_A.match(t)
    if m:
        return Intent("create_reminder", {"message": m.group(1), "when": m.group(2)})

    m = _SEARCH_YT.match(t)
    if m:
        return Intent("web_search", {"query": m.group(1), "engine": "youtube"})
    m = _SEARCH.match(t)
    if m:
        engine = (m.group(2) or "google").lower()
        engine = "youtube" if engine == "youtube" else ("bing" if engine == "bing" else "google")
        return Intent("web_search", {"query": m.group(1), "engine": engine})

    m = _PLAY.match(t)
    if m:
        return Intent("play_music", {"query": m.group(1)})

    m = _OPEN.match(t)
    if m:
        target = m.group(1).strip().strip(".")
        tl = target.lower()
        tl = re.sub(r"^(?:the|my)\s+", "", tl)
        tl = re.sub(r"\s+(?:website|site|web ?page)$", "", tl)
        if tl in KNOWN_SITES or _DOMAIN.match(tl) or tl.startswith("http"):
            return Intent("open_website", {"url": tl})
        # Requests that sound like files or complex tasks go to the AI model
        if any(w in tl for w in (" file", "folder", " and ", "document", "\\", "/")):
            return None
        if len(tl.split()) <= 4:
            return Intent("open_application", {"name": target})
    return None
