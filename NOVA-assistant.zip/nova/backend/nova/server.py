"""Local WebSocket bridge between the Electron UI and the Python backend.

* Binds to 127.0.0.1 only - never reachable from the network.
* Every connection must authenticate with a random per-launch token that
  Electron passes to the backend through an environment variable.
"""
from __future__ import annotations

import asyncio
import hmac
import json
import logging
from concurrent.futures import ThreadPoolExecutor

log = logging.getLogger("nova.server")


class Hub:
    def __init__(self):
        self.loop: asyncio.AbstractEventLoop | None = None
        self.clients: set = set()

    def send(self, msg: dict) -> None:
        """Thread-safe broadcast to all connected UIs."""
        if self.loop is None or self.loop.is_closed():
            return
        data = json.dumps(msg, ensure_ascii=False)
        asyncio.run_coroutine_threadsafe(self._broadcast(data), self.loop)

    async def _broadcast(self, data: str) -> None:
        for ws in list(self.clients):
            try:
                await ws.send(data)
            except Exception:
                self.clients.discard(ws)


async def serve(assistant_factory, token: str, host: str = "127.0.0.1", port: int = 0,
                on_ready=None, stop_event: asyncio.Event | None = None) -> None:
    try:
        from websockets.asyncio.server import serve as ws_serve  # websockets >= 13
    except ImportError:  # pragma: no cover
        from websockets import serve as ws_serve  # type: ignore

    hub = Hub()
    hub.loop = asyncio.get_running_loop()
    assistant = assistant_factory(hub.send)
    ui_worker = ThreadPoolExecutor(max_workers=1, thread_name_prefix="ui")  # keeps message order

    async def handler(ws):
        try:
            first = await asyncio.wait_for(ws.recv(), timeout=5)
            auth = json.loads(first)
        except Exception:
            await ws.close(4001, "auth required")
            return
        if auth.get("type") != "auth" or not hmac.compare_digest(str(auth.get("token", "")), token):
            log.warning("Rejected unauthenticated connection")
            await ws.close(4003, "forbidden")
            return
        hub.clients.add(ws)
        log.info("UI connected (%d client(s))", len(hub.clients))
        try:
            await ws.send(json.dumps(assistant.hello(), ensure_ascii=False))
            async for raw in ws:
                try:
                    msg = json.loads(raw)
                except json.JSONDecodeError:
                    continue
                if isinstance(msg, dict):
                    hub.loop.run_in_executor(ui_worker, _safe_dispatch, assistant, msg)
        except Exception as exc:
            log.info("UI connection closed: %s", exc)
        finally:
            hub.clients.discard(ws)

    async with ws_serve(handler, host, port, max_size=8 * 1024 * 1024, ping_interval=20) as server:
        actual_port = list(server.sockets)[0].getsockname()[1]
        assistant.start()
        if on_ready:
            on_ready(actual_port)
        await (stop_event.wait() if stop_event else asyncio.Future())
        assistant.shutdown()


def _safe_dispatch(assistant, msg: dict) -> None:
    try:
        assistant.handle_ui(msg)
    except Exception:
        log.exception("Error handling UI message %s", msg.get("type"))
