"""NOVA's brain: conversation state machine tying voice, AI and skills together.

States sent to the UI: idle | listening | thinking | speaking
"""
from __future__ import annotations

import json
import logging
import platform
import threading
import uuid
from datetime import datetime
from typing import Any, Callable

from . import router, secrets
from .audio.capture import Microphone
from .audio.pipeline import VoicePipeline
from .audio.stt import SpeechToText, STTError
from .config import LLM_PROVIDERS, MALE_VOICES, SECRET_NAMES, Settings, data_dir
from .llm import ChatClient, LLMError
from .speaker import Speaker
from .speech_text import SentenceSplitter, to_speech
from .skills import ReminderService, build_registry
from .tts import TextToSpeech

log = logging.getLogger("nova.assistant")

LANG_NAMES = {"en": "English", "hi": "Hindi", "kn": "Kannada", "ta": "Tamil", "te": "Telugu",
              "es": "Spanish", "fr": "French", "de": "German", "ja": "Japanese"}
MAX_TOOL_STEPS = 6


class Conversation:
    """Short-term memory: the last N user/assistant exchanges (incl. tool calls)."""

    def __init__(self, max_turns: int = 20):
        self.max_turns = max_turns
        self.turns: list[list[dict]] = []
        self._lock = threading.Lock()

    def add(self, msgs: list[dict]) -> None:
        with self._lock:
            self.turns.append(msgs)
            self.turns = self.turns[-self.max_turns:]

    def messages(self) -> list[dict]:
        with self._lock:
            return [m for t in self.turns for m in t]

    def clear(self) -> None:
        with self._lock:
            self.turns.clear()


class Assistant:
    def __init__(self, settings: Settings, send: Callable[[dict], Any]):
        self.settings = settings
        self._send = send
        self.state = "idle"
        self._lock = threading.RLock()
        self.turn = 0
        self.cancel_event = threading.Event()
        self.turn_active = False
        self.last_source = "voice"
        self.pending: dict | None = None
        self.history = Conversation(int(settings.get("llm.max_history_turns") or 20))
        self.reminders = ReminderService(data_dir() / "reminders.json", self._on_reminder_due)
        self.registry = build_registry(settings, self.reminders)
        self.tts = TextToSpeech(settings)
        self.speaker = Speaker(self.tts, self.send)
        self.stt = SpeechToText(settings, self.status)
        self.voice = VoicePipeline(self)
        settings.on_change(self._on_settings_changed)

    # ------------------------------------------------------------------ io
    def send(self, msg: dict) -> None:
        try:
            self._send(msg)
        except Exception:
            log.exception("send failed")

    def status(self, message: str, level: str = "info") -> None:
        log.info("status[%s]: %s", level, message)
        self.send({"type": "status", "message": message, "level": level})

    def set_state(self, state: str) -> None:
        with self._lock:
            if state == self.state:
                return
            self.state = state
        self.send({"type": "state", "state": state})

    def mic_status(self) -> dict:
        return {"type": "mic", "enabled": bool(self.settings.get("mic.enabled")), "active": self.voice.active}

    def hello(self) -> dict:
        return {
            "type": "hello",
            "version": "1.0.0",
            "state": self.state,
            "settings": self.settings.snapshot(),
            "secrets": secrets.secrets_status(),
            "providers": {k: {"label": v["label"], "model": v["model"], "key_name": v["key_name"]}
                          for k, v in LLM_PROVIDERS.items()},
            "voices": MALE_VOICES,
            "devices": Microphone.list_devices(),
            "mic": self.mic_status(),
            "reminders": self.reminders.list(),
        }

    # ------------------------------------------------------------ lifecycle
    def start(self) -> None:
        self.reminders.start()
        if self.settings.get("mic.enabled"):
            if self.voice.start() and self.settings.get("stt.provider") == "faster_whisper":
                self.stt.preload_async()
        self.send(self.mic_status())

    def shutdown(self) -> None:
        self.voice.stop()
        self.reminders.stop()

    # ------------------------------------------------------------ turns
    def _new_turn(self) -> tuple[int, threading.Event]:
        with self._lock:
            self.cancel_event.set()
            self.turn += 1
            self.cancel_event = threading.Event()
            self.speaker.cancel()
            self.speaker.begin(self.turn)
            self.turn_active = True
            turn, cancel = self.turn, self.cancel_event
        self.send({"type": "stop_audio"})
        return turn, cancel

    def interrupt(self) -> None:
        """Stop speaking/thinking immediately (barge-in, Stop button, Esc)."""
        with self._lock:
            self.cancel_event.set()
            self.turn += 1
            self.speaker.begin(self.turn)
            self.speaker.cancel()
            self.turn_active = False
        self._resolve_pending(False)
        self.voice.cancel_listen()
        self.send({"type": "stop_audio"})
        self.set_state("idle")

    def start_listening(self, timeout_s: float = 7.0) -> None:
        if not self.voice.active:
            self.status("The microphone is off. Turn it on with the mic button to talk to me.", "warning")
            return
        if self.state in ("speaking", "thinking") and not self.pending:
            self.interrupt()
        self.voice.request_listen(timeout_s)
        self.set_state("listening")

    # Called from the voice thread -------------------------------------
    def on_wake_word(self) -> None:
        log.info("Wake word detected")
        self.send({"type": "wake"})
        self.start_listening(7.0)

    def on_listen_timeout(self) -> None:
        if self.pending:
            self._resolve_pending(False)
            self.status("No answer, so I cancelled that action.")
        if self.state == "listening":
            self.set_state("idle")

    def on_utterance(self, audio: bytes) -> None:
        self.set_state("thinking")

        def work():
            try:
                text = self.stt.transcribe(audio)
            except STTError as exc:
                self.status(str(exc), "error")
                self.set_state("idle")
                return
            except Exception as exc:
                log.exception("STT failed")
                self.status(f"Speech recognition failed: {exc}", "error")
                self.set_state("idle")
                return
            if not text:
                if self.pending:
                    self.start_listening(8.0)
                else:
                    self.send({"type": "heard_nothing"})
                    self.set_state("idle")
                return
            self.handle_text(text, "voice")

        threading.Thread(target=work, daemon=True, name="stt").start()

    # Text entry point (voice or typed) --------------------------------
    def handle_text(self, text: str, source: str = "text") -> None:
        text = (text or "").strip()
        if not text:
            return
        self.send({"type": "transcript", "role": "user", "text": text, "source": source})
        if self.pending and not self.pending["event"].is_set():
            answer = router.parse_yes_no(text)
            if answer is None:
                self.status("I didn't hear a clear yes, so I cancelled that action.")
            self._resolve_pending(bool(answer))
            return
        if router.is_stop(text):
            self.interrupt()
            return
        self.last_source = source
        turn, cancel = self._new_turn()
        threading.Thread(target=self._run_turn, args=(text, turn, cancel), daemon=True,
                         name=f"turn-{turn}").start()

    def _run_turn(self, text: str, turn: int, cancel: threading.Event) -> None:
        self.set_state("thinking")
        speak = self.last_source != "text" or bool(self.settings.get("speak_typed_replies"))

        def say(sentence: str) -> None:
            if speak and not cancel.is_set():
                self.speaker.say(turn, sentence)

        try:
            intent = router.match(text)
            if intent and intent.tool in self.registry.tools:
                log.info("Router intent: %s %s", intent.tool, intent.args)
                self.send({"type": "tool", "name": intent.tool, "args": intent.args})
                result = self.registry.execute(intent.tool, intent.args, self._confirm_for(turn, cancel))
                if cancel.is_set():
                    return
                say(result.message)
                self._final(turn, result.message)
                self.history.add([{"role": "user", "content": text},
                                  {"role": "assistant", "content": result.message}])
            else:
                self._ask_llm(text, turn, cancel, say)
        except LLMError as exc:
            if not cancel.is_set():
                msg = str(exc)
                say(msg)
                self._final(turn, msg, error=True)
        except Exception as exc:
            log.exception("Turn failed")
            if not cancel.is_set():
                msg = "Sorry, something went wrong on my side."
                say(msg)
                self._final(turn, f"{msg} ({exc})", error=True)
        finally:
            with self._lock:
                current = turn == self.turn
                if current:
                    self.turn_active = False
            if current:
                self.speaker.end_segment(turn)
            self._save_transcript(text)

    def _final(self, turn: int, text: str, error: bool = False) -> None:
        self._last_reply = text
        self.send({"type": "transcript", "role": "assistant", "text": text, "turn": turn,
                   "final": True, "error": error})

    # ------------------------------------------------------------ AI model
    def _client(self) -> ChatClient:
        cfg = self.settings.llm_config()
        key = secrets.get_secret(cfg["key_name"]) if cfg["key_name"] else None
        label = LLM_PROVIDERS.get(cfg["provider"], {}).get("label", "the AI service").split(" (")[0]
        if cfg["key_name"] and not key:
            raise LLMError(
                f"To answer that I need an AI key. Open Settings, then AI, and add your {label} API key. "
                "I can still open apps and websites, tell the time, search, play music and set reminders.")
        return ChatClient(cfg["kind"], cfg["base_url"], cfg["model"], key, cfg["temperature"], label)

    def system_prompt(self) -> dict:
        now = datetime.now().astimezone()
        name = self.settings.get("assistant_name") or "NOVA"
        lang = LANG_NAMES.get((self.settings.get("language") or "en").split("-")[0], "English")
        roots = ", ".join(self.settings.get("files.allowed_roots") or [])
        content = f"""You are {name}, a personal AI voice assistant and companion running on the user's {platform.system()} laptop.
Personality: helpful, confident, polite and warm, with a subtle futuristic flair. Never robotic, never rude.
Current local date and time: {now.strftime('%A, %d %B %Y, %I:%M %p')} ({now.tzname()}).

How you talk:
- Your replies are spoken aloud by a text-to-speech voice. Write natural spoken sentences. No markdown headings, tables, bullet symbols or emoji.
- Keep answers short (one to three sentences) unless the user asks for detail. When explaining a hard topic, go step by step in plain language with a simple example.
- For code, say one sentence about it and put the code in a fenced code block. Code is shown on screen, not read aloud.
- Use the conversation so far to understand follow-up questions.
- Reply in {lang}.

Using the computer:
- Use the tools to open apps and websites, search the web, play music, manage reminders and work with files. Never claim you did something unless the tool result says ok.
- For current events, prices, news or facts you are unsure of, call web_search with open_browser=false and answer from the results.
- File tools only work inside these folders: {roots}.
- Actions that change files trigger a confirmation dialog automatically. Do not ask for permission yourself first - just call the tool; if the user declines, accept it gracefully.
- If a tool fails, explain briefly and suggest what the user can do."""
        return {"role": "system", "content": content}

    def _ask_llm(self, text: str, turn: int, cancel: threading.Event, say: Callable[[str], None]) -> None:
        client = self._client()
        tools = self.registry.schemas() if self.settings.get("llm.enable_tools") else None
        user_msg = {"role": "user", "content": text}
        turn_msgs: list[dict] = [user_msg]
        messages = [self.system_prompt()] + self.history.messages() + [user_msg]
        full = ""
        for _step in range(MAX_TOOL_STEPS):
            splitter = SentenceSplitter()
            acc = ""
            tool_calls = None
            for kind, value in client.stream(messages, tools, cancel):
                if cancel.is_set():
                    break
                if kind == "text":
                    acc += value
                    self.send({"type": "assistant_delta", "turn": turn, "text": value})
                    for sentence in splitter.feed(value):
                        say(sentence)
                elif kind == "tool_calls":
                    tool_calls = value
            if cancel.is_set():
                if acc or full:
                    self.history.add(turn_msgs + [{"role": "assistant", "content": (full + acc) + " [interrupted]"}])
                return
            for sentence in splitter.flush():
                say(sentence)
            full += acc
            if not tool_calls:
                turn_msgs.append({"role": "assistant", "content": acc})
                break
            asst = {"role": "assistant", "content": acc, "tool_calls": tool_calls}
            turn_msgs.append(asst)
            messages.append(asst)
            for tc in tool_calls:
                log.info("AI tool call: %s %s", tc["name"], tc["arguments"])
                self.send({"type": "tool", "name": tc["name"], "args": tc["arguments"]})
                result = self.registry.execute(tc["name"], tc["arguments"], self._confirm_for(turn, cancel))
                tool_msg = {"role": "tool", "tool_call_id": tc["id"], "name": tc["name"],
                            "content": result.for_model()}
                turn_msgs.append(tool_msg)
                messages.append(tool_msg)
                if cancel.is_set():
                    return
            if full and not full.endswith((" ", "\n")):
                full += " "
        else:
            say("Done.")
            full += "Done."
        self.history.add(turn_msgs)
        self._final(turn, full.strip() or "Done.")

    # ------------------------------------------------------------ confirmations
    def _confirm_for(self, turn: int, cancel: threading.Event):
        def confirm(title: str, detail: str) -> bool:
            return self._confirm(title, detail, turn, cancel)
        return confirm

    def _confirm(self, title: str, detail: str, turn: int, cancel: threading.Event, timeout_s: float = 60) -> bool:
        cid = uuid.uuid4().hex[:10]
        ev = threading.Event()
        with self._lock:
            self.pending = {"id": cid, "event": ev, "approved": False, "turn": turn}
        self.send({"type": "confirm", "id": cid, "title": title, "detail": detail})
        spoken = to_speech(detail)
        prompt = (f"Just to confirm: {spoken}. Should I go ahead?" if len(spoken) < 140
                  else "I need your permission for this action. Should I go ahead?")
        self.speaker.say(turn, prompt)
        self.speaker.end_segment(turn)
        waited = 0.0
        while not ev.wait(0.25):
            waited += 0.25
            if cancel.is_set() or waited >= timeout_s:
                break
        with self._lock:
            approved = bool(self.pending and self.pending["id"] == cid and self.pending["approved"])
            self.pending = None
        self.send({"type": "confirm_resolved", "id": cid, "approved": approved})
        if self.state == "listening" and not cancel.is_set():
            self.voice.cancel_listen()
            self.set_state("thinking")
        return approved

    def _resolve_pending(self, approved: bool, cid: str | None = None) -> None:
        with self._lock:
            p = self.pending
            if p and (cid is None or p["id"] == cid) and not p["event"].is_set():
                p["approved"] = approved
                p["event"].set()

    # ------------------------------------------------------------ playback events
    def on_playback_started(self, turn: int) -> None:
        if turn == self.turn:
            self.set_state("speaking")

    def on_playback_finished(self, turn: int) -> None:
        if turn != self.turn:
            return
        if self.pending:
            self.start_listening(8.0)
            return
        if self.turn_active:
            self.set_state("thinking")
            return
        follow = float(self.settings.get("follow_up_seconds") or 0)
        if self.last_source == "voice" and follow > 0 and self.voice.active:
            self.voice.request_listen(follow)
            self.set_state("listening")
            self.send({"type": "follow_up", "seconds": follow})
        else:
            self.set_state("idle")

    # ------------------------------------------------------------ reminders
    def _on_reminder_due(self, item: dict) -> None:
        self.send({"type": "notify", "title": "NOVA reminder", "body": item["message"]})
        self.send({"type": "reminders", "items": self.reminders.list()})
        if self.turn_active or self.state in ("listening", "thinking"):
            return  # don't talk over the user; the notification is enough
        turn, _cancel = self._new_turn()
        self.last_source = "system"
        self.speaker.say(turn, f"Reminder: {item['message']}.")
        self._final(turn, f"⏰ Reminder: {item['message']}")
        with self._lock:
            self.turn_active = False
        self.speaker.end_segment(turn)

    # ------------------------------------------------------------ settings
    def _on_settings_changed(self, change: dict) -> None:
        before, after = change["before"], change["after"]
        if before["mic"] != after["mic"]:
            self.voice.stop()
            if after["mic"]["enabled"]:
                if self.voice.start() and after["stt"]["provider"] == "faster_whisper":
                    self.stt.preload_async()
            self.send(self.mic_status())
        if before["wake_word"] != after["wake_word"]:
            self.voice.apply_settings()
        if before["stt"] != after["stt"] and after["stt"]["provider"] == "faster_whisper" and self.voice.active:
            self.stt.preload_async()
        self.history.max_turns = int(after["llm"]["max_history_turns"] or 20)

    def _save_transcript(self, user_text: str) -> None:
        if not self.settings.get("privacy.save_transcripts"):
            return
        try:
            folder = data_dir() / "transcripts"
            folder.mkdir(exist_ok=True)
            path = folder / f"{datetime.now():%Y-%m-%d}.jsonl"
            with path.open("a", encoding="utf-8") as f:
                f.write(json.dumps({"time": datetime.now().isoformat(timespec="seconds"), "user": user_text,
                                    "assistant": getattr(self, "_last_reply", "")}, ensure_ascii=False) + "\n")
        except Exception:
            log.exception("Could not save transcript")

    # ------------------------------------------------------------ UI messages
    def handle_ui(self, msg: dict) -> None:
        t = msg.get("type")
        if t == "start_listening":
            self.start_listening(float(msg.get("timeout", 7)))
        elif t == "stop_listening":
            self.voice.cancel_listen()
            if self.state == "listening":
                self.set_state("idle")
        elif t == "interrupt":
            self.interrupt()
        elif t == "text_input":
            self.handle_text(str(msg.get("text", ""))[:4000], "text")
        elif t == "playback_started":
            self.on_playback_started(int(msg.get("turn", -1)))
        elif t == "playback_finished":
            self.on_playback_finished(int(msg.get("turn", -1)))
        elif t == "set_mic":
            self.settings.update({"mic": {"enabled": bool(msg.get("enabled"))}})
            if not msg.get("enabled"):
                self.interrupt()
        elif t == "confirm_response":
            self._resolve_pending(bool(msg.get("approved")), str(msg.get("id")))
        elif t == "get_settings":
            self.send(self.hello())
        elif t == "update_settings":
            patch = msg.get("patch") or {}
            if isinstance(patch, dict):
                self.settings.update(patch)
            self.send({"type": "settings", "settings": self.settings.snapshot()})
            self.status("Settings saved.")
        elif t == "set_secret":
            name, value = str(msg.get("name")), str(msg.get("value", ""))
            try:
                secrets.set_secret(name, value)
                self.status(f"{name} saved securely in your system credential store.")
            except Exception as exc:
                self.status(f"Could not save the key: {exc}", "error")
            self.send({"type": "secrets", "secrets": secrets.secrets_status()})
        elif t == "delete_secret":
            name = str(msg.get("name"))
            if name in SECRET_NAMES:
                secrets.delete_secret(name)
                self.status(f"{name} removed.")
            self.send({"type": "secrets", "secrets": secrets.secrets_status()})
        elif t == "clear_conversation":
            self.interrupt()
            self.history.clear()
            self.send({"type": "conversation_cleared"})
        elif t == "list_reminders":
            self.send({"type": "reminders", "items": self.reminders.list()})
        elif t == "delete_reminder":
            self.reminders.remove(str(msg.get("id")))
            self.send({"type": "reminders", "items": self.reminders.list()})
        elif t == "test_voice":
            turn, _ = self._new_turn()
            self.last_source = "system"
            self.speaker.say(turn, "Hello, I'm NOVA. This is how my voice sounds. How can I help you today?")
            with self._lock:
                self.turn_active = False
            self.speaker.end_segment(turn)
        elif t == "ping":
            self.send({"type": "pong"})
        else:
            log.warning("Unknown UI message %r", t)
