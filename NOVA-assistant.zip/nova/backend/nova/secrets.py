"""Secure API-key handling.

Lookup order for a key such as ``GEMINI_API_KEY``:
  1. Environment variable (including values loaded from a local ``.env`` file)
  2. The operating system's credential store via ``keyring``
     (Windows Credential Manager / macOS Keychain / Secret Service on Linux)

Keys entered in the NOVA settings screen are written to the OS credential
store only. They are never written to settings.json, never logged and never
sent back to the user interface (the UI only learns whether a key is set).
"""
from __future__ import annotations

import logging
import os
from pathlib import Path

from .config import SECRET_NAMES, data_dir

log = logging.getLogger("nova.secrets")
SERVICE = "NOVA-Assistant"

try:
    import keyring  # type: ignore
    from keyring.errors import KeyringError  # type: ignore
except Exception:  # pragma: no cover - optional at import time
    keyring = None
    KeyringError = Exception  # type: ignore


def load_dotenv_files() -> None:
    """Load ``.env`` from the data dir and the backend folder, if present."""
    try:
        from dotenv import load_dotenv  # type: ignore
    except Exception:
        return
    for candidate in (data_dir() / ".env", Path(__file__).resolve().parent.parent / ".env"):
        if candidate.exists():
            load_dotenv(candidate, override=False)
            log.info("Loaded environment from %s", candidate)


def get_secret(name: str | None) -> str | None:
    if not name:
        return None
    value = os.environ.get(name)
    if value:
        return value.strip()
    if keyring is not None:
        try:
            value = keyring.get_password(SERVICE, name)
            if value:
                return value.strip()
        except KeyringError as exc:
            log.warning("Credential store unavailable: %s", exc)
        except Exception as exc:
            log.warning("Credential store error: %s", exc)
    return None


def set_secret(name: str, value: str) -> None:
    if name not in SECRET_NAMES:
        raise ValueError(f"Unknown secret name: {name}")
    value = (value or "").strip()
    if not value:
        raise ValueError("Empty key")
    if keyring is None:
        raise RuntimeError(
            "The 'keyring' package is not installed, so keys cannot be stored securely. "
            "Install it, or set the key as an environment variable / in a .env file."
        )
    keyring.set_password(SERVICE, name, value)


def delete_secret(name: str) -> None:
    if name not in SECRET_NAMES:
        raise ValueError(f"Unknown secret name: {name}")
    if keyring is None:
        return
    try:
        keyring.delete_password(SERVICE, name)
    except Exception:
        pass  # not set - nothing to delete


def secrets_status() -> dict[str, dict[str, bool | str]]:
    """Which keys are configured (never the values)."""
    out: dict[str, dict[str, bool | str]] = {}
    for name in SECRET_NAMES:
        source = ""
        if os.environ.get(name):
            source = "environment"
        elif keyring is not None:
            try:
                if keyring.get_password(SERVICE, name):
                    source = "credential store"
            except Exception:
                pass
        out[name] = {"set": bool(source), "source": source}
    return out
