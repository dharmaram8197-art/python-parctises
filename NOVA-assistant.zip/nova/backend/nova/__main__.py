"""Entry point: ``python -m nova`` (started automatically by the Electron app)."""
from __future__ import annotations

import argparse
import asyncio
import logging
import logging.handlers
import os
import secrets as pysecrets
import sys
import threading

from .config import Settings, data_dir


def setup_logging(verbose: bool) -> None:
    logs = data_dir() / "logs"
    logs.mkdir(exist_ok=True)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    file_handler = logging.handlers.RotatingFileHandler(logs / "backend.log", maxBytes=2_000_000,
                                                        backupCount=3, encoding="utf-8")
    file_handler.setFormatter(fmt)
    stream = logging.StreamHandler(sys.stderr)
    stream.setFormatter(fmt)
    root = logging.getLogger()
    root.setLevel(logging.DEBUG if verbose else logging.INFO)
    root.addHandler(file_handler)
    root.addHandler(stream)
    for noisy in ("httpx", "httpcore", "websockets", "faster_whisper", "urllib3"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


def watch_parent(stop) -> None:
    """Exit when Electron goes away (our stdin pipe closes)."""
    if sys.stdin is None:
        return

    def run():
        try:
            while sys.stdin.readline():
                pass
        except Exception:
            pass
        stop()

    threading.Thread(target=run, daemon=True, name="parent-watch").start()


def main() -> None:
    parser = argparse.ArgumentParser(description="NOVA backend")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=0, help="0 = pick a free port")
    parser.add_argument("--verbose", action="store_true")
    parser.add_argument("--no-parent-watch", action="store_true", help="for running standalone")
    args = parser.parse_args()

    setup_logging(args.verbose)
    log = logging.getLogger("nova")

    from . import secrets as nova_secrets
    from .assistant import Assistant

    nova_secrets.load_dotenv_files()
    token = os.environ.pop("NOVA_TOKEN", "") or pysecrets.token_urlsafe(24)
    if args.host not in ("127.0.0.1", "localhost", "::1"):
        log.warning("Binding to a non-local address is not recommended")

    settings = Settings()

    def on_ready(port: int) -> None:
        # Electron parses this line. The token is printed only for standalone dev use.
        print(f"NOVA_BACKEND_READY {port}", flush=True)
        if args.no_parent_watch:
            print(f"Standalone mode: connect with token {token}", flush=True)
        log.info("Backend listening on %s:%d", args.host, port)

    async def runner():
        stop = asyncio.Event()
        loop = asyncio.get_running_loop()
        if not args.no_parent_watch:
            watch_parent(lambda: loop.call_soon_threadsafe(stop.set))
        from .server import serve
        await serve(lambda send: Assistant(settings, send), token, args.host, args.port, on_ready, stop)

    try:
        asyncio.run(runner())
    except KeyboardInterrupt:
        pass
    log.info("Backend stopped")
    os._exit(0)  # don't wait for daemon audio threads


if __name__ == "__main__":
    main()
