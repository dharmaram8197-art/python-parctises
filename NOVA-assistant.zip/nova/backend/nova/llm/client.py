"""Streaming chat clients with tool (function) calling.

Internal message format (provider-neutral):
  {"role": "system"|"user", "content": str}
  {"role": "assistant", "content": str, "tool_calls": [{"id", "name", "arguments": dict}]}
  {"role": "tool", "tool_call_id": str, "name": str, "content": str}

``stream()`` yields events:
  ("text", str)               - a piece of the reply
  ("tool_calls", list[dict])  - the model wants tools run (id, name, arguments)
"""
from __future__ import annotations

import json
import logging
import threading
from typing import Any, Iterable, Iterator

log = logging.getLogger("nova.llm")


class LLMError(RuntimeError):
    pass


def _friendly_http_error(status: int, body: str, provider: str) -> LLMError:
    if status in (401, 403):
        return LLMError(f"The {provider} API key was rejected. Please check it in Settings.")
    if status == 429:
        return LLMError(f"{provider} is rate-limiting requests right now. Please try again shortly.")
    if status == 404:
        return LLMError(f"{provider} could not find that model. Check the model name in Settings.")
    if status >= 500:
        return LLMError(f"{provider} is having trouble right now (error {status}).")
    return LLMError(f"{provider} returned error {status}: {body[:200]}")


def _parse_args(raw: str) -> dict:
    if not raw:
        return {}
    try:
        val = json.loads(raw)
        return val if isinstance(val, dict) else {}
    except json.JSONDecodeError:
        return {}


def sse_data(lines: Iterable[str]) -> Iterator[dict]:
    """Yield JSON payloads from Server-Sent-Event ``data:`` lines."""
    for line in lines:
        if not line or not line.startswith("data:"):
            continue
        payload = line[5:].strip()
        if payload == "[DONE]":
            return
        try:
            yield json.loads(payload)
        except json.JSONDecodeError:
            continue


# ----------------------------------------------------------------------------
# OpenAI-compatible (OpenAI, Gemini, Groq, OpenRouter, Ollama, LM Studio, ...)
# ----------------------------------------------------------------------------
def to_openai_messages(messages: list[dict]) -> list[dict]:
    out = []
    for m in messages:
        if m["role"] == "assistant" and m.get("tool_calls"):
            out.append({
                "role": "assistant",
                "content": m.get("content") or None,
                "tool_calls": [
                    {"id": tc["id"], "type": "function",
                     "function": {"name": tc["name"], "arguments": json.dumps(tc["arguments"])}}
                    for tc in m["tool_calls"]
                ],
            })
        elif m["role"] == "tool":
            out.append({"role": "tool", "tool_call_id": m["tool_call_id"], "content": m["content"]})
        else:
            out.append({"role": m["role"], "content": m["content"]})
    return out


def parse_openai_stream(payloads: Iterable[dict]) -> Iterator[tuple[str, Any]]:
    calls: dict[int, dict] = {}
    for p in payloads:
        if p.get("error"):
            raise LLMError(str(p["error"].get("message", p["error"])) if isinstance(p["error"], dict) else str(p["error"]))
        for choice in p.get("choices") or []:
            delta = choice.get("delta") or {}
            if delta.get("content"):
                yield ("text", delta["content"])
            for i, tc in enumerate(delta.get("tool_calls") or []):
                idx = tc.get("index", i)
                slot = calls.setdefault(idx, {"id": "", "name": "", "args": ""})
                if tc.get("id"):
                    slot["id"] = tc["id"]
                fn = tc.get("function") or {}
                if fn.get("name"):
                    slot["name"] = fn["name"]
                if fn.get("arguments"):
                    args = fn["arguments"]
                    slot["args"] += args if isinstance(args, str) else json.dumps(args)
    if calls:
        result = []
        for idx in sorted(calls):
            c = calls[idx]
            if c["name"]:
                result.append({"id": c["id"] or f"call_{idx}", "name": c["name"],
                               "arguments": _parse_args(c["args"])})
        if result:
            yield ("tool_calls", result)


# ----------------------------------------------------------------------------
# Anthropic Messages API
# ----------------------------------------------------------------------------
def to_anthropic(messages: list[dict]) -> tuple[str, list[dict]]:
    system = "\n\n".join(m["content"] for m in messages if m["role"] == "system")
    out: list[dict] = []
    for m in messages:
        role = m["role"]
        if role == "system":
            continue
        if role == "tool":
            block = {"type": "tool_result", "tool_use_id": m["tool_call_id"], "content": m["content"]}
            if out and out[-1]["role"] == "user" and isinstance(out[-1]["content"], list) \
                    and all(b.get("type") == "tool_result" for b in out[-1]["content"]):
                out[-1]["content"].append(block)
            else:
                out.append({"role": "user", "content": [block]})
        elif role == "assistant" and m.get("tool_calls"):
            blocks: list[dict] = []
            if m.get("content"):
                blocks.append({"type": "text", "text": m["content"]})
            for tc in m["tool_calls"]:
                blocks.append({"type": "tool_use", "id": tc["id"], "name": tc["name"], "input": tc["arguments"]})
            out.append({"role": "assistant", "content": blocks})
        else:
            if out and out[-1]["role"] == role and isinstance(out[-1]["content"], str):
                out[-1]["content"] += "\n" + m["content"]  # API needs alternating roles
            else:
                out.append({"role": role, "content": m["content"] or "..."})
    return system, out


def parse_anthropic_stream(payloads: Iterable[dict]) -> Iterator[tuple[str, Any]]:
    blocks: dict[int, dict] = {}
    for p in payloads:
        t = p.get("type")
        if t == "error":
            raise LLMError(p.get("error", {}).get("message", "Anthropic stream error"))
        if t == "content_block_start":
            cb = p.get("content_block", {})
            if cb.get("type") == "tool_use":
                blocks[p["index"]] = {"id": cb.get("id"), "name": cb.get("name"), "json": ""}
        elif t == "content_block_delta":
            d = p.get("delta", {})
            if d.get("type") == "text_delta" and d.get("text"):
                yield ("text", d["text"])
            elif d.get("type") == "input_json_delta":
                if p["index"] in blocks:
                    blocks[p["index"]]["json"] += d.get("partial_json", "")
    if blocks:
        yield ("tool_calls", [
            {"id": b["id"], "name": b["name"], "arguments": _parse_args(b["json"])}
            for _, b in sorted(blocks.items())
        ])


# ----------------------------------------------------------------------------
class ChatClient:
    def __init__(self, kind: str, base_url: str, model: str, api_key: str | None,
                 temperature: float = 0.7, provider_label: str = "AI service"):
        self.kind = kind
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.api_key = api_key
        self.temperature = temperature
        self.label = provider_label

    def stream(self, messages: list[dict], tools: list[dict] | None,
               cancel: threading.Event | None = None) -> Iterator[tuple[str, Any]]:
        import httpx  # type: ignore

        if self.kind == "anthropic":
            system, msgs = to_anthropic(messages)
            url = self.base_url + "/messages"
            headers = {"x-api-key": self.api_key or "", "anthropic-version": "2023-06-01",
                       "content-type": "application/json"}
            body: dict[str, Any] = {"model": self.model, "max_tokens": 1500, "system": system,
                                    "messages": msgs, "stream": True, "temperature": self.temperature}
            if tools:
                body["tools"] = [{"name": t["name"], "description": t["description"],
                                  "input_schema": t["parameters"]} for t in tools]
            parser = parse_anthropic_stream
        else:
            url = self.base_url + "/chat/completions"
            headers = {"content-type": "application/json"}
            if self.api_key:
                headers["authorization"] = f"Bearer {self.api_key}"
            body = {"model": self.model, "messages": to_openai_messages(messages), "stream": True,
                    "temperature": self.temperature}
            if tools:
                body["tools"] = [{"type": "function", "function": t} for t in tools]
                body["tool_choice"] = "auto"
            parser = parse_openai_stream

        timeout = httpx.Timeout(60.0, connect=10.0)
        try:
            with httpx.stream("POST", url, headers=headers, json=body, timeout=timeout) as resp:
                if resp.status_code != 200:
                    text = resp.read().decode("utf-8", "replace")
                    if tools and resp.status_code == 400 and "tool" in text.lower():
                        log.warning("Model rejected tools; retrying without them")
                        resp.close()
                        yield from self.stream(messages, None, cancel)
                        return
                    raise _friendly_http_error(resp.status_code, text, self.label)

                def lines():
                    for line in resp.iter_lines():
                        if cancel is not None and cancel.is_set():
                            return
                        yield line

                yield from parser(sse_data(lines()))
        except httpx.ConnectError as exc:
            raise LLMError(f"I can't reach {self.label}. Check your internet connection"
                           + (" or that Ollama is running." if "localhost" in self.base_url else ".")) from exc
        except httpx.TimeoutException as exc:
            raise LLMError(f"{self.label} took too long to respond.") from exc
        except httpx.HTTPError as exc:
            raise LLMError(f"Network error talking to {self.label}: {exc}") from exc
