"""Microphone capture: delivers 16 kHz mono int16 frames of 30 ms."""
from __future__ import annotations

import logging
import queue

import numpy as np

from .vad import FRAME_SAMPLES, SAMPLE_RATE

log = logging.getLogger("nova.mic")


class _Rechunker:
    """Resamples arbitrary-rate float/int audio to 16 kHz and cuts 30 ms frames."""

    def __init__(self, src_rate: int):
        self.src_rate = src_rate
        self.buf = np.zeros(0, dtype=np.int16)

    def push(self, samples: np.ndarray) -> list[bytes]:
        if self.src_rate != SAMPLE_RATE and samples.size:
            n_out = int(round(samples.size * SAMPLE_RATE / self.src_rate))
            if n_out <= 0:
                return []
            x_old = np.linspace(0.0, 1.0, num=samples.size, endpoint=False)
            x_new = np.linspace(0.0, 1.0, num=n_out, endpoint=False)
            samples = np.interp(x_new, x_old, samples.astype(np.float32)).astype(np.int16)
        self.buf = np.concatenate([self.buf, samples.astype(np.int16)])
        out = []
        while self.buf.size >= FRAME_SAMPLES:
            out.append(self.buf[:FRAME_SAMPLES].tobytes())
            self.buf = self.buf[FRAME_SAMPLES:]
        return out


class Microphone:
    def __init__(self, out_queue: "queue.Queue[bytes]", device: int | str | None = None):
        self.q = out_queue
        self.device = device
        self.stream = None
        self.sample_rate = SAMPLE_RATE
        self.dropped = 0

    @staticmethod
    def list_devices() -> list[dict]:
        try:
            import sounddevice as sd  # type: ignore
        except Exception:
            return []
        devices = []
        for idx, dev in enumerate(sd.query_devices()):
            if dev.get("max_input_channels", 0) > 0:
                devices.append({"index": idx, "name": dev["name"]})
        return devices

    def _put(self, frame: bytes) -> None:
        try:
            self.q.put_nowait(frame)
        except queue.Full:
            self.dropped += 1

    def start(self) -> None:
        import sounddevice as sd  # type: ignore

        try:
            chunker = _Rechunker(SAMPLE_RATE)

            def cb16(indata, frames, time_info, status):  # noqa: ARG001
                for fr in chunker.push(np.frombuffer(bytes(indata), dtype=np.int16)):
                    self._put(fr)

            self.stream = sd.RawInputStream(
                samplerate=SAMPLE_RATE, channels=1, dtype="int16",
                blocksize=FRAME_SAMPLES, device=self.device, callback=cb16,
            )
            self.stream.start()
            self.sample_rate = SAMPLE_RATE
            log.info("Microphone opened at 16 kHz")
            return
        except Exception as exc:
            log.info("16 kHz capture not supported (%s); using device rate", exc)
            self.stream = None

        info = sd.query_devices(self.device, "input")
        rate = int(info["default_samplerate"])
        chunker = _Rechunker(rate)

        def cbn(indata, frames, time_info, status):  # noqa: ARG001
            mono = indata[:, 0] if indata.ndim > 1 else indata
            for fr in chunker.push((mono * 32767).astype(np.int16)):
                self._put(fr)

        self.stream = sd.InputStream(
            samplerate=rate, channels=1, dtype="float32",
            blocksize=int(rate * 0.03), device=self.device, callback=cbn,
        )
        self.stream.start()
        self.sample_rate = rate
        log.info("Microphone opened at %d Hz (resampling to 16 kHz)", rate)

    def stop(self) -> None:
        if self.stream is not None:
            try:
                self.stream.stop()
                self.stream.close()
            except Exception:
                pass
            self.stream = None

    @property
    def active(self) -> bool:
        return self.stream is not None
