"""Always-on voice loop: microphone -> wake word -> utterance recording."""
from __future__ import annotations

import logging
import queue
import threading
import time

from .capture import Microphone
from .vad import NoiseFloor, Recorder, rms
from .wakeword import WakeWordDetector

log = logging.getLogger("nova.voice")


class VoicePipeline:
    def __init__(self, assistant):
        self.a = assistant
        self.q: "queue.Queue[bytes]" = queue.Queue(maxsize=400)
        self.mic: Microphone | None = None
        self.wake: WakeWordDetector | None = None
        self.noise = NoiseFloor()
        self.recorder: Recorder | None = None
        self._listen_request: float | None = None
        self._cancel_request = False
        self._running = False
        self._thread: threading.Thread | None = None
        self._last_level_sent = 0.0
        self._wake_loading = False

    # -- lifecycle ---------------------------------------------------------
    def start(self) -> bool:
        if self.mic and self.mic.active:
            return True
        self.mic = Microphone(self.q, self.a.settings.get("mic.device"))
        try:
            self.mic.start()
        except Exception as exc:
            log.error("Microphone error: %s", exc)
            self.mic = None
            self.a.status(f"I can't access the microphone: {exc}", "error")
            return False
        self._running = True
        if self._thread is None or not self._thread.is_alive():
            self._thread = threading.Thread(target=self._loop, daemon=True, name="voice")
            self._thread.start()
        self._ensure_wake_word()
        return True

    def stop(self) -> None:
        self._running = False
        if self.mic:
            self.mic.stop()
            self.mic = None
        self.recorder = None
        with self.q.mutex:
            self.q.queue.clear()

    @property
    def active(self) -> bool:
        return bool(self.mic and self.mic.active)

    def _ensure_wake_word(self) -> None:
        if not self.a.settings.get("wake_word.enabled") or self.wake is not None or self._wake_loading:
            return
        self._wake_loading = True

        def load():
            try:
                det = WakeWordDetector(self.a.settings.get("wake_word.phrases") or ["hey nova"])
                det.load(progress=lambda m: self.a.status(m))
                self.wake = det
                self.a.status("Wake word ready - say \"Hey Nova\".")
            except ImportError:
                self.a.status("Wake word needs the 'vosk' package. You can still use the Talk button "
                              "or Ctrl+Alt+N.", "warning")
            except Exception as exc:
                log.error("Wake word failed: %s", exc)
                self.a.status(f"Wake word unavailable ({exc}). Use the Talk button or Ctrl+Alt+N.", "warning")
            finally:
                self._wake_loading = False

        threading.Thread(target=load, daemon=True, name="wake-load").start()

    def apply_settings(self) -> None:
        if self.wake is not None:
            self.wake.set_phrases(self.a.settings.get("wake_word.phrases") or ["hey nova"])
        self._ensure_wake_word()

    # -- requests from the assistant (thread-safe flag passing) -----------
    def request_listen(self, timeout_s: float = 7.0) -> None:
        self._cancel_request = False
        self._listen_request = timeout_s

    def cancel_listen(self) -> None:
        self._listen_request = None
        self._cancel_request = True

    @property
    def listening(self) -> bool:
        return self.recorder is not None

    # -- main loop ---------------------------------------------------------
    def _loop(self) -> None:
        while True:
            if not self._running:
                time.sleep(0.1)
                continue
            try:
                frame = self.q.get(timeout=0.2)
            except queue.Empty:
                frame = None

            if self._cancel_request:
                self._cancel_request = False
                self.recorder = None
            if self._listen_request is not None:
                timeout = self._listen_request
                self._listen_request = None
                self.recorder = Recorder(
                    threshold=self.noise.threshold(),
                    start_timeout_s=timeout,
                    silence_ms=int(self.a.settings.get("mic.silence_ms") or 900),
                    max_utterance_s=float(self.a.settings.get("mic.max_utterance_s") or 20),
                )
            if frame is None:
                continue

            level = rms(frame)
            now = time.monotonic()
            interval = 0.066 if self.recorder else 0.25
            if now - self._last_level_sent >= interval:
                self._last_level_sent = now
                self.a.send({"type": "level", "value": round(min(1.0, level / 4000.0), 3),
                             "listening": self.recorder is not None})

            if self.recorder is not None:
                status = self.recorder.feed(frame)
                if status == "timeout":
                    self.recorder = None
                    self.a.on_listen_timeout()
                elif status == "done":
                    audio = self.recorder.audio()
                    self.recorder = None
                    if self.wake:
                        self.wake.reset()
                    self.a.on_utterance(audio)
                continue

            state = self.a.state
            if state == "idle":
                self.noise.update(level)
            if self.wake is not None and self.a.settings.get("wake_word.enabled") \
                    and state in ("idle", "speaking", "thinking"):
                try:
                    if self.wake.accept(frame):
                        self.a.on_wake_word()
                except Exception as exc:
                    log.error("Wake word error: %s", exc)
                    self.wake = None
