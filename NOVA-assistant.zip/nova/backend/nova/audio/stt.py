"""Speech-to-text.

Providers:
  * ``faster_whisper`` - runs Whisper locally (offline, private). Default.
  * ``openai_compatible`` - any /audio/transcriptions endpoint
    (Groq's free Whisper, OpenAI, ...).
"""
from __future__ import annotations

import io
import logging
import threading
import wave

import numpy as np

from .. import secrets
from .vad import SAMPLE_RATE

log = logging.getLogger("nova.stt")

# Whisper tends to "hear" these in near-silence.
_HALLUCINATIONS = {
    "", "you", "thank you", "thank you.", "thanks for watching!", "thanks for watching",
    "bye.", "bye", ".", "thank you for watching.", "subtitles by the amara.org community",
}


class STTError(RuntimeError):
    pass


def pcm_to_wav(pcm: bytes, rate: int = SAMPLE_RATE) -> bytes:
    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(rate)
        wf.writeframes(pcm)
    return buf.getvalue()


def clean_transcript(text: str, duration_s: float) -> str:
    text = " ".join(text.split()).strip()
    if text.lower() in _HALLUCINATIONS and duration_s < 2.5:
        return ""
    return text


class SpeechToText:
    def __init__(self, settings, status_cb=None):
        self.settings = settings
        self.status_cb = status_cb or (lambda msg, level="info": None)
        self._model = None
        self._model_key = None
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    def preload_async(self) -> None:
        threading.Thread(target=self._safe_preload, daemon=True, name="stt-preload").start()

    def _safe_preload(self) -> None:
        try:
            if self.settings.get("stt.provider") == "faster_whisper":
                self._local_model()
        except Exception as exc:
            log.error("Speech model failed to load: %s", exc)
            self.status_cb(f"Speech recognition model failed to load: {exc}", "error")

    def _local_model(self):
        cfg = self.settings.get("stt")
        key = (cfg["model"],)
        with self._lock:
            if self._model is not None and self._model_key == key:
                return self._model
            try:
                from faster_whisper import WhisperModel  # type: ignore
            except Exception as exc:
                raise STTError(
                    "faster-whisper is not installed. Run: pip install faster-whisper "
                    "or switch speech recognition to an online provider in Settings."
                ) from exc
            self.status_cb(f"Loading speech model '{cfg['model']}' (first run downloads it)...")
            try:
                model = WhisperModel(cfg["model"], device="auto", compute_type="int8")
            except Exception:
                log.info("Falling back to CPU for Whisper")
                model = WhisperModel(cfg["model"], device="cpu", compute_type="int8")
            self._model, self._model_key = model, key
            self.status_cb("Speech recognition ready.")
            return model

    # ------------------------------------------------------------------
    def transcribe(self, pcm: bytes) -> str:
        duration = len(pcm) / 2 / SAMPLE_RATE
        if duration < 0.25:
            return ""
        provider = self.settings.get("stt.provider")
        lang = (self.settings.get("language") or "en").split("-")[0]
        if provider == "openai_compatible":
            text = self._transcribe_api(pcm, lang)
        else:
            text = self._transcribe_local(pcm, lang)
        return clean_transcript(text, duration)

    def _transcribe_local(self, pcm: bytes, lang: str) -> str:
        model = self._local_model()
        audio = np.frombuffer(pcm, dtype=np.int16).astype(np.float32) / 32768.0
        model_name = self.settings.get("stt.model") or ""
        segments, _info = model.transcribe(
            audio,
            language=None if model_name.endswith(".en") and lang == "en" else lang,
            beam_size=1,
            condition_on_previous_text=False,
            vad_filter=False,
            initial_prompt="Hey Nova.",
        )
        return " ".join(s.text for s in segments)

    def _transcribe_api(self, pcm: bytes, lang: str) -> str:
        import httpx  # type: ignore

        cfg = self.settings.get("stt")
        key = secrets.get_secret(cfg.get("key_name"))
        if not key:
            raise STTError(f"No API key for speech recognition ({cfg.get('key_name')}). Add it in Settings.")
        model = cfg["model"] if cfg["model"] and "." not in cfg["model"] else "whisper-large-v3-turbo"
        url = cfg["base_url"].rstrip("/") + "/audio/transcriptions"
        try:
            r = httpx.post(
                url,
                headers={"Authorization": f"Bearer {key}"},
                files={"file": ("speech.wav", pcm_to_wav(pcm), "audio/wav")},
                data={"model": model, "language": lang, "response_format": "json"},
                timeout=30,
            )
        except httpx.HTTPError as exc:
            raise STTError(f"Could not reach the speech service: {exc}") from exc
        if r.status_code != 200:
            raise STTError(f"Speech service error {r.status_code}: {r.text[:200]}")
        return r.json().get("text", "")
