"""Voice-activity detection and utterance end-pointing.

Works with plain energy detection; if ``webrtcvad`` (package
``webrtcvad-wheels``) is installed it is combined with the energy gate for
more robust detection in noisy rooms.
"""
from __future__ import annotations

import collections
import math

import numpy as np

SAMPLE_RATE = 16000
FRAME_MS = 30
FRAME_SAMPLES = SAMPLE_RATE * FRAME_MS // 1000  # 480
FRAME_BYTES = FRAME_SAMPLES * 2

try:  # optional
    import webrtcvad  # type: ignore
except Exception:  # pragma: no cover
    webrtcvad = None


def rms(frame: bytes) -> float:
    if not frame:
        return 0.0
    a = np.frombuffer(frame, dtype=np.int16).astype(np.float32)
    return float(math.sqrt(float(np.mean(a * a)))) if a.size else 0.0


class NoiseFloor:
    """Slowly-adapting estimate of the background noise level."""

    def __init__(self, initial: float = 120.0):
        self.value = initial

    def update(self, level: float) -> None:
        # Adapt quickly downward, slowly upward (speech should not raise the floor much)
        alpha = 0.05 if level < self.value else 0.005
        self.value = (1 - alpha) * self.value + alpha * level
        self.value = min(max(self.value, 30.0), 3000.0)

    def threshold(self) -> float:
        return max(self.value * 2.8, 260.0)


class Recorder:
    """Collects one utterance.

    ``feed`` returns ``None`` while recording, ``"timeout"`` when no speech
    started within ``start_timeout_s`` and ``"done"`` when speech ended.
    """

    def __init__(
        self,
        threshold: float,
        start_timeout_s: float = 6.0,
        silence_ms: int = 900,
        max_utterance_s: float = 20.0,
        preroll_ms: int = 300,
        vad_aggressiveness: int = 2,
    ):
        self.threshold = threshold
        self.start_frames = int(start_timeout_s * 1000 / FRAME_MS)
        self.silence_frames = max(1, int(silence_ms / FRAME_MS))
        self.max_frames = int(max_utterance_s * 1000 / FRAME_MS)
        self.preroll: collections.deque[bytes] = collections.deque(maxlen=max(1, preroll_ms // FRAME_MS))
        self.frames: list[bytes] = []
        self.started = False
        self.consecutive_speech = 0
        self.silence_run = 0
        self.frames_seen = 0
        self.speech_frames = 0
        self.vad = None
        if webrtcvad is not None:
            try:
                self.vad = webrtcvad.Vad(vad_aggressiveness)
            except Exception:
                self.vad = None

    def is_speech(self, frame: bytes) -> bool:
        level = rms(frame)
        if self.vad is not None and len(frame) == FRAME_BYTES:
            try:
                return self.vad.is_speech(frame, SAMPLE_RATE) and level > self.threshold * 0.6
            except Exception:
                pass
        return level > self.threshold

    def feed(self, frame: bytes) -> str | None:
        self.frames_seen += 1
        speech = self.is_speech(frame)
        if not self.started:
            self.preroll.append(frame)
            self.consecutive_speech = self.consecutive_speech + 1 if speech else 0
            if self.consecutive_speech >= 3:  # ~90 ms of speech
                self.started = True
                self.frames.extend(self.preroll)
                self.preroll.clear()
                self.speech_frames = self.consecutive_speech
                return None
            if self.frames_seen >= self.start_frames:
                return "timeout"
            return None

        self.frames.append(frame)
        if speech:
            self.speech_frames += 1
            self.silence_run = 0
        else:
            self.silence_run += 1
        if self.silence_run >= self.silence_frames:
            return "done"
        if len(self.frames) >= self.max_frames:
            return "done"
        return None

    def audio(self) -> bytes:
        # Trim most of the trailing silence
        keep = len(self.frames) - max(0, self.silence_run - 5)
        return b"".join(self.frames[:keep])

    def duration_s(self) -> float:
        return len(self.frames) * FRAME_MS / 1000.0
