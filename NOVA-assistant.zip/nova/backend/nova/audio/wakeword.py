"""Offline "Hey Nova" wake-word detection using a grammar-restricted Vosk model.

The small English Vosk model (~40 MB) is downloaded automatically on first
run into ``<data dir>/models``. Restricting the recognizer grammar to the
wake phrases keeps CPU usage low and false triggers rare. Nothing leaves the
computer while NOVA waits for the wake word.
"""
from __future__ import annotations

import difflib
import json
import logging
import os
import shutil
import time
import urllib.request
import zipfile
from pathlib import Path
from typing import Callable

from ..config import data_dir
from .vad import SAMPLE_RATE

log = logging.getLogger("nova.wake")

MODEL_NAME = "vosk-model-small-en-us-0.15"
MODEL_URL = f"https://alphacephei.com/vosk/models/{MODEL_NAME}.zip"


def model_path() -> Path:
    env = os.environ.get("NOVA_VOSK_MODEL")
    if env:
        return Path(env)
    return data_dir() / "models" / MODEL_NAME


def ensure_model(progress: Callable[[str], None] | None = None) -> Path:
    path = model_path()
    if (path / "am").exists() or (path / "conf").exists():
        return path
    path.parent.mkdir(parents=True, exist_ok=True)
    zip_path = path.parent / f"{MODEL_NAME}.zip"
    if progress:
        progress("Downloading wake-word model (about 40 MB, one time only)...")
    log.info("Downloading %s", MODEL_URL)
    last = [0.0]

    def hook(blocks, block_size, total):
        if progress and total > 0 and time.time() - last[0] > 1.0:
            last[0] = time.time()
            pct = min(100, int(blocks * block_size * 100 / total))
            progress(f"Downloading wake-word model... {pct}%")

    tmp = zip_path.with_suffix(".part")
    urllib.request.urlretrieve(MODEL_URL, tmp, reporthook=hook)  # noqa: S310 (fixed https URL)
    tmp.replace(zip_path)
    with zipfile.ZipFile(zip_path) as zf:
        root = path.parent.resolve()
        for member in zf.namelist():  # guard against path traversal
            if not (root / member).resolve().is_relative_to(root):
                raise RuntimeError("Unsafe path in model archive")
        zf.extractall(path.parent)
    zip_path.unlink(missing_ok=True)
    if not path.exists():
        raise RuntimeError("Wake-word model archive had an unexpected layout")
    return path


def normalize(text: str) -> str:
    return " ".join("".join(c if c.isalnum() or c.isspace() else " " for c in text.lower()).split())


class WakeWordDetector:
    def __init__(self, phrases: list[str], cooldown_s: float = 1.5):
        self.phrases = [normalize(p) for p in phrases if p.strip()] or ["hey nova"]
        self.cooldown_s = cooldown_s
        self._last = 0.0
        self.model = None
        self.rec = None
        self.free_form = False  # True if a wake word isn't in the model's vocabulary

    def load(self, progress: Callable[[str], None] | None = None) -> None:
        from vosk import KaldiRecognizer, Model, SetLogLevel  # type: ignore

        SetLogLevel(-1)
        path = ensure_model(progress)
        self.model = Model(str(path))
        self._KaldiRecognizer = KaldiRecognizer
        self._make_recognizer()
        log.info("Wake word ready: %s", self.phrases)

    def _make_recognizer(self) -> None:
        missing = []
        if hasattr(self.model, "find_word"):
            missing = [w for p in self.phrases for w in p.split() if self.model.find_word(w) == -1]
        self.free_form = bool(missing)
        if self.free_form:
            # Unknown word: recognise freely and fuzzy-match the wake phrase instead.
            log.warning("Words not in wake model vocabulary: %s - using fuzzy matching", missing)
            self.rec = self._KaldiRecognizer(self.model, SAMPLE_RATE)
        else:
            words = sorted(set(self.phrases)) + ["[unk]"]
            self.rec = self._KaldiRecognizer(self.model, SAMPLE_RATE, json.dumps(words))

    def set_phrases(self, phrases: list[str]) -> None:
        self.phrases = [normalize(p) for p in phrases if p.strip()] or ["hey nova"]
        if self.model is not None:
            self._make_recognizer()

    @property
    def ready(self) -> bool:
        return self.rec is not None

    def matches(self, text: str) -> bool:
        t = normalize(text)
        if any(p in t for p in self.phrases):
            return True
        if not self.free_form:
            return False
        words = t.split()
        for p in self.phrases:
            n = len(p.split())
            for size in (n, n + 1):
                for i in range(0, max(1, len(words) - size + 1)):
                    window = " ".join(words[i:i + size])
                    if difflib.SequenceMatcher(None, p, window).ratio() >= 0.8:
                        return True
        return False

    def accept(self, frame: bytes) -> bool:
        if self.rec is None:
            return False
        if self.rec.AcceptWaveform(frame):
            text = json.loads(self.rec.Result()).get("text", "")
        else:
            text = json.loads(self.rec.PartialResult()).get("partial", "")
        if text and self.matches(text):
            self.rec.Reset()
            now = time.monotonic()
            if now - self._last >= self.cooldown_s:
                self._last = now
                return True
        return False

    def reset(self) -> None:
        if self.rec is not None:
            self.rec.Reset()


def remove_model() -> None:
    shutil.rmtree(model_path(), ignore_errors=True)
