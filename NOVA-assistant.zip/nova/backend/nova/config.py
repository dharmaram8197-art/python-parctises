"""Settings storage for NOVA.

Settings (non-secret) live in a JSON file in the per-user data directory.
API keys are NEVER stored here - see ``nova.secrets``.
"""
from __future__ import annotations

import copy
import json
import logging
import os
import sys
import threading
from pathlib import Path
from typing import Any, Callable

log = logging.getLogger("nova.config")

APP_NAME = "NOVA"


def data_dir() -> Path:
    """Per-user data folder (settings, reminders, downloaded models)."""
    override = os.environ.get("NOVA_DATA_DIR")
    if override:
        p = Path(override)
    elif sys.platform == "win32":
        p = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming")) / APP_NAME / "data"
    elif sys.platform == "darwin":
        p = Path.home() / "Library" / "Application Support" / APP_NAME / "data"
    else:
        p = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / APP_NAME / "data"
    p.mkdir(parents=True, exist_ok=True)
    return p


def _home_folder(name: str) -> str:
    return str(Path.home() / name)


# Presets for AI providers. Every "openai" kind provider speaks the
# OpenAI-compatible /chat/completions API.
LLM_PROVIDERS: dict[str, dict[str, Any]] = {
    "gemini": {
        "label": "Google Gemini (free tier available)",
        "kind": "openai",
        "base_url": "https://generativelanguage.googleapis.com/v1beta/openai",
        "key_name": "GEMINI_API_KEY",
        "model": "gemini-2.5-flash",
    },
    "groq": {
        "label": "Groq (free tier available)",
        "kind": "openai",
        "base_url": "https://api.groq.com/openai/v1",
        "key_name": "GROQ_API_KEY",
        "model": "llama-3.3-70b-versatile",
    },
    "openai": {
        "label": "OpenAI",
        "kind": "openai",
        "base_url": "https://api.openai.com/v1",
        "key_name": "OPENAI_API_KEY",
        "model": "gpt-4o-mini",
    },
    "anthropic": {
        "label": "Anthropic Claude",
        "kind": "anthropic",
        "base_url": "https://api.anthropic.com/v1",
        "key_name": "ANTHROPIC_API_KEY",
        "model": "claude-sonnet-5-5",
    },
    "openrouter": {
        "label": "OpenRouter",
        "kind": "openai",
        "base_url": "https://openrouter.ai/api/v1",
        "key_name": "OPENROUTER_API_KEY",
        "model": "openai/gpt-4o-mini",
    },
    "ollama": {
        "label": "Ollama (local, offline)",
        "kind": "openai",
        "base_url": "http://localhost:11434/v1",
        "key_name": None,
        "model": "llama3.1",
    },
}

SECRET_NAMES = [
    "GEMINI_API_KEY",
    "GROQ_API_KEY",
    "OPENAI_API_KEY",
    "ANTHROPIC_API_KEY",
    "OPENROUTER_API_KEY",
]

MALE_VOICES = {
    # edge-tts neural voices (male)
    "en-US-AndrewNeural": "Andrew (US) - warm, natural",
    "en-US-BrianNeural": "Brian (US) - friendly",
    "en-US-ChristopherNeural": "Christopher (US) - confident",
    "en-US-GuyNeural": "Guy (US) - classic",
    "en-US-EricNeural": "Eric (US)",
    "en-GB-RyanNeural": "Ryan (UK)",
    "en-IN-PrabhatNeural": "Prabhat (India)",
    "en-AU-WilliamNeural": "William (Australia)",
    "hi-IN-MadhurNeural": "Madhur (Hindi)",
}

DEFAULTS: dict[str, Any] = {
    "assistant_name": "NOVA",
    "language": "en",
    "wake_word": {
        "enabled": True,
        "phrases": ["hey nova", "hi nova", "okay nova"],
    },
    "follow_up_seconds": 6,
    "speak_typed_replies": True,
    "mic": {
        "enabled": True,
        "device": None,          # None = system default input
        "silence_ms": 900,
        "max_utterance_s": 20,
    },
    "stt": {
        "provider": "faster_whisper",   # faster_whisper | openai_compatible
        "model": "base.en",             # whisper model size, or API model name
        "base_url": "https://api.groq.com/openai/v1",
        "key_name": "GROQ_API_KEY",
    },
    "tts": {
        "provider": "edge",             # edge | openai | system
        "voice": "en-US-AndrewNeural",
        "rate": "+0%",
        "pitch": "-2Hz",
        "openai_voice": "onyx",
        "openai_model": "gpt-4o-mini-tts",
    },
    "llm": {
        "provider": "gemini",
        "model": "",                    # empty = provider default
        "base_url": "",                 # empty = provider default
        "temperature": 0.7,
        "max_history_turns": 20,
        "enable_tools": True,
    },
    "privacy": {
        "save_transcripts": False,
    },
    "files": {
        "allowed_roots": [
            _home_folder("Documents"),
            _home_folder("Desktop"),
            _home_folder("Downloads"),
        ],
    },
    "music": {
        "folder": _home_folder("Music"),
        "online_service": "youtube",    # youtube | youtube_music | spotify
    },
}


def _deep_merge(base: dict, patch: dict, schema: dict) -> dict:
    """Merge ``patch`` into ``base`` keeping only keys/types known in ``schema``."""
    out = copy.deepcopy(base)
    for key, value in patch.items():
        if key not in schema:
            log.warning("Ignoring unknown setting %r", key)
            continue
        ref = schema[key]
        if isinstance(ref, dict):
            if isinstance(value, dict):
                out[key] = _deep_merge(out.get(key, {}), value, ref)
            continue
        if ref is None:
            out[key] = value if (value is None or isinstance(value, (str, int))) else ref
        elif isinstance(ref, bool):
            if isinstance(value, bool):
                out[key] = value
        elif isinstance(ref, (int, float)) and not isinstance(ref, bool):
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                out[key] = type(ref)(value) if isinstance(ref, float) else value
        elif isinstance(ref, list):
            if isinstance(value, list) and all(isinstance(v, str) for v in value):
                out[key] = value
        elif isinstance(ref, str):
            if isinstance(value, str):
                out[key] = value
    return out


class Settings:
    """Thread-safe settings with change listeners."""

    def __init__(self, path: Path | None = None):
        self.path = path or (data_dir() / "settings.json")
        self._lock = threading.RLock()
        self._data = copy.deepcopy(DEFAULTS)
        self._listeners: list[Callable[[dict], None]] = []
        self.load()

    def load(self) -> None:
        if self.path.exists():
            try:
                stored = json.loads(self.path.read_text(encoding="utf-8"))
                with self._lock:
                    self._data = _deep_merge(DEFAULTS, stored, DEFAULTS)
            except Exception as exc:  # corrupt file -> keep defaults, keep a backup
                log.error("Could not read settings (%s); using defaults", exc)
                try:
                    self.path.replace(self.path.with_suffix(".corrupt.json"))
                except OSError:
                    pass

    def save(self) -> None:
        with self._lock:
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(json.dumps(self._data, indent=2), encoding="utf-8")
            tmp.replace(self.path)

    def snapshot(self) -> dict:
        with self._lock:
            return copy.deepcopy(self._data)

    def get(self, dotted: str, default: Any = None) -> Any:
        with self._lock:
            cur: Any = self._data
            for part in dotted.split("."):
                if not isinstance(cur, dict) or part not in cur:
                    return default
                cur = cur[part]
            return copy.deepcopy(cur)

    def update(self, patch: dict) -> dict:
        with self._lock:
            before = copy.deepcopy(self._data)
            self._data = _deep_merge(self._data, patch, DEFAULTS)
            self.save()
            after = copy.deepcopy(self._data)
        for fn in list(self._listeners):
            try:
                fn({"before": before, "after": after})
            except Exception:
                log.exception("Settings listener failed")
        return after

    def on_change(self, fn: Callable[[dict], None]) -> None:
        self._listeners.append(fn)

    # -- convenience -------------------------------------------------------
    def llm_config(self) -> dict:
        llm = self.get("llm")
        preset = LLM_PROVIDERS.get(llm["provider"], LLM_PROVIDERS["gemini"])
        return {
            "provider": llm["provider"],
            "kind": preset["kind"],
            "base_url": llm["base_url"] or preset["base_url"],
            "key_name": preset["key_name"],
            "model": llm["model"] or preset["model"],
            "temperature": llm["temperature"],
        }
