"""Text-to-speech with a natural male voice.

Providers:
  * ``edge``   - Microsoft neural voices through ``edge-tts`` (free, needs internet).
  * ``openai`` - OpenAI TTS (``onyx`` is a deep male voice; needs OPENAI_API_KEY).
  * ``system`` - offline OS voice via ``pyttsx3`` (Windows: "Microsoft David").

If the chosen provider fails, NOVA falls back to the offline system voice,
and if that fails too the UI shows subtitles only.
"""
from __future__ import annotations

import asyncio
import logging
import os
import sys
import tempfile
import threading

from . import secrets

log = logging.getLogger("nova.tts")


class TTSError(RuntimeError):
    pass


class TextToSpeech:
    def __init__(self, settings):
        self.settings = settings
        self._pyttsx_lock = threading.Lock()

    def synthesize(self, text: str) -> tuple[bytes, str]:
        """Return (audio bytes, mime type)."""
        provider = self.settings.get("tts.provider")
        errors = []
        order = [provider] + (["system"] if provider != "system" else [])
        for p in order:
            try:
                if p == "edge":
                    return self._edge(text), "audio/mpeg"
                if p == "openai":
                    return self._openai(text), "audio/mpeg"
                if p == "system":
                    return self._system(text), "audio/wav"
            except Exception as exc:
                log.warning("TTS provider %s failed: %s", p, exc)
                errors.append(f"{p}: {exc}")
        raise TTSError("; ".join(errors) or "no TTS provider")

    # ------------------------------------------------------------------
    def _edge(self, text: str) -> bytes:
        try:
            import edge_tts  # type: ignore
        except Exception as exc:
            raise TTSError("edge-tts not installed") from exc
        cfg = self.settings.get("tts")

        async def run() -> bytes:
            comm = edge_tts.Communicate(text, cfg["voice"], rate=cfg["rate"], pitch=cfg["pitch"])
            data = bytearray()
            async for chunk in comm.stream():
                if chunk.get("type") == "audio":
                    data.extend(chunk["data"])
            return bytes(data)

        data = asyncio.run(asyncio.wait_for(run(), timeout=20))
        if not data:
            raise TTSError("edge-tts returned no audio")
        return data

    def _openai(self, text: str) -> bytes:
        import httpx  # type: ignore

        key = secrets.get_secret("OPENAI_API_KEY")
        if not key:
            raise TTSError("OPENAI_API_KEY is not set")
        cfg = self.settings.get("tts")
        r = httpx.post(
            "https://api.openai.com/v1/audio/speech",
            headers={"Authorization": f"Bearer {key}"},
            json={"model": cfg["openai_model"], "voice": cfg["openai_voice"],
                  "input": text, "response_format": "mp3"},
            timeout=30,
        )
        if r.status_code != 200:
            raise TTSError(f"OpenAI TTS error {r.status_code}: {r.text[:160]}")
        return r.content

    def _system(self, text: str) -> bytes:
        try:
            import pyttsx3  # type: ignore
        except Exception as exc:
            raise TTSError("pyttsx3 not installed") from exc
        with self._pyttsx_lock:
            if sys.platform == "win32":
                try:
                    import comtypes  # type: ignore

                    comtypes.CoInitialize()
                except Exception:
                    pass
            engine = pyttsx3.init()
            try:
                for v in engine.getProperty("voices"):
                    name = (getattr(v, "name", "") or "").lower()
                    gender = (getattr(v, "gender", "") or "")
                    if "david" in name or "male" == str(gender).lower() or "mark" in name:
                        engine.setProperty("voice", v.id)
                        break
                engine.setProperty("rate", 178)
                fd, path = tempfile.mkstemp(suffix=".wav")
                os.close(fd)
                engine.save_to_file(text, path)
                engine.runAndWait()
                with open(path, "rb") as f:
                    data = f.read()
                os.unlink(path)
            finally:
                try:
                    engine.stop()
                except Exception:
                    pass
        if len(data) < 100:
            raise TTSError("system voice produced no audio")
        return data
