"""NOVA desktop voice assistant - Python backend."""
__version__ = "1.0.0"
