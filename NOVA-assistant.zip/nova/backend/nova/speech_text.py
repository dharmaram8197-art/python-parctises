"""Turning streamed LLM text into speakable sentences."""
from __future__ import annotations

import re

_LINK = re.compile(r"\[([^\]]+)\]\((?:[^)]+)\)")
_URL = re.compile(r"https?://\S+")
_MD = re.compile(r"(\*\*|__|\*|_|`|#+\s|>\s|~~)")
_BULLET = re.compile(r"^\s*(?:[-*•]|\d+[.)])\s+", re.M)
_EMOJI = re.compile("[\U0001F300-\U0001FAFF☀-➿]")


def to_speech(text: str) -> str:
    """Strip markdown/URLs/emoji so TTS reads naturally."""
    text = _LINK.sub(r"\1", text)
    text = _URL.sub("the link on screen", text)
    text = _BULLET.sub("", text)
    text = _MD.sub("", text)
    text = _EMOJI.sub("", text)
    return " ".join(text.split()).strip()


class SentenceSplitter:
    """Feed streaming text; get back complete sentences to speak.

    Fenced code blocks (```...```) are never spoken - a short notice is
    spoken instead, while the full text still goes to the chat panel.
    """

    _END = re.compile(r"([.!?…])(\s+)|(\n\s*\n)|(:\s*\n)|(\n(?=\s*(?:[-*•]|\d+[.)])\s))")

    def __init__(self, min_chars: int = 18):
        self.min_chars = min_chars
        self.buf = ""
        self.in_code = False
        self.code_announced = False

    def feed(self, chunk: str) -> list[str]:
        self.buf += chunk
        out: list[str] = []
        while True:
            if self.in_code:
                end = self.buf.find("```")
                if end == -1:
                    # keep only a tail in case the fence is split across chunks
                    self.buf = self.buf[-2:]
                    break
                self.buf = self.buf[end + 3:]
                self.in_code = False
                continue
            fence = self.buf.find("```")
            search_area = self.buf if fence == -1 else self.buf[:fence]
            m = None
            for cand in self._END.finditer(search_area):
                if cand.end() >= self.min_chars:
                    m = cand
                    break
            if m is not None:
                sentence, self.buf = self.buf[: m.end()], self.buf[m.end():]
                spoken = to_speech(sentence)
                if spoken:
                    out.append(spoken)
                continue
            if fence != -1:
                before = to_speech(self.buf[:fence])
                if before:
                    out.append(before)
                if not self.code_announced:
                    out.append("I've put the code on your screen.")
                    self.code_announced = True
                self.buf = self.buf[fence + 3:]
                self.in_code = True
                continue
            break
        return out

    def flush(self) -> list[str]:
        if self.in_code:
            self.buf = ""
            return []
        spoken = to_speech(self.buf)
        self.buf = ""
        return [spoken] if spoken else []
