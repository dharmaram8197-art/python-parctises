"""Laptop skills available to NOVA."""
from __future__ import annotations

from .base import Registry, Tool, ToolResult
from .files import FileManager
from .music import MusicPlayer
from .reminders import ReminderService


def build_registry(settings, reminders: ReminderService) -> Registry:
    from . import files, music, reminders as rem, system

    reg = Registry()
    system.register(reg)
    files.register(reg, FileManager(lambda: settings.get("files.allowed_roots") or []))
    music.register(reg, MusicPlayer(settings.get))
    rem.register(reg, reminders)
    return reg


__all__ = ["Registry", "Tool", "ToolResult", "build_registry", "ReminderService"]
