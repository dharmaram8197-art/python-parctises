"""Reminders: natural-language time parsing, persistent storage and a scheduler."""
from __future__ import annotations

import json
import logging
import re
import threading
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from typing import Callable

from .base import Registry, Tool, ToolResult

log = logging.getLogger("nova.reminders")

_NUM_WORDS = {
    "a": 1, "an": 1, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7,
    "eight": 8, "nine": 9, "ten": 10, "eleven": 11, "twelve": 12, "fifteen": 15, "twenty": 20,
    "thirty": 30, "forty": 40, "forty five": 45, "forty-five": 45, "sixty": 60, "half an": 0.5,
    "half a": 0.5, "a couple of": 2, "couple of": 2, "a few": 3, "few": 3,
}
_UNITS = {
    "s": 1, "sec": 1, "secs": 1, "second": 1, "seconds": 1,
    "m": 60, "min": 60, "mins": 60, "minute": 60, "minutes": 60,
    "h": 3600, "hr": 3600, "hrs": 3600, "hour": 3600, "hours": 3600,
    "day": 86400, "days": 86400, "week": 604800, "weeks": 604800,
}
_NUM = r"(\d+(?:\.\d+)?|" + "|".join(sorted(map(re.escape, _NUM_WORDS), key=len, reverse=True)) + r")"
_REL = re.compile(_NUM + r"\s*(" + "|".join(sorted(_UNITS, key=len, reverse=True)) + r")\b")
_CLOCK = re.compile(r"\b(\d{1,2})(?::|\.)?(\d{2})?\s*(a\.?m\.?|p\.?m\.?)?(?=\W|$)")


def _num(token: str) -> float:
    token = token.strip().lower()
    return float(token) if re.match(r"^\d", token) else float(_NUM_WORDS.get(token, 0))


def parse_when(text: str, now: datetime | None = None) -> datetime | None:
    """Understand 'in 10 minutes', 'at 5:30 pm', 'tomorrow at 9', 'at noon', ISO times."""
    now = now or datetime.now()
    s = text.lower().strip().strip(".")
    if not s:
        return None
    # ISO 8601
    try:
        dt = datetime.fromisoformat(text.strip())
        return dt.astimezone().replace(tzinfo=None) if dt.tzinfo else dt
    except ValueError:
        pass

    # relative: "in 1 hour and 30 minutes", "after 5 min", "10 minutes from now"
    if re.search(r"\b(in|after|from now|later)\b", s) or _REL.fullmatch(s):
        total = 0.0
        for m in _REL.finditer(s):
            total += _num(m.group(1)) * _UNITS[m.group(2)]
        if "half an hour" in s and total == 0:
            total = 1800
        if total > 0:
            return now + timedelta(seconds=total)

    day_offset = 0
    if "day after tomorrow" in s:
        day_offset = 2
    elif "tomorrow" in s:
        day_offset = 1
    base = now + timedelta(days=day_offset)

    if "noon" in s or "midday" in s:
        hour, minute = 12, 0
    elif "midnight" in s:
        hour, minute = 0, 0
        if day_offset == 0:
            base = now + timedelta(days=1)
    else:
        cleaned = re.sub(r"\b(today|tomorrow|day after|tonight|this|at|on|by|o'clock|oclock)\b", " ", s)
        m = _CLOCK.search(cleaned)
        if not m:
            if day_offset:
                hour, minute = 9, 0  # "tomorrow" alone -> 9 AM
            else:
                return None
        else:
            hour = int(m.group(1))
            minute = int(m.group(2) or 0)
            ampm = (m.group(3) or "").replace(".", "")
            if hour > 23 or minute > 59:
                return None
            if ampm == "pm" and hour < 12:
                hour += 12
            elif ampm == "am" and hour == 12:
                hour = 0
            elif not ampm and hour <= 12:
                if "evening" in s or "tonight" in s or "afternoon" in s or "night" in s:
                    hour = hour + 12 if hour < 12 else hour
                elif "morning" not in s and day_offset == 0:
                    # ambiguous "at 5": pick the next occurrence of 5 (AM or PM)
                    candidate = base.replace(hour=hour % 12, minute=minute, second=0, microsecond=0)
                    while candidate <= now:
                        candidate += timedelta(hours=12)
                    return candidate
    result = base.replace(hour=hour, minute=minute, second=0, microsecond=0)
    if result <= now and day_offset == 0:
        result += timedelta(days=1)
    return result


def describe_time(dt: datetime, now: datetime | None = None) -> str:
    now = now or datetime.now()
    t = dt.strftime("%I:%M %p").lstrip("0")
    if dt.date() == now.date():
        return f"at {t}"
    if dt.date() == (now + timedelta(days=1)).date():
        return f"tomorrow at {t}"
    return f"on {dt.strftime('%A, %B')} {dt.day} at {t}"


class ReminderService:
    def __init__(self, path: Path, on_due: Callable[[dict], None]):
        self.path = path
        self.on_due = on_due
        self._lock = threading.Lock()
        self._items: list[dict] = []
        self._stop = threading.Event()
        self._load()

    def _load(self) -> None:
        if self.path.exists():
            try:
                self._items = json.loads(self.path.read_text(encoding="utf-8"))
            except Exception:
                log.error("Reminder file unreadable; starting fresh")
                self._items = []

    def _save(self) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self._items, indent=2), encoding="utf-8")
        tmp.replace(self.path)

    def start(self) -> None:
        threading.Thread(target=self._loop, daemon=True, name="reminders").start()

    def stop(self) -> None:
        self._stop.set()

    def _loop(self) -> None:
        while not self._stop.wait(1.0):
            now = datetime.now()
            due = []
            with self._lock:
                for item in self._items:
                    if datetime.fromisoformat(item["due"]) <= now:
                        due.append(item)
                if due:
                    self._items = [i for i in self._items if i not in due]
                    self._save()
            for item in due:
                try:
                    self.on_due(item)
                except Exception:
                    log.exception("Reminder callback failed")

    def list(self) -> list[dict]:
        with self._lock:
            return sorted(self._items, key=lambda i: i["due"])

    def add(self, message: str, due: datetime) -> dict:
        item = {"id": uuid.uuid4().hex[:8], "message": message.strip(), "due": due.isoformat(timespec="seconds"),
                "created": datetime.now().isoformat(timespec="seconds")}
        with self._lock:
            self._items.append(item)
            self._save()
        return item

    def remove(self, rid: str) -> bool:
        with self._lock:
            before = len(self._items)
            self._items = [i for i in self._items if i["id"] != rid]
            self._save()
            return len(self._items) != before

    # -- tools ---------------------------------------------------------------
    def create_reminder(self, message: str, when: str) -> ToolResult:
        due = parse_when(when)
        if due is None:
            return ToolResult(False, f"I couldn't understand the time '{when}'. Try 'in 10 minutes' or 'at 6 pm'.")
        if not message.strip():
            return ToolResult(False, "What should I remind you about?")
        item = self.add(message, due)
        return ToolResult(True, f"Okay, I'll remind you to {item['message']} {describe_time(due)}.", item)

    def list_reminders(self) -> ToolResult:
        items = self.list()
        if not items:
            return ToolResult(True, "You have no reminders.", [])
        first = items[0]
        msg = (f"You have {len(items)} reminder{'s' if len(items) > 1 else ''}. The next one is to "
               f"{first['message']} {describe_time(datetime.fromisoformat(first['due']))}.")
        return ToolResult(True, msg, items)

    def cancel_reminder(self, reminder_id: str = "", text: str = "") -> ToolResult:
        target = None
        for item in self.list():
            if (reminder_id and item["id"] == reminder_id) or (text and text.lower() in item["message"].lower()):
                target = item
                break
        if not target:
            return ToolResult(False, "I couldn't find that reminder.")
        self.remove(target["id"])
        return ToolResult(True, f"Cancelled the reminder to {target['message']}.")


def register(reg: Registry, svc: ReminderService) -> None:
    reg.add(Tool("create_reminder",
                 "Create a reminder. 'when' is natural language like 'in 20 minutes', 'at 6:30 pm', "
                 "'tomorrow at 9 am', or an ISO 8601 local datetime.",
                 {"type": "object", "properties": {"message": {"type": "string"}, "when": {"type": "string"}},
                  "required": ["message", "when"]}, svc.create_reminder))
    reg.add(Tool("list_reminders", "List upcoming reminders.", {"type": "object", "properties": {}},
                 lambda: svc.list_reminders()))
    reg.add(Tool("cancel_reminder", "Cancel a reminder by id or by matching text.",
                 {"type": "object", "properties": {"reminder_id": {"type": "string"}, "text": {"type": "string"}}},
                 svc.cancel_reminder))
