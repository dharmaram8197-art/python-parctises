"""Play music: local library first, then an online service."""
from __future__ import annotations

import difflib
import os
import random
import subprocess
import sys
import urllib.parse
import webbrowser
from pathlib import Path
from typing import Callable

from .base import Registry, Tool, ToolResult

AUDIO_EXT = {".mp3", ".m4a", ".wav", ".flac", ".ogg", ".aac", ".wma", ".opus"}


def _open(path: Path) -> None:
    if sys.platform == "win32":
        os.startfile(str(path))  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", str(path)])
    else:
        subprocess.Popen(["xdg-open", str(path)])


class MusicPlayer:
    def __init__(self, settings_get: Callable[[str], object]):
        self.get = settings_get

    def library(self) -> list[Path]:
        folder = Path(os.path.expanduser(str(self.get("music.folder") or "")))
        if not folder.is_dir():
            return []
        songs = []
        for root, _dirs, files in os.walk(folder):
            for f in files:
                if Path(f).suffix.lower() in AUDIO_EXT:
                    songs.append(Path(root) / f)
                    if len(songs) >= 5000:
                        return songs
        return songs

    def find_local(self, query: str) -> Path | None:
        songs = self.library()
        if not songs:
            return None
        q = query.lower()
        names = {s.stem.lower(): s for s in songs}
        hits = [s for n, s in names.items() if q in n]
        if hits:
            return hits[0]
        close = difflib.get_close_matches(q, list(names), n=1, cutoff=0.6)
        return names[close[0]] if close else None

    def play_music(self, query: str = "") -> ToolResult:
        query = (query or "").strip()
        generic = query.lower() in ("", "music", "some music", "a song", "songs", "my music", "something")
        if generic:
            songs = self.library()
            if songs:
                song = random.choice(songs)
                _open(song)
                return ToolResult(True, f"Playing {song.stem}.")
            query = "relaxing music mix"
        else:
            local = self.find_local(query)
            if local:
                _open(local)
                return ToolResult(True, f"Playing {local.stem}.")
        service = self.get("music.online_service") or "youtube"
        q = urllib.parse.quote_plus(query)
        url = {
            "youtube_music": f"https://music.youtube.com/search?q={q}",
            "spotify": f"https://open.spotify.com/search/{urllib.parse.quote(query)}",
        }.get(str(service), f"https://www.youtube.com/results?search_query={q}")
        webbrowser.open(url, new=2)
        label = {"youtube_music": "YouTube Music", "spotify": "Spotify"}.get(str(service), "YouTube")
        return ToolResult(True, f"Here's {query} on {label}.", {"url": url})


def register(reg: Registry, player: MusicPlayer) -> None:
    reg.add(Tool("play_music",
                 "Play music. Searches the user's music folder first, then opens an online music service. "
                 "Pass a song, artist or genre, or leave empty for anything.",
                 {"type": "object", "properties": {"query": {"type": "string"}}}, player.play_music))
