"""Basic file management, restricted to user-approved folders.

* Only folders listed in Settings -> Privacy -> Allowed folders can be touched.
* Anything that changes files (create, move, rename, delete) needs confirmation.
* Deletion sends files to the Recycle Bin / Trash - never a permanent delete.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Callable

from .base import Registry, Tool, ToolResult

EXECUTABLE_EXT = {".exe", ".bat", ".cmd", ".ps1", ".vbs", ".msi", ".scr", ".com", ".lnk", ".js",
                  ".jse", ".wsf", ".hta", ".reg", ".sh", ".app", ".jar", ".py", ".pyw"}
TEXT_EXT = {".txt", ".md", ".csv", ".json", ".py", ".js", ".html", ".css", ".log", ".ini", ".yaml", ".yml", ".xml"}
SHORTCUTS = {"desktop": "Desktop", "documents": "Documents", "downloads": "Downloads",
             "music": "Music", "pictures": "Pictures", "videos": "Videos"}


class FileManager:
    def __init__(self, roots_provider: Callable[[], list[str]]):
        self._roots = roots_provider

    def roots(self) -> list[Path]:
        out = []
        for r in self._roots():
            try:
                p = Path(os.path.expanduser(r)).resolve()
            except OSError:
                continue
            out.append(p)
        return out

    def resolve(self, path: str, must_exist: bool = False) -> Path:
        roots = self.roots()
        if not roots:
            raise PermissionError("No folders are allowed for file actions. Add one in Settings, Privacy.")
        raw = (path or "").strip().strip('"')
        first, _, rest = raw.replace("\\", "/").partition("/")
        if first.lower() in SHORTCUTS:
            base = Path.home() / SHORTCUTS[first.lower()]
            p = (base / rest) if rest else base
        else:
            p = Path(os.path.expanduser(raw))
            if not p.is_absolute():
                p = roots[0] / p
        p = p.resolve()
        if not any(p == r or p.is_relative_to(r) for r in roots):
            allowed = ", ".join(str(r) for r in roots)
            raise PermissionError(f"For your safety I can only work inside: {allowed}.")
        if must_exist and not p.exists():
            raise FileNotFoundError(str(p))
        return p

    # -- read-only ---------------------------------------------------------
    def list_files(self, folder: str = "documents") -> ToolResult:
        p = self.resolve(folder, must_exist=True)
        if not p.is_dir():
            return ToolResult(False, f"{p.name} is not a folder.")
        items = sorted(p.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower()))
        entries = [{"name": i.name, "type": "folder" if i.is_dir() else "file",
                    "size": i.stat().st_size if i.is_file() else None} for i in items[:200]]
        folders = sum(1 for e in entries if e["type"] == "folder")
        return ToolResult(True, f"{p.name} has {len(items)} items, including {folders} folders.",
                          {"path": str(p), "items": entries, "truncated": len(items) > 200})

    def search_files(self, name: str, folder: str = "") -> ToolResult:
        bases = [self.resolve(folder, must_exist=True)] if folder else self.roots()
        needle = name.lower().strip()
        hits = []
        for base in bases:
            for root, dirs, files in os.walk(base):
                dirs[:] = [d for d in dirs if not d.startswith(".") and d not in ("node_modules", "AppData")]
                for f in files + dirs:
                    if needle in f.lower():
                        hits.append(str(Path(root) / f))
                        if len(hits) >= 50:
                            break
                if len(hits) >= 50:
                    break
        if not hits:
            return ToolResult(True, f"I didn't find anything named {name}.", {"results": []})
        return ToolResult(True, f"I found {len(hits)} match{'es' if len(hits) != 1 else ''} for {name}.",
                          {"results": hits})

    def read_text_file(self, path: str) -> ToolResult:
        p = self.resolve(path, must_exist=True)
        if p.suffix.lower() not in TEXT_EXT:
            return ToolResult(False, "I can only read plain text files.")
        text = p.read_text(encoding="utf-8", errors="replace")
        return ToolResult(True, f"I read {p.name}.", {"content": text[:8000], "truncated": len(text) > 8000})

    def open_file(self, path: str) -> ToolResult:
        p = self.resolve(path, must_exist=True)
        if sys.platform == "win32":
            os.startfile(str(p))  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(p)])
        else:
            subprocess.Popen(["xdg-open", str(p)])
        return ToolResult(True, f"Opening {p.name}.")

    # -- changes (need confirmation) --------------------------------------
    def create_folder(self, path: str) -> ToolResult:
        p = self.resolve(path)
        p.mkdir(parents=True, exist_ok=True)
        return ToolResult(True, f"Created the folder {p.name}.", {"path": str(p)})

    def create_text_file(self, path: str, content: str = "", overwrite: bool = False) -> ToolResult:
        p = self.resolve(path)
        if p.exists() and not overwrite:
            return ToolResult(False, f"{p.name} already exists, so I left it unchanged.")
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return ToolResult(True, f"Saved {p.name}.", {"path": str(p)})

    def move_file(self, source: str, destination: str) -> ToolResult:
        src = self.resolve(source, must_exist=True)
        dst = self.resolve(destination)
        if dst.is_dir():
            dst = dst / src.name
        if dst.exists():
            return ToolResult(False, f"{dst.name} already exists there.")
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src), str(dst))
        return ToolResult(True, f"Moved {src.name} to {dst.parent.name}.", {"path": str(dst)})

    def delete_file(self, path: str) -> ToolResult:
        p = self.resolve(path, must_exist=True)
        if any(p == r for r in self.roots()):
            return ToolResult(False, "I won't delete one of your main allowed folders.")
        try:
            from send2trash import send2trash  # type: ignore
        except Exception:
            return ToolResult(False, "Deleting needs the send2trash package so files go to the Recycle Bin.")
        send2trash(str(p))
        return ToolResult(True, f"Moved {p.name} to the Recycle Bin.")


def register(reg: Registry, fm: FileManager) -> None:
    S = {"type": "string"}
    reg.add(Tool("list_files", "List the contents of a folder. Accepts 'desktop', 'documents', 'downloads' or a path.",
                 {"type": "object", "properties": {"folder": S}}, fm.list_files))
    reg.add(Tool("search_files", "Find files or folders whose name contains some text.",
                 {"type": "object", "properties": {"name": S, "folder": S}, "required": ["name"]}, fm.search_files))
    reg.add(Tool("read_text_file", "Read a plain-text file so you can summarise or answer questions about it.",
                 {"type": "object", "properties": {"path": S}, "required": ["path"]}, fm.read_text_file))
    reg.add(Tool("open_file", "Open a file with its default application.",
                 {"type": "object", "properties": {"path": S}, "required": ["path"]}, fm.open_file,
                 sensitive=lambda a: Path(str(a.get("path", ""))).suffix.lower() in EXECUTABLE_EXT,
                 describe=lambda a: f"Open the program file '{a.get('path')}'? Programs can change your computer."))
    reg.add(Tool("create_folder", "Create a new folder.",
                 {"type": "object", "properties": {"path": S}, "required": ["path"]}, fm.create_folder,
                 sensitive=True, describe=lambda a: f"Create the folder '{fm.resolve(a.get('path', ''))}'"))
    reg.add(Tool("create_text_file", "Create (or with overwrite=true, replace) a text file with the given content.",
                 {"type": "object", "properties": {"path": S, "content": S, "overwrite": {"type": "boolean"}},
                  "required": ["path"]}, fm.create_text_file, sensitive=True,
                 describe=lambda a: (f"{'Overwrite' if a.get('overwrite') else 'Create'} the file "
                                     f"'{fm.resolve(a.get('path', ''))}' ({len(a.get('content', '') or '')} characters)")))
    reg.add(Tool("move_file", "Move or rename a file or folder.",
                 {"type": "object", "properties": {"source": S, "destination": S}, "required": ["source", "destination"]},
                 fm.move_file, sensitive=True,
                 describe=lambda a: f"Move '{fm.resolve(a.get('source', ''))}' to '{fm.resolve(a.get('destination', ''))}'"))
    reg.add(Tool("delete_file", "Delete a file or folder by moving it to the Recycle Bin.",
                 {"type": "object", "properties": {"path": S}, "required": ["path"]}, fm.delete_file,
                 sensitive=True, describe=lambda a: f"Move '{fm.resolve(a.get('path', ''))}' to the Recycle Bin"))
