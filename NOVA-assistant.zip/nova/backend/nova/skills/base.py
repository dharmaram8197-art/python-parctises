"""Tool registry: every laptop action NOVA can take is a Tool.

Tools marked sensitive are never executed until the user confirms, either by
clicking Allow in the confirmation dialog or by saying "yes".
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from typing import Any, Callable

log = logging.getLogger("nova.skills")


@dataclass
class ToolResult:
    ok: bool
    message: str                     # short, speakable summary
    data: Any = None                 # extra detail for the AI model

    def for_model(self) -> str:
        payload: dict[str, Any] = {"ok": self.ok, "message": self.message}
        if self.data is not None:
            payload["data"] = self.data
        text = json.dumps(payload, ensure_ascii=False, default=str)
        return text[:12000]


@dataclass
class Tool:
    name: str
    description: str
    parameters: dict
    func: Callable[..., ToolResult]
    # bool, or a function(args) -> bool deciding per call
    sensitive: bool | Callable[[dict], bool] = False
    # function(args) -> human description used in the confirmation prompt
    describe: Callable[[dict], str] | None = None
    # False = only used by the offline command router, hidden from the AI model
    expose: bool = True

    def is_sensitive(self, args: dict) -> bool:
        return self.sensitive(args) if callable(self.sensitive) else bool(self.sensitive)

    def schema(self) -> dict:
        return {"name": self.name, "description": self.description, "parameters": self.parameters}


ConfirmFn = Callable[[str, str], bool]  # (title, detail) -> approved


@dataclass
class Registry:
    tools: dict[str, Tool] = field(default_factory=dict)

    def add(self, tool: Tool) -> None:
        self.tools[tool.name] = tool

    def schemas(self) -> list[dict]:
        return [t.schema() for t in self.tools.values() if t.expose]

    def execute(self, name: str, args: dict | None, confirm: ConfirmFn) -> ToolResult:
        tool = self.tools.get(name)
        if tool is None:
            return ToolResult(False, f"I don't have a tool called {name}.")
        args = dict(args or {})
        try:
            if tool.is_sensitive(args):
                detail = tool.describe(args) if tool.describe else f"{name}({args})"
                if not confirm("Allow this action?", detail):
                    return ToolResult(False, "Okay, I won't do that.", {"cancelled_by_user": True})
            return tool.func(**args)
        except TypeError as exc:
            log.warning("Bad arguments for %s: %s", name, exc)
            return ToolResult(False, f"I couldn't run {name}: missing or invalid details.")
        except PermissionError as exc:
            return ToolResult(False, str(exc) or "That location isn't allowed.")
        except FileNotFoundError as exc:
            return ToolResult(False, f"I couldn't find that: {exc}")
        except Exception as exc:
            log.exception("Tool %s failed", name)
            return ToolResult(False, f"Sorry, that didn't work: {exc}")
