"""Apps, websites, date/time and web search."""
from __future__ import annotations

import difflib
import logging
import os
import platform
import re
import shutil
import subprocess
import sys
import urllib.parse
import webbrowser
from datetime import datetime
from pathlib import Path

from .base import Registry, Tool, ToolResult

log = logging.getLogger("nova.system")

KNOWN_SITES = {
    "youtube": "https://www.youtube.com",
    "google": "https://www.google.com",
    "gmail": "https://mail.google.com",
    "github": "https://github.com",
    "chatgpt": "https://chatgpt.com",
    "claude": "https://claude.ai",
    "wikipedia": "https://www.wikipedia.org",
    "stack overflow": "https://stackoverflow.com",
    "stackoverflow": "https://stackoverflow.com",
    "linkedin": "https://www.linkedin.com",
    "instagram": "https://www.instagram.com",
    "facebook": "https://www.facebook.com",
    "twitter": "https://x.com",
    "x": "https://x.com",
    "reddit": "https://www.reddit.com",
    "amazon": "https://www.amazon.in",
    "flipkart": "https://www.flipkart.com",
    "netflix": "https://www.netflix.com",
    "whatsapp web": "https://web.whatsapp.com",
    "google maps": "https://maps.google.com",
    "maps": "https://maps.google.com",
    "google drive": "https://drive.google.com",
    "drive": "https://drive.google.com",
    "leetcode": "https://leetcode.com",
    "youtube music": "https://music.youtube.com",
    "spotify web": "https://open.spotify.com",
}

# Windows commands for common apps (used before searching the Start Menu)
WINDOWS_APPS = {
    "notepad": ["notepad.exe"],
    "calculator": ["calc.exe"],
    "calc": ["calc.exe"],
    "paint": ["mspaint.exe"],
    "file explorer": ["explorer.exe"],
    "explorer": ["explorer.exe"],
    "files": ["explorer.exe"],
    "command prompt": ["cmd.exe", "/c", "start", "cmd.exe"],
    "cmd": ["cmd.exe", "/c", "start", "cmd.exe"],
    "terminal": ["wt.exe"],
    "powershell": ["cmd.exe", "/c", "start", "powershell.exe"],
    "task manager": ["taskmgr.exe"],
    "settings": ["explorer.exe", "ms-settings:"],
    "control panel": ["control.exe"],
    "snipping tool": ["explorer.exe", "ms-screenclip:"],
    "camera": ["explorer.exe", "microsoft.windows.camera:"],
    "store": ["explorer.exe", "ms-windows-store:"],
    "clock": ["explorer.exe", "ms-clock:"],
    "photos": ["explorer.exe", "ms-photos:"],
    "mail": ["explorer.exe", "outlookmail:"],
    "spotify": ["explorer.exe", "spotify:"],
}

APP_ALIASES = {
    "vs code": "visual studio code", "vscode": "visual studio code", "code": "visual studio code",
    "chrome": "google chrome", "edge": "microsoft edge", "word": "word", "excel": "excel",
    "powerpoint": "powerpoint", "teams": "microsoft teams",
}


def _norm(s: str) -> str:
    s = s.lower().strip()
    s = re.sub(r"^(the|my)\s+", "", s)
    s = re.sub(r"\s+(app|application|program)$", "", s)
    return s.strip(" .!?")


def _start_menu_shortcuts() -> dict[str, Path]:
    roots = [
        Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData")) / "Microsoft/Windows/Start Menu/Programs",
        Path(os.environ.get("APPDATA", "")) / "Microsoft/Windows/Start Menu/Programs",
    ]
    found: dict[str, Path] = {}
    for root in roots:
        if not root.exists():
            continue
        for p in root.rglob("*.lnk"):
            name = p.stem.lower()
            if any(w in name for w in ("uninstall", "readme", "help", "documentation")):
                continue
            found.setdefault(name, p)
    return found


def _linux_desktop_entries() -> dict[str, str]:
    found = {}
    for root in [Path("/usr/share/applications"), Path.home() / ".local/share/applications"]:
        if root.exists():
            for p in root.glob("*.desktop"):
                try:
                    m = re.search(r"^Name=(.+)$", p.read_text(errors="ignore"), re.M)
                except OSError:
                    continue
                if m:
                    found[m.group(1).strip().lower()] = p.stem
    return found


def _best_match(query: str, names: list[str]) -> str | None:
    if query in names:
        return query
    contains = [n for n in names if query in n]
    if contains:
        return min(contains, key=len)
    close = difflib.get_close_matches(query, names, n=1, cutoff=0.72)
    return close[0] if close else None


def open_application(name: str) -> ToolResult:
    query = _norm(name)
    if not query:
        return ToolResult(False, "Which app should I open?")
    if sys.platform == "win32":
        if query in WINDOWS_APPS:
            subprocess.Popen(WINDOWS_APPS[query], shell=False)
            return ToolResult(True, f"Opening {name}.")
        shortcuts = _start_menu_shortcuts()
        target = APP_ALIASES.get(query, query)
        match = _best_match(target, list(shortcuts))
        if match:
            os.startfile(str(shortcuts[match]))  # type: ignore[attr-defined]
            return ToolResult(True, f"Opening {match.title()}.")
    elif sys.platform == "darwin":
        target = APP_ALIASES.get(query, query)
        apps = [p.stem.lower() for d in ("/Applications", "/System/Applications",
                                          str(Path.home() / "Applications"))
                for p in Path(d).glob("*.app")] if Path("/Applications").exists() else []
        match = _best_match(target, apps) or target
        r = subprocess.run(["open", "-a", match], capture_output=True)
        if r.returncode == 0:
            return ToolResult(True, f"Opening {match.title()}.")
    else:
        entries = _linux_desktop_entries()
        target = APP_ALIASES.get(query, query)
        match = _best_match(target, list(entries))
        if match and shutil.which("gtk-launch"):
            subprocess.Popen(["gtk-launch", entries[match]])
            return ToolResult(True, f"Opening {match.title()}.")
        if shutil.which(query):
            subprocess.Popen([query])
            return ToolResult(True, f"Opening {name}.")
    if query in KNOWN_SITES:
        return open_website(query)
    return ToolResult(False, f"I couldn't find an app called {name} on this computer.")


def normalize_url(target: str) -> str | None:
    t = target.strip().strip(".").lower()
    if t in KNOWN_SITES:
        return KNOWN_SITES[t]
    raw = target.strip().strip(".")
    if re.match(r"^https?://", raw, re.I):
        url = raw
    elif re.match(r"^[\w-]+(\.[\w-]+)+(/\S*)?$", raw):
        url = "https://" + raw
    else:
        return None
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        return None
    return url


def open_website(url: str) -> ToolResult:
    target = normalize_url(url)
    if target is None:
        return web_search(url)
    webbrowser.open(target, new=2)
    host = urllib.parse.urlparse(target).netloc.replace("www.", "")
    return ToolResult(True, f"Opening {host}.", {"url": target})


def get_datetime() -> ToolResult:
    now = datetime.now().astimezone()
    return ToolResult(True, now.strftime("It's %I:%M %p on %A, %B %d, %Y.").replace(" 0", " "),
                      {"iso": now.isoformat(), "timezone": str(now.tzinfo)})


def tell_time() -> ToolResult:
    now = datetime.now()
    return ToolResult(True, f"It's {now.strftime('%I:%M %p').lstrip('0')}.")


def tell_date() -> ToolResult:
    now = datetime.now()
    return ToolResult(True, f"Today is {now.strftime('%A, %B')} {now.day}, {now.year}.")


def _snippets(query: str, n: int = 5) -> list[dict]:
    try:
        from ddgs import DDGS  # type: ignore
    except Exception:
        try:
            from duckduckgo_search import DDGS  # type: ignore
        except Exception:
            return []
    try:
        with DDGS() as d:
            return [{"title": r.get("title"), "snippet": r.get("body"), "url": r.get("href")}
                    for r in d.text(query, max_results=n)]
    except Exception as exc:
        log.info("Web snippets unavailable: %s", exc)
        return []


def web_search(query: str, open_browser: bool = True, engine: str = "google") -> ToolResult:
    query = query.strip()
    if not query:
        return ToolResult(False, "What should I search for?")
    q = urllib.parse.quote_plus(query)
    url = {
        "youtube": f"https://www.youtube.com/results?search_query={q}",
        "bing": f"https://www.bing.com/search?q={q}",
        "duckduckgo": f"https://duckduckgo.com/?q={q}",
    }.get(engine, f"https://www.google.com/search?q={q}")
    if open_browser:
        webbrowser.open(url, new=2)
    results = _snippets(query) if not open_browser or engine == "google" else []
    msg = f"Here are the search results for {query}." if open_browser else f"I searched for {query}."
    return ToolResult(True, msg, {"url": url, "results": results} if results else {"url": url})


def system_info() -> ToolResult:
    data = {"os": f"{platform.system()} {platform.release()}", "machine": platform.machine(),
            "python": platform.python_version()}
    try:
        import psutil  # type: ignore
        b = psutil.sensors_battery()
        if b:
            data["battery_percent"] = round(b.percent)
            data["plugged_in"] = b.power_plugged
    except Exception:
        pass
    msg = f"You're running {data['os']}."
    if "battery_percent" in data:
        msg += f" Battery is at {data['battery_percent']} percent."
    return ToolResult(True, msg, data)


def register(reg: Registry) -> None:
    reg.add(Tool("open_application", "Open an installed application on the user's computer by name.",
                 {"type": "object", "properties": {"name": {"type": "string", "description": "App name, e.g. 'notepad', 'vs code', 'chrome'"}},
                  "required": ["name"]}, open_application))
    reg.add(Tool("open_website", "Open a website in the default browser. Accepts a URL, a domain or a well-known site name.",
                 {"type": "object", "properties": {"url": {"type": "string"}}, "required": ["url"]}, open_website))
    reg.add(Tool("get_datetime", "Get the current local date, time and timezone.",
                 {"type": "object", "properties": {}}, lambda: get_datetime()))
    reg.add(Tool("tell_time", "Current time.", {"type": "object", "properties": {}},
                 lambda: tell_time(), expose=False))
    reg.add(Tool("tell_date", "Current date.", {"type": "object", "properties": {}},
                 lambda: tell_date(), expose=False))
    reg.add(Tool("web_search",
                 "Search the web. With open_browser=true the results open in the browser; with false, "
                 "result snippets are returned to you so you can answer the user's question about current information.",
                 {"type": "object", "properties": {
                     "query": {"type": "string"},
                     "open_browser": {"type": "boolean", "default": True},
                     "engine": {"type": "string", "enum": ["google", "bing", "duckduckgo", "youtube"]}},
                  "required": ["query"]}, web_search))
    reg.add(Tool("system_info", "Get operating system and battery information.",
                 {"type": "object", "properties": {}}, lambda: system_info()))
